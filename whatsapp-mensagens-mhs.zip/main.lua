local manifest = {
  id = 'whatsapp-messages-mhs',
  name = 'WhatsApp messages (MHS)',
  version = '3.7',
  author = 'Aaron Hewitt, adapted by Michel Henrique',
  minApiVersion = 2,
  testedApiVersion = 2,
  description = 'Reads each message in a WhatsApp chat as one item: sender, content, the message it replies to, and time. Play, playback speed and the other buttons in a message are in its Actions menu. In the chats list, swiping skips each chat\'s photo, which opens the profile from the chat\'s Actions menu. The actions WhatsApp gives a message, such as reply, forward and share, are in its Actions menu too. On a voice message, a two-finger swipe right advances it and a two-finger swipe left rewinds it; elsewhere those gestures do what they always do. After you start recording a voice message without holding the microphone, focus goes to Send instead of Pause, without Send being said. A double tap on a document message opens the document instead of pressing Forward. A three-finger tap presses Read more on the focused message and says the whole message. Works with WhatsApp in English and in Brazilian Portuguese.',
  apps = {
    { package = 'com.whatsapp', activity = 'Conversation' },
    { package = 'com.whatsapp', activity = 'HomeActivity' },
    { package = 'com.whatsapp.w4b', activity = 'Conversation' },
    { package = 'com.whatsapp.w4b', activity = 'HomeActivity' },
  },
  permissions = { 'screen', 'actions', 'speech', 'input' },
  settings = {
    { key = 'expandLong', type = 'switch', title = 'Expand long messages', default = true },
    { key = 'sendAfterRecording', type = 'switch', title = 'Focus Send when a voice message recording starts', default = true },
  },
  commands = {
    { id = 'audioForward', title = 'Advance voice message', gesture = 'twoFingerSwipeRight' },
    { id = 'audioBackward', title = 'Rewind voice message', gesture = 'twoFingerSwipeLeft' },
    { id = 'openDocument', title = 'Open document', gesture = 'doubleTap' },
    { id = 'readMore', title = 'Read more', gesture = 'threeFingerTap' },
  },
  rules = {
    { match = { parentId = 'list', className = 'ViewGroup' }, group = true, activity = 'Conversation' },
    -- A double tap on a photo message opens the photo, not the row.
    { id = 'conversation_row_image', activate = { id = 'image' }, activity = 'Conversation' },
    {
      match = { clickable = true, inside = { parentId = 'list', className = 'ViewGroup' } },
      hide = 'all',
      activity = 'Conversation',
    },
    {
      match = { className = 'SeekBar', inside = { parentId = 'list', className = 'ViewGroup' } },
      hide = true,
      silence = true,
      activity = 'Conversation',
    },
    -- A voice message's time, which counts up each second while it plays.
    {
      match = { id = 'description', inside = { parentId = 'list', className = 'ViewGroup' } },
      silence = true,
      activity = 'Conversation',
    },
    -- The photo of each chat in the chats list and the Communities tab. It is in the chat's
    -- Actions menu instead.
    { match = { id = 'contact_selector', parentId = 'contact_row_container' }, hide = 'all', activity = 'HomeActivity' },
    { match = { id = 'contact_photo', parentId = 'contact_row_container' }, hide = true, activity = 'HomeActivity' },
  },
}

local tr = sf._

-- What WhatsApp itself writes in a message, in English and in Brazilian Portuguese. The script finds
-- these in the text of the screen, so each has the texts of every language it knows. The comparisons
-- ignore case where noted.
local WA = {
  voice_marks = { ', voice message', ', mensagem de voz', ', audio message', ', mensagem de áudio',
                  ', mensagem de audio' },
  poll_from = { 'Poll from ', 'Enquete de ', 'Enquete criada por ' },
  elapsed = { '^Voice message, (.*) elapsed$', '^Mensagem de voz, (.*) decorridos?$',
              '^Mensagem de voz, (.*) transcorridos?$', '^Mensagem de voz, (.*) reproduzidos?$' },
  zero_elapsed = { ['0 seconds'] = true, ['0 segundos'] = true, ['0 segundo'] = true },
  enlarge = { 'enlarge photo', 'ampliar foto' },
  photo_words = { 'photo', 'foto' },
  read_more = { 'read more', 'ler mais', 'leia mais' },
  -- The Pause button of a recording that is locked, and the Send button.
  pause = { 'pause', 'pausar' },
  send = { 'Send', 'Enviar' },
}

local function lower(text)
  return (text or ''):lower()
end

local function is_one_of(text, candidates)
  text = lower(text)
  for _, candidate in ipairs(candidates) do
    if text == candidate then
      return true
    end
  end
  return false
end

-- The first of [marks] found in [text], and where.
local function earliest(text, marks)
  local at
  for _, mark in ipairs(marks) do
    local found = text:find(mark, 1, true)
    if found and (not at or found < at) then
      at = found
    end
  end
  return at
end

-- A message row is read with one search, which gives the row and everything in it, so that the
-- rest of the script looks things up in the script instead of asking WhatsApp again. Every call
-- to the app takes time, more than the 30 milliseconds SandFly waits for onFocus, so the row is
-- read after onFocus returns and said when it is ready.
local MAX_ROW_ITEMS = 200
local MAX_BUTTONS = 24
local MAX_OPTIONS = 20
local MAX_REACTIONS = 8
local MAX_NOTICES = 5
local LABEL_DEPTH = 3
local MAX_BUBBLE_ITEMS = 60
local MAX_BUBBLE_TEXTS = 6

local function present(text)
  if text ~= nil and text ~= '' then
    return text
  end
end

-- Joins the parts that aren't nil, false or empty.
local function join(parts, separator)
  local kept = {}
  for i = 1, parts.n or #parts do
    local part = parts[i]
    if part and part ~= '' then
      kept[#kept + 1] = part
    end
  end
  return table.concat(kept, separator)
end

local function short_id(item)
  return (item.id or ''):match('[^/]*$')
end

-- Removes the direction marks WhatsApp adds, U+200B to U+200F, U+202A to U+202E and U+2066 to
-- U+2069, and the "~" before a name the contact list doesn't have.
local function clean(text)
  text = (text or ''):gsub('\226\128[\139-\143\170-\174]', '')
  text = text:gsub('\226\129[\166-\169]', '')
  -- The narrow no-break space after the "~", U+202F.
  text = text:gsub('\226\128\175', ' ')
  text = text:match('^%s*(.-)%s*$')
  text = text:gsub('^~%s*', '')
  return (text:match('^%s*(.-)%s*$'))
end

-- Gives the list of messages that the row is in, or nil if the item isn't a message row.
local function list_of(item)
  if short_id(item):sub(1, 17) ~= 'conversation_row_' then
    return nil
  end
  local parent = item:parent()
  if parent and (parent.id or ''):sub(-5) == '/list' then
    return parent
  end
end

-- The row and everything in it, by short id.
local function read_row(row, list)
  local items = row:findAll({}, MAX_ROW_ITEMS)
  local by_id = {}
  for _, item in ipairs(items) do
    local id = short_id(item)
    if id ~= '' then
      local found = by_id[id]
      if not found then
        found = {}
        by_id[id] = found
      end
      found[#found + 1] = item
    end
  end
  return { node = row, list = list, items = items, by_id = by_id }
end

local function first(r, id)
  local found = r.by_id[id]
  return found and found[1]
end

local function all_of(r, id, limit)
  local found = r.by_id[id] or {}
  local result = {}
  for i = 1, math.min(#found, limit) do
    result[i] = found[i]
  end
  return result
end

local function text_in(r, id)
  local found = first(r, id)
  return found and clean(found.text) or ''
end

local function main_of(r)
  return first(r, 'main_layout') or first(r, 'polls_main_layout')
end

-- Sent messages have a delivery status and sit against the right edge.
local function is_outgoing(r)
  if first(r, 'status') then
    return true
  end
  local main = main_of(r)
  local row = r.node
  return main ~= nil and row.bounds.right - main.bounds.right < main.bounds.left - row.bounds.left
end

-- Whether the chat is a group, and the contact's name if not, kept for each chat.
local chats = {}

-- In a chat with one person, the messages from them have no name and no picture.
local function contact_name(list)
  if not list then
    return ''
  end
  local chat = chats[list.handle]
  if not chat then
    local is_group = false
    for _, id in ipairs({ 'name_in_group_tv', 'group_profile_pic', 'group_profile_initials' }) do
      if list:find(id) then
        is_group = true
        break
      end
    end
    local title = not is_group and sf.screen.find('conversation_contact_name') or nil
    chat = { name = title and clean(title.text) or '' }
    chats[list.handle] = chat
  end
  return chat.name
end

-- Splits "54 seconds, 09:11, played" into the body, the time and what follows the time.
local function split_time(rest)
  local init = 1
  while true do
    local s, e, time = rest:find(',%s*(%d%d?:%d%d)', init)
    if not s then
      return nil
    end
    local tail = rest:sub(e + 1)
    local ampm = tail:match('^%s?[aApP][mM]')
    if ampm then
      time = time .. ampm
      tail = tail:sub(#ampm + 1)
    end
    if tail == '' then
      return rest:sub(1, s - 1), time, nil
    end
    local state = tail:match('^,%s*(.*)$')
    if state then
      return rest:sub(1, s - 1), time, state
    end
    init = s + 1
  end
end

-- "Alex Smith, voice message, 54 seconds, 09:11" has the sender first, and the time and "played"
-- last. A sound file reads "audio message" instead, and its row also shows the file name.
local function voice_of(r)
  if r.voice == nil then
    r.voice = false
    local main = first(r, 'main_layout')
    local description = main and main.contentDescription or ''
    local at = earliest(description, WA.voice_marks)
    if at then
      local rest = description:sub(at + 2)
      local file = short_id(r.node) == 'conversation_row_audio' and text_in(r, 'description') or ''
      local body, time, state = split_time(rest)
      r.voice = {
        sender = clean(description:sub(1, at - 1)),
        body = join({ body or rest, file }, ', '),
        time = time or '',
        state = state or '',
      }
    end
  end
  return r.voice or nil
end

-- "Poll from Alex Smith, next event.\nSelect one or more\n..."; each option reads "Name, 2 votes".
local function poll_of(r)
  if r.poll == nil then
    r.poll = false
    local main = first(r, 'polls_main_layout')
    if main then
      local name = text_in(r, 'poll_name')
      local description = main.contentDescription or ''
      local end_at = description:find(', ' .. name .. '.', 1, true)
      local parts = { tr('poll') .. ': ' .. name, text_in(r, 'poll_type_text') }
      for _, option in ipairs(all_of(r, 'poll_option_main_layout', MAX_OPTIONS)) do
        local label = clean(option.contentDescription)
        parts[#parts + 1] = option.checked and (tr('selected') .. ' ' .. label) or label
      end
      local sender = ''
      for _, prefix in ipairs(WA.poll_from) do
        if end_at and description:sub(1, #prefix) == prefix then
          sender = clean(description:sub(#prefix + 1, end_at - 1))
          break
        end
      end
      r.poll = { sender = sender, body = join(parts, '. ') }
    end
  end
  return r.poll or nil
end

-- A message from the same sender as the one before it has no name of its own.
local function sender_of(r, depth)
  depth = depth or 3
  local named = text_in(r, 'name_in_group_tv')
  if named ~= '' then
    return named
  end
  local known = (voice_of(r) or poll_of(r) or {}).sender
  if present(known) then
    return known
  end
  if is_outgoing(r) then
    return tr('You')
  end
  if depth > 0 and r.list then
    local rows = r.rows or r.list:children()
    for i, sibling in ipairs(rows) do
      if sibling == r.node then
        local previous = i > 1 and rows[i - 1] or nil
        if previous then
          local p = read_row(previous, r.list)
          p.rows = rows
          if not is_outgoing(p) then
            local name = present(sender_of(p, depth - 1))
            if name then
              return name
            end
          end
        end
        break
      end
    end
  end
  return contact_name(r.list)
end

-- "Voice message, 2 minutes, 33 seconds elapsed"; "0 seconds elapsed" before it has played.
local function elapsed_of(r)
  local seek_bar = first(r, 'audio_seekbar')
  local elapsed
  if seek_bar then
    for _, pattern in ipairs(WA.elapsed) do
      elapsed = (seek_bar.contentDescription or ''):match(pattern)
      if elapsed then
        break
      end
    end
  end
  if elapsed and not WA.zero_elapsed[lower(elapsed)] then
    return elapsed .. ' ' .. tr('elapsed')
  end
  return ''
end

local function label_of(item, depth)
  depth = depth or LABEL_DEPTH
  local own = clean(present(item.contentDescription) or item.text)
  if own ~= '' or depth == 0 then
    return own
  end
  for _, child in ipairs(item:children()) do
    local label = label_of(child, depth - 1)
    if label ~= '' then
      return label
    end
  end
  return ''
end

local function document_of(r)
  if short_id(r.node) ~= 'conversation_row_document' then
    return ''
  end
  local content = first(r, 'content')
  local label = content and label_of(content) or ''
  return label ~= '' and (tr('document') .. ': ' .. label) or tr('document')
end

-- "Enlarge photo", or "Photo 331 kB" before it is downloaded.
local function photo_of(r)
  if short_id(r.node) ~= 'conversation_row_image' then
    return ''
  end
  local image = first(r, 'image')
  local label = clean(image and image.contentDescription)
  if label == '' or is_one_of(label, WA.enlarge) then
    return tr('photo')
  end
  for _, word in ipairs(WA.photo_words) do
    if label:sub(1, #word):lower() == word then
      return tr('photo') .. label:sub(#word + 1)
    end
  end
  return label
end

-- The quote's frame and holder have no text of their own, so Android leaves them out of what a
-- screen reader sees; only the quote's title and text are there.
local function reply_of(r)
  local author = text_in(r, 'quoted_title')
  local quoted = text_in(r, 'quoted_text')
  if author == '' and quoted == '' then
    return ''
  end
  return join({ (tr('in reply to') .. ' ' .. author):match('^%s*(.-)%s*$'), quoted }, ': ')
end

-- A link's preview repeats the link; only a title that isn't the address is worth saying, unless
-- the message is only the link, which WhatsApp then shows as the preview alone.
local function preview_of(r, alone)
  local title = text_in(r, 'title')
  local is_address = title:find('^https?://') or title:find('^www%.')
  local named
  if title ~= '' and not is_address then
    named = title
  elseif alone then
    named = present(text_in(r, 'url')) or title
  end
  if not present(named) then
    return ''
  end
  return tr(first(r, 'play_button') and 'video link' or 'link') .. ': ' .. named
end

-- The time and status are said on their own, so a message of a kind not handled above is read
-- from the rest of the text in its bubble.
local SKIP_IDS = {
  date = true, status = true, name_in_group_tv = true, secondary_name_in_group_tv = true,
  conversation_row_date_divider = true, group_profile_initials = true,
}
local function bubble_text_of(r)
  -- A text message's bubble has nothing to say of its own, so screen readers don't see it.
  local main = main_of(r) or r.node
  local texts, seen = {}, {}
  for _, item in ipairs(main:findAll({}, MAX_BUBBLE_ITEMS)) do
    if #texts >= MAX_BUBBLE_TEXTS then
      break
    end
    if not SKIP_IDS[short_id(item)] then
      local own = clean(present(item.contentDescription) or item.text)
      if own ~= '' and not seen[own] then
        seen[own] = true
        texts[#texts + 1] = own
      end
    end
  end
  return table.concat(texts, ', ')
end

local function reactions_of(r)
  local reactions = {}
  for _, reaction in ipairs(all_of(r, 'reaction_bubble_emoji_text', MAX_REACTIONS)) do
    reactions[#reactions + 1] = clean(reaction.text)
  end
  if #reactions == 0 then
    return ''
  end
  return tr('reactions') .. ' ' .. table.concat(reactions, ' ')
end

local function describe(r)
  local voice = voice_of(r)
  local poll = not voice and poll_of(r) or nil
  local body
  if voice then
    body = voice.body
  elseif poll then
    body = poll.body
  else
    local text = present(text_in(r, 'message_text')) or text_in(r, 'caption')
    body = join({ present(document_of(r)) or photo_of(r), text }, ', ')
  end
  local notices = {}
  for _, info in ipairs(all_of(r, 'info', MAX_NOTICES)) do
    notices[#notices + 1] = clean(info.text)
  end
  local preview = preview_of(r, body == '')
  local other = (body == '' and preview == '') and bubble_text_of(r) or ''
  if body == '' and preview == '' and other == '' then
    return #notices > 0 and table.concat(notices, ', ') or nil
  end
  local status = first(r, 'status')
  local time = voice and voice.time or text_in(r, 'date')
  local state = voice and present(voice.state) or (status and status.contentDescription)
  local parts = table.pack(
    sender_of(r),
    present(body) or present(preview) or other,
    voice and elapsed_of(r),
    first(r, 'edit_label') and tr('edited'),
    body ~= '' and preview,
    reply_of(r),
    reactions_of(r),
    join({ time, state, text_in(r, 'conversation_row_date_divider') }, ', ')
  )
  for _, notice in ipairs(notices) do
    parts.n = parts.n + 1
    parts[parts.n] = notice
  end
  return join(parts, ', ')
end

-- Whether [item] is WhatsApp's "Read more". It may be in the description or in the text, and with an
-- ellipsis or a period at the end, so those are left out of the comparison.
local function plain(text)
  local t = lower(text):gsub('\u{2026}', '')
  t = t:gsub('^[%s%.]+', ''):gsub('[%s%.]+$', '')
  return t
end

local function is_read_more(item)
  return is_one_of(plain(item.contentDescription), WA.read_more) or is_one_of(plain(item.text), WA.read_more)
end

local function read_more_in(r)
  for _, item in ipairs(r.items) do
    if is_read_more(item) then
      return item
    end
  end
end

-- Whether something in [row] still says "Read more" (in any of the languages).
local MAX_ROW_ITEMS = 120
local function has_read_more(row)
  for _, item in ipairs(row:findAll({}, MAX_ROW_ITEMS)) do
    if is_read_more(item) then
      return true
    end
  end
  return false
end

local EXPAND_ATTEMPTS = 4
local EXPAND_DELAY = 250

-- Each focus is counted, so that a row read after focus moved on isn't said.
local focus_count = 0

-- The last row read, kept for the Actions menu. SandFly waits only 50 milliseconds for the actions
-- of a script, and every call to WhatsApp takes time, so the menu uses what the focus already read.
local cached_row = nil

-- WhatsApp cuts a long message off in the screen's text, so open it and say the whole message.
local function expand(row, list, read_more, count)
  read_more:click()
  local current = row
  for _ = 1, EXPAND_ATTEMPTS do
    sf.sleep(EXPAND_DELAY)
    current = current:refresh() or current
    if not has_read_more(current) then
      break
    end
  end
  local text = describe(read_row(current, list))
  if text and count == focus_count then
    sf.speak(text, { interrupt = true })
  end
end

local expand_long = sf.settings.get('expandLong') ~= false
local send_after_recording = sf.settings.get('sendAfterRecording') ~= false
sf.onSettingChange(function(key, value)
  if key == 'expandLong' then
    expand_long = value ~= false
  elseif key == 'sendAfterRecording' then
    send_after_recording = value ~= false
  end
end)

sf.onWindowChange(function()
  chats = {}
end)

-- Reads the focused row and says it, or what SandFly would have said, [fallback], if it isn't a
-- message.
local function say_row(item, fallback, count)
  local list = list_of(item)
  local r = list and read_row(item, list)
  if r then
    cached_row = { node = item, r = r }
  end
  local read_more = r and expand_long and read_more_in(r)
  if read_more then
    expand(item, list, read_more, count)
    return
  end
  local text = r and describe(r) or fallback
  if count == focus_count and present(text) then
    sf.speak(text, { interrupt = true })
  end
end

-- Starting to record a voice message by tapping the microphone, not holding it, puts SandFly focus
-- on the Pause button of the recording. Focus goes to Send instead.
--
-- It is told by where focus comes from, not by the tap: the click event of the tap is queued behind
-- the speech hook, so the hook can't count on having seen it. Focus that lands on Pause from
-- anywhere but Send or Pause itself is the recording starting. When you swipe back from Send to Pause
-- yourself, focus comes from Send, and Pause keeps it.
local REDIRECT_GAP = 3 -- seconds in which focus that lands on Pause again is left alone
local SEND_TRIES = 4
local SEND_RETRY_MS = 200
local KEEP_CHECKS = 2
local KEEP_CHECK_MS = 350
local last_redirect = -1000
local previous_kind = '' -- what focus was on before: 'pause', 'send' or '' for anything else
local quiet_send = false -- true while the script puts focus on Send: Send isn't said then

-- 'pause' for the Pause button of a recording, 'send' for the Send button, '' for anything else.
-- The Pause of a voice message in the chat, control_btn, is not the recording's.
local function kind_of(item, text)
  if short_id(item) == 'control_btn' then
    return ''
  end
  local id = lower(short_id(item))
  local name = lower(present(item.contentDescription) or present(item.text) or text)
  if id == 'send' then
    return 'send'
  end
  for _, send in ipairs(WA.send) do
    if name == lower(send) then
      return 'send'
    end
  end
  if item.clickable or item.role == 'button' then
    if id:find('pause', 1, true) then
      return 'pause'
    end
    for _, prefix in ipairs(WA.pause) do
      if name:sub(1, #prefix) == prefix then
        return 'pause'
      end
    end
  end
  return ''
end

local function find_send()
  local send = sf.screen.find({ id = 'send' })
  for _, name in ipairs(WA.send) do
    send = send or sf.screen.find({ contentDescription = name })
  end
  return send
end

-- Moves focus to Send, looking for it a few times, since the recording's screen may not be ready.
-- When it can't, says what SandFly would have said for the Pause button. Afterwards checks that
-- focus stayed on Send, and puts it back if WhatsApp moved it to Pause again.
local function do_go_to_send(item, text, count)
  local moved = false
  for attempt = 1, SEND_TRIES do
    if count ~= focus_count then
      return
    end
    local ok, send = pcall(find_send)
    if ok and send then
      last_redirect = os.time()
      quiet_send = true -- focus lands on Send without Send being said
      moved = send:focus() and true or false
      break
    end
    if attempt < SEND_TRIES then
      sf.sleep(SEND_RETRY_MS)
    end
  end
  if not moved then
    print('Send button not found or not focusable; staying on Pause')
    if count == focus_count and present(text) then
      sf.speak(text, { interrupt = true })
    end
    return
  end
  for _ = 1, KEEP_CHECKS do
    sf.sleep(KEEP_CHECK_MS)
    local focused = sf.screen.focused()
    if not focused or kind_of(focused, '') ~= 'pause' then
      return
    end
    local ok, send = pcall(find_send)
    if ok and send then
      send:focus()
    end
  end
end

local function go_to_send(item, text, count)
  local ok, err = pcall(do_go_to_send, item, text, count)
  quiet_send = false
  if not ok then
    print('Moving focus to Send failed: ' .. tostring(err))
  end
end

sf.onFocus(function(item, text)
  focus_count = focus_count + 1
  -- Only the id is looked at here, which needs no call to WhatsApp.
  if short_id(item):sub(1, 17) ~= 'conversation_row_' then
    local kind = kind_of(item, text)
    local before = previous_kind
    previous_kind = kind
    if kind == 'send' and quiet_send then
      return false
    end
    if kind == 'pause' and send_after_recording and before == '' and os.time() - last_redirect > REDIRECT_GAP then
      -- Pause isn't said now; go_to_send says it if focus can't go to Send.
      sf.setTimeout(go_to_send, 0, item, text, focus_count)
      return false
    end
    return
  end
  previous_kind = ''
  -- sf.run would start reading at once, inside onFocus's time, and SandFly turns the script off
  -- when it runs out of time again and again. A timer reads the row once onFocus has returned.
  sf.setTimeout(say_row, 0, item, text, focus_count)
  return false
end)

-- Moves a voice message back or forward with a gesture. WhatsApp's seek bar only moves a message that
-- is paused, by its own step, so a message that is playing is paused, moved and played again; whether
-- it is playing is told by the bar moving on its own a moment apart.
local PLAY_PROBE_DELAY = 80
local TOGGLE_DELAY = 200

local function seek(node, list, forward, count)
  local r = read_row(node, list)
  local seek_bar = first(r, 'audio_seekbar')
  if not seek_bar then
    sf.playSound('beep')
    return
  end
  local control = first(r, 'control_btn')
  local playing = false
  local before = seek_bar.range and seek_bar.range.current
  if control and before then
    sf.sleep(PLAY_PROBE_DELAY)
    seek_bar = seek_bar:refresh() or seek_bar
    local after = seek_bar.range and seek_bar.range.current
    playing = after ~= nil and after > before
  end
  if playing then
    control:click()
    sf.sleep(TOGGLE_DELAY)
  end
  if forward then
    seek_bar:scrollForward()
  else
    seek_bar:scrollBackward()
  end
  sf.sleep(TOGGLE_DELAY)
  if playing then
    control:click()
  end
  seek_bar = seek_bar:refresh() or seek_bar
  local range = seek_bar.range
  if range and count == focus_count then
    sf.speak(string.format('%d s', math.floor(range.current / 1000)), { interrupt = true })
  end
end

-- Returns false when the focus isn't on a voice message, so that the gesture does what it always
-- does (SandFly's own, or the app's).
local function on_seek_gesture(event, forward)
  local node = event and event.node or sf.screen.focused()
  if not node then
    return false
  end
  local r = cached_row and cached_row.node == node and cached_row.r
  if not r then
    local list = list_of(node)
    if not list then
      return false
    end
    r = read_row(node, list)
    cached_row = { node = node, r = r }
  end
  if not first(r, 'audio_seekbar') then
    return false
  end
  sf.setTimeout(seek, 0, node, r.list, forward, focus_count)
end

sf.onCommand('audioForward', function(event) return on_seek_gesture(event, true) end)
sf.onCommand('audioBackward', function(event) return on_seek_gesture(event, false) end)

-- A double tap on a document message opens the document. SandFly presses the first thing in the row
-- that can be pressed, and that is the Forward button beside the document. The document is the
-- biggest thing in the row that can be pressed; the buttons around it are small.
local DOCUMENT_MIN_SHARE = 0.2 -- of the row's area

local function area_of(item)
  local b = item.bounds
  if not b then
    return 0
  end
  return math.max(0, b.right - b.left) * math.max(0, b.bottom - b.top)
end

local function document_target(r)
  local best, best_area
  for _, item in ipairs(r.items) do
    if item.clickable and item ~= r.node then
      local area = area_of(item)
      if area > 0 and (not best_area or area > best_area) then
        best, best_area = item, area
      end
    end
  end
  if best and best_area >= DOCUMENT_MIN_SHARE * area_of(r.node) then
    return best
  end
end

local function open_document(target)
  if not target:click() then
    target:tap()
  end
end

-- A double tap on a voice message presses the first thing in the row that can be pressed, and that is
-- not always the play button: the quoted message of a reply is above it, and the Forward button of a
-- message that you sent is on its left. The play button (or the download one, before the message is
-- downloaded) is what the double tap should press.
local function voice_target(r)
  if not (first(r, 'audio_seekbar') or voice_of(r)) then
    return nil
  end
  local control = first(r, 'control_btn')
  return control and control.clickable and control or nil
end

-- Returns false for anything that isn't a document or a voice message, so every other
-- double tap does what it always does. A row that focus already read costs no call to WhatsApp.
sf.onCommand('openDocument', function(event)
  local node = event and event.node
  if not node then
    return false
  end
  local id = short_id(node)
  if id:sub(1, 17) ~= 'conversation_row_' then
    return false
  end
  local r = cached_row and cached_row.node == node and cached_row.r
  if not r then
    local list = list_of(node)
    if not list then
      return false
    end
    r = read_row(node, list)
    cached_row = { node = node, r = r }
  end
  local target
  if id == 'conversation_row_document' then
    target = document_target(r)
  else
    target = voice_target(r)
  end
  if not target then
    return false
  end
  sf.setTimeout(open_document, 0, target)
end)

-- A three-finger tap presses "Read more" of the focused message, and says the whole message. Without
-- a "Read more" in the message it returns false, so the gesture does what it always does.
sf.onCommand('readMore', function(event)
  local node = event and event.node
  if not node or short_id(node):sub(1, 17) ~= 'conversation_row_' then
    return false
  end
  local r = cached_row and cached_row.node == node and cached_row.r
  local list = r and r.list or list_of(node)
  if not list then
    return false
  end
  if not r then
    r = read_row(node, list)
    cached_row = { node = node, r = r }
  end
  local read_more = read_more_in(r)
  if not read_more then
    return false
  end
  sf.setTimeout(expand, 0, node, list, read_more, focus_count)
end)

local SKIPPED_BUTTONS = {
  name_in_group = true, contact_photo_view = true, url_layout = true, poll_option_vote_checkbox = true,
  info = true,
}

-- downloading is true while the row has a Download button, so its photo isn't there yet.
-- The text of a button. With the row already read, it comes from the items that were read: the button's
-- own text, or that of the first item inside it that has one. Without it, WhatsApp is asked.
local function name_of(button, r)
  if not r then
    return label_of(button)
  end
  local own = clean(present(button.contentDescription) or button.text)
  if own ~= '' then
    return own
  end
  local a = button.bounds
  for _, candidate in ipairs(r.items) do
    local b = candidate.bounds
    if candidate ~= button and a and b and b.left >= a.left and b.right <= a.right
        and b.top >= a.top and b.bottom <= a.bottom then
      local label = clean(present(candidate.contentDescription) or candidate.text)
      if label ~= '' then
        return label
      end
    end
  end
  return ''
end

local function title_of(button, downloading, r)
  local id = short_id(button)
  if id == 'bubble_quoted_message_frame' then
    return tr('Go to replied message')
  elseif id == 'reactions_bubble_layout' then
    return tr('View reactions')
  elseif id == 'link_preview_frame' then
    return tr('Open link')
  elseif id == 'poll_option_main_layout' then
    return tr('Vote') .. ': ' .. name_of(button, r)
  elseif id == 'image' then
    return downloading and '' or tr('Open photo')
  elseif id == 'polls_main_layout' then
    local label = name_of(button, r)
    return is_one_of(label, WA.enlarge) and label or ''
  elseif id == 'control_btn' then
    return (button.className or ''):sub(-11) == 'ImageButton' and name_of(button, r) or tr('Download')
  elseif SKIPPED_BUTTONS[id] then
    return ''
  end
  local label = name_of(button, r)
  return label:find('^https?://') and tr('Open link') or label
end

-- The label of an item's click action, where the app gave it one, such as "view profile".
local ACTION_CLICK = 16
local function click_label(item)
  for _, action in ipairs(item.actions or {}) do
    if action.id == ACTION_CLICK and action.label ~= 'click' then
      return (clean(action.label):gsub('^%l', string.upper))
    end
  end
  return ''
end

local MAX_CHAT_ITEMS = 20

-- A chat in the chats list, whose photo, hidden by the rules, opens the contact's or group's
-- profile. The action has the name WhatsApp gives the photo, in WhatsApp's language. A community's
-- photo can't be clicked itself; the frame around it can.
local function chat_actions(row)
  local photo, frame
  for _, item in ipairs(row:findAll({}, MAX_CHAT_ITEMS)) do
    local id = short_id(item)
    if id == 'contact_photo' or id == 'parent_stack_photo' then
      photo = photo or item
    elseif id == 'contact_selector' then
      frame = frame or item
    end
  end
  local target = photo and photo.clickable and photo or frame
  if not target then
    return
  end
  local title = present(click_label(target))
    or (photo and (present(click_label(photo)) or present(clean(photo.contentDescription))))
    or tr('View profile')
  return {
    {
      title = title,
      run = function()
        if not target:click() then
          target:tap()
        end
      end,
    },
  }
end

-- Names of the standard Android actions, which SandFly lists on their own, without spaces and in
-- lower case. A custom action named like one of them isn't listed twice.
local STANDARD_ACTIONS = {}
for name in ([[click longclick scrollforward scrollbackward expand collapse dismiss copy cut paste select
  clearselection focusinput clearfocus showonscreen scrollup scrolldown scrollleft scrollright pageup
  pagedown pageleft pageright contextclick imeenter pressandhold showtooltip hidetooltip
  showtextsuggestions setselection settext setprogress scrolltoposition]]):gmatch('%S+') do
  STANDARD_ACTIONS[name] = true
end
local ACTION_LONG_CLICK = 32

local function upper_first(text)
  return (text:gsub('^%l', string.upper))
end

-- The actions WhatsApp gives the message, such as Reply, Forward and Share, wherever in the row they
-- are: this script hides the buttons of a row, and with them the place they may be on, so the row is
-- searched for them. Each has the number of the action and the item that has it.
local function native_actions_of(r)
  local found, seen = {}, {}
  for _, node in ipairs(r.items) do
    for _, action in ipairs(node.actions or {}) do
      local label = clean(action.label or '')
      local key = label:lower():gsub('[%s_%-]', '')
      if label ~= '' and action.id ~= ACTION_CLICK and action.id ~= ACTION_LONG_CLICK
          and not STANDARD_ACTIONS[key] and not seen[key] then
        seen[key] = true
        found[#found + 1] = { title = upper_first(label), node = node, id = action.id, label = label }
      end
    end
  end
  return found
end

local function inside(inner, outer)
  local a, b = inner.bounds, outer.bounds
  return a and b and a.left >= b.left and a.right <= b.right and a.top >= b.top and a.bottom <= b.bottom
end

-- Whether the button holds the picture or the initials of a contact in a group chat.
local function is_profile_button(r, button)
  for _, id in ipairs({ 'group_profile_initials', 'group_profile_pic' }) do
    for _, found in ipairs(r.by_id[id] or {}) do
      if inside(found, button) then
        return true
      end
    end
  end
  return false
end

local function message_actions(item, r)
  local actions, titles = {}, {}
  local function add(title, run)
    local key = title:lower()
    if title ~= '' and not titles[key] then
      titles[key] = true
      actions[#actions + 1] = { title = title, run = run }
    end
  end

  -- What the app itself offers for the message comes first.
  for _, native in ipairs(native_actions_of(r)) do
    add(native.title, function()
      local node = native.node:refresh() or native.node
      -- By its number first; by its name if that fails. An item that is gone raises an error.
      local ok, done = pcall(function() return node:perform(native.id) end)
      if not (ok and done) then
        ok, done = pcall(function() return node:perform(native.label) end)
      end
      if not (ok and done) then
        sf.speak(tr('That action is not available'), { interrupt = true })
      end
    end)
  end

  local buttons = {}
  for _, candidate in ipairs(r.items) do
    if candidate.clickable and #buttons < MAX_BUTTONS then
      buttons[#buttons + 1] = candidate
    end
  end
  local downloading = false
  for _, button in ipairs(buttons) do
    if short_id(button) == 'control_btn' and (button.className or ''):sub(-11) ~= 'ImageButton' then
      downloading = true
    end
  end
  for _, button in ipairs(buttons) do
    if button ~= item and not is_profile_button(r, button) then
      add(title_of(button, downloading, r), function()
        if not button:click() then
          button:tap()
        end
      end)
    end
  end
  return actions
end

sf.onActions(function(item)
  if short_id(item) == 'contact_row_container' then
    return chat_actions(item)
  end
  -- The row that focus read, if it is this one; otherwise one search reads it now.
  local r = cached_row and cached_row.node == item and cached_row.r
  if not r then
    local list = list_of(item)
    if not list then
      return
    end
    r = read_row(item, list)
    cached_row = { node = item, r = r }
  end
  return message_actions(item, r)
end)
