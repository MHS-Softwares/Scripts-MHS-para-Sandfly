local manifest = {
  id = 'whatsapp-messages-mhs',
  name = 'WhatsApp messages (MHS)',
  version = '4.9.3',
  author = 'Aaron Hewitt, adapted by Michel Henrique',
  minApiVersion = 6,
  testedApiVersion = 6,
  description = 'Reads each message in a WhatsApp chat as one item: sender, content, the message it replies to, and time. Play, playback speed and the other buttons in a message are in its Actions menu. In the chats list, swiping skips each chat\'s photo, which opens the profile from the chat\'s Actions menu. The actions WhatsApp gives a message, such as reply, forward and share, are in its Actions menu too. On a voice message, a two-finger swipe right advances it and a two-finger swipe left rewinds it; elsewhere those gestures do what they always do. After you start recording a voice message without holding the microphone, focus goes to Send instead of Pause, without Send being said. A double tap on a document message opens the document instead of pressing Forward, and on a video message plays it, or downloads it if it was not downloaded, even when WhatsApp gives the message no name. It also works in the album of photos and videos of a chat. In the player of a video, the progress of the video is not said while it plays. A three-finger tap presses Read more on the focused message and says the whole message. The microphone button says only Record, and its instructions only when usage hints are on. In the Actions menu of a message, each link, e-mail address and phone number in it can also be copied. WhatsApp has a bug: sometimes you open a chat with many unread messages and it takes you to messages from several days ago, before the unread ones. The command Find the unread messages line fixes that: it scrolls the chat, in whichever direction it takes, until it finds the line that says how many messages are unread, even when that line is far from the screen, and puts the focus on it. The command Go to the last message jumps to the end of the chat and puts the focus on the newest message, so the focus does not go back to where it was. Neither has a gesture until you assign one in Settings > Commands > Scripts. While a voice message plays, the focus goes to it, and the screen stays on, because WhatsApp stops playing when the screen turns off; each has a switch in the settings, and the screen timeout you had comes back when the playback ends. SandFly needs to be allowed to modify system settings for that. In the Actions menu of a reply, Go to replied message moves the focus to the original message and reads it. Works with WhatsApp in English and in Brazilian Portuguese.',
  apps = {
    { package = 'com.whatsapp', activity = 'Conversation' },
    { package = 'com.whatsapp', activity = 'HomeActivity' },
    { package = 'com.whatsapp.w4b', activity = 'Conversation' },
    { package = 'com.whatsapp.w4b', activity = 'HomeActivity' },
    { package = 'com.whatsapp', activity = 'MediaAlbumActivity' },
    { package = 'com.whatsapp.w4b', activity = 'MediaAlbumActivity' },
    { package = 'com.whatsapp', activity = 'MediaViewActivity' },
    { package = 'com.whatsapp.w4b', activity = 'MediaViewActivity' },
  },
  permissions = { 'screen', 'actions', 'speech', 'input', 'clipboard', 'system' },
  settings = {
    { key = 'expandLong', type = 'switch', title = 'Expand long messages', default = true },
    { key = 'sendAfterRecording', type = 'switch', title = 'Focus Send when a voice message recording starts', default = true },
    { key = 'followPlayingMessage', type = 'switch', title = 'Move the focus to the voice message that is playing', default = true },
    { key = 'keepScreenOnWhilePlaying', type = 'switch', title = 'Keep the screen on while a voice message plays', default = true },
    { key = 'repliedWaitMs', type = 'number', title = 'How long to wait for WhatsApp to scroll before looking for the replied message, in milliseconds', default = 250 },
  },
  commands = {
    { id = 'audioForward', title = 'Advance voice message', gesture = 'twoFingerSwipeRight' },
    { id = 'audioBackward', title = 'Rewind voice message', gesture = 'twoFingerSwipeLeft' },
    { id = 'openDocument', title = 'Open document', gesture = 'doubleTap' },
    { id = 'readMore', title = 'Read more', gesture = 'threeFingerTap' },
    { id = 'voiceSpeed', title = 'Change the voice message speed' },
    { id = 'lastMessage', title = 'Go to the last message' },
    { id = 'unreadLine', title = 'Find the unread messages line' },
  },
  rules = {
    { match = { parentId = 'list', className = 'ViewGroup' }, group = true, activity = 'Conversation' },
    -- The album of photos and videos of a chat: each one is a row of the same kind, read as one item.
    { match = { parentId = 'list', className = 'ViewGroup' }, group = true, activity = 'MediaAlbumActivity' },
    {
      match = { clickable = true, inside = { parentId = 'list', className = 'ViewGroup' } },
      hide = 'all',
      activity = 'MediaAlbumActivity',
    },
    -- The microphone button says only Record. Its instructions are the usage hint, which SandFly says
    -- only while usage hints are on.
    { id = 'voice_note_btn', label = 'Record', role = 'button', hint = 'Double tap and hold to record, swipe left to cancel the recording, swipe up to record hands-free. Release to send.', activity = 'Conversation' },
    -- A double tap on a photo message opens the photo, not the row.
    { id = 'conversation_row_image', activate = { id = 'image' }, activity = 'Conversation' },
    {
      match = { clickable = true, inside = { parentId = 'list', className = 'ViewGroup' } },
      hide = 'all',
      activity = 'Conversation',
    },
    {
      match = { className = 'SeekBar', inside = { parentId = 'list', className = 'ViewGroup' } },
      hide = true,
      silence = true,
      activity = 'Conversation',
    },
    -- A voice message's time, which counts up each second while it plays.
    {
      match = { id = 'description', inside = { parentId = 'list', className = 'ViewGroup' } },
      silence = true,
      activity = 'Conversation',
    },
    -- The player of a video: the progress bar and the time that counts up are not said while the video plays. They are said
    -- when they have the focus.
    { id = 'mediacontroller_progress', silence = true, activity = 'MediaViewActivity' },
    { id = 'time_current', silence = true, activity = 'MediaViewActivity' },
    -- The photo of each chat in the chats list and the Communities tab. It is in the chat's
    -- Actions menu instead.
    { match = { id = 'contact_selector', parentId = 'contact_row_container' }, hide = 'all', activity = 'HomeActivity' },
    { match = { id = 'contact_photo', parentId = 'contact_row_container' }, hide = true, activity = 'HomeActivity' },
  },
}

local tr = sf._

-- What WhatsApp itself writes in a message, in English and in Brazilian Portuguese. The script finds
-- these in the text of the screen, so each has the texts of every language it knows. The comparisons
-- ignore case where noted.
local WA = {
  voice_marks = { ', voice message', ', mensagem de voz', ', audio message', ', mensagem de áudio',
                  ', mensagem de audio' },
  poll_from = { 'Poll from ', 'Enquete de ', 'Enquete criada por ' },
  elapsed = { '^Voice message, (.*) elapsed$', '^Mensagem de voz, (.*) decorridos?$',
              '^Mensagem de voz, (.*) transcorridos?$', '^Mensagem de voz, (.*) reproduzidos?$' },
  zero_elapsed = { ['0 seconds'] = true, ['0 segundos'] = true, ['0 segundo'] = true },
  enlarge = { 'enlarge photo', 'ampliar foto' },
  photo_words = { 'photo', 'foto' },
  read_more = { 'read more', 'ler mais', 'leia mais' },
  -- The Pause button of a recording that is locked, and the Send button.
  pause = { 'pause', 'pausar' },
  send = { 'Send', 'Enviar' },
  -- The playback speed button of a voice message, as WhatsApp names it.
  speed = { 'velocidade de reprodu', 'playback speed' },
  -- What the picture of a video that is not downloaded says: it is the Download button.
  download = { 'baixar', 'download' },
  -- What the button that plays a downloaded video says. Its id is not always the same: in a group it is "cancel_download".
  play_video = { 'reproduzir', 'play' },
}

local function lower(text)
  return (text or ''):lower()
end

local function is_one_of(text, candidates)
  text = lower(text)
  for _, candidate in ipairs(candidates) do
    if text == candidate then
      return true
    end
  end
  return false
end

-- The first of [marks] found in [text], and where.
local function earliest(text, marks)
  local at
  for _, mark in ipairs(marks) do
    local found = text:find(mark, 1, true)
    if found and (not at or found < at) then
      at = found
    end
  end
  return at
end

-- A message row is read with one search, which gives the row and everything in it, so that the
-- rest of the script looks things up in the script instead of asking WhatsApp again. Every call
-- to the app takes time, more than the 30 milliseconds SandFly waits for onFocus, so the row is
-- read after onFocus returns and said when it is ready.
local MAX_ROW_ITEMS = 200
local MAX_BUTTONS = 24
local MAX_OPTIONS = 20
local MAX_REACTIONS = 8
local MAX_NOTICES = 5
local LABEL_DEPTH = 3
local MAX_BUBBLE_ITEMS = 60
local MAX_BUBBLE_TEXTS = 6

local function present(text)
  if text ~= nil and text ~= '' then
    return text
  end
end

-- Joins the parts that aren't nil, false or empty.
local function join(parts, separator)
  local kept = {}
  for i = 1, parts.n or #parts do
    local part = parts[i]
    if part and part ~= '' then
      kept[#kept + 1] = part
    end
  end
  return table.concat(kept, separator)
end

local function short_id(item)
  return (item.id or ''):match('[^/]*$')
end

-- Removes the direction marks WhatsApp adds, U+200B to U+200F, U+202A to U+202E and U+2066 to
-- U+2069, and the "~" before a name the contact list doesn't have.
local function clean(text)
  text = (text or ''):gsub('\226\128[\139-\143\170-\174]', '')
  text = text:gsub('\226\129[\166-\169]', '')
  -- The narrow no-break space after the "~", U+202F.
  text = text:gsub('\226\128\175', ' ')
  text = text:match('^%s*(.-)%s*$')
  text = text:gsub('^~%s*', '')
  return (text:match('^%s*(.-)%s*$'))
end

-- Some rows of a chat have no id (a video that is not downloaded, in a group, for one): they are known by what a row
-- is, with no call to WhatsApp: a group of views with no id that can be long-pressed and not pressed.
local function looks_like_row(item)
  return short_id(item) == '' and (item.className or ''):find('ViewGroup$') ~= nil
    and item.longClickable == true and not item.clickable
end

-- Gives the list of messages that the row is in, or nil if the item isn't a message row.
local function list_of(item)
  if short_id(item):sub(1, 17) ~= 'conversation_row_' and not looks_like_row(item) then
    return nil
  end
  local parent = item:parent()
  if parent and (parent.id or ''):sub(-5) == '/list' then
    return parent
  end
end

-- The row and everything in it, by short id.
local function read_row(row, list)
  local items = row:findAll({}, MAX_ROW_ITEMS)
  local by_id = {}
  for _, item in ipairs(items) do
    local id = short_id(item)
    if id ~= '' then
      local found = by_id[id]
      if not found then
        found = {}
        by_id[id] = found
      end
      found[#found + 1] = item
    end
  end
  return { node = row, list = list, items = items, by_id = by_id }
end

local function first(r, id)
  local found = r.by_id[id]
  return found and found[1]
end

local function all_of(r, id, limit)
  local found = r.by_id[id] or {}
  local result = {}
  for i = 1, math.min(#found, limit) do
    result[i] = found[i]
  end
  return result
end

local function text_in(r, id)
  local found = first(r, id)
  return found and clean(found.text) or ''
end

local function main_of(r)
  return first(r, 'main_layout') or first(r, 'polls_main_layout')
end

-- Sent messages have a delivery status and sit against the right edge.
local function is_outgoing(r)
  if first(r, 'status') then
    return true
  end
  local main = main_of(r)
  local row = r.node
  return main ~= nil and row.bounds.right - main.bounds.right < main.bounds.left - row.bounds.left
end

-- Whether the chat is a group, and the contact's name if not, kept for each chat.
local chats = {}

-- In a chat with one person, the messages from them have no name and no picture.
local function contact_name(list)
  if not list then
    return ''
  end
  local chat = chats[list.handle]
  if not chat then
    local is_group = false
    for _, id in ipairs({ 'name_in_group_tv', 'group_profile_pic', 'group_profile_initials' }) do
      if list:find(id) then
        is_group = true
        break
      end
    end
    local title = not is_group and sf.screen.find('conversation_contact_name') or nil
    chat = { name = title and clean(title.text) or '' }
    chats[list.handle] = chat
  end
  return chat.name
end

-- Splits "54 seconds, 09:11, played" into the body, the time and what follows the time.
local function split_time(rest)
  local init = 1
  while true do
    local s, e, time = rest:find(',%s*(%d%d?:%d%d)', init)
    if not s then
      return nil
    end
    local tail = rest:sub(e + 1)
    local ampm = tail:match('^%s?[aApP][mM]')
    if ampm then
      time = time .. ampm
      tail = tail:sub(#ampm + 1)
    end
    if tail == '' then
      return rest:sub(1, s - 1), time, nil
    end
    local state = tail:match('^,%s*(.*)$')
    if state then
      return rest:sub(1, s - 1), time, state
    end
    init = s + 1
  end
end

-- "Alex Smith, voice message, 54 seconds, 09:11" has the sender first, and the time and "played"
-- last. A sound file reads "audio message" instead, and its row also shows the file name.
local function voice_of(r)
  if r.voice == nil then
    r.voice = false
    local main = first(r, 'main_layout')
    local description = main and main.contentDescription or ''
    local at = earliest(description, WA.voice_marks)
    if at then
      local rest = description:sub(at + 2)
      local file = short_id(r.node) == 'conversation_row_audio' and text_in(r, 'description') or ''
      local body, time, state = split_time(rest)
      r.voice = {
        sender = clean(description:sub(1, at - 1)),
        body = join({ body or rest, file }, ', '),
        time = time or '',
        state = state or '',
      }
    end
  end
  return r.voice or nil
end

-- "Poll from Alex Smith, next event.\nSelect one or more\n..."; each option reads "Name, 2 votes".
local function poll_of(r)
  if r.poll == nil then
    r.poll = false
    local main = first(r, 'polls_main_layout')
    if main then
      local name = text_in(r, 'poll_name')
      local description = main.contentDescription or ''
      local end_at = description:find(', ' .. name .. '.', 1, true)
      local parts = { tr('poll') .. ': ' .. name, text_in(r, 'poll_type_text') }
      for _, option in ipairs(all_of(r, 'poll_option_main_layout', MAX_OPTIONS)) do
        local label = clean(option.contentDescription)
        parts[#parts + 1] = option.checked and (tr('selected') .. ' ' .. label) or label
      end
      local sender = ''
      for _, prefix in ipairs(WA.poll_from) do
        if end_at and description:sub(1, #prefix) == prefix then
          sender = clean(description:sub(#prefix + 1, end_at - 1))
          break
        end
      end
      r.poll = { sender = sender, body = join(parts, '. ') }
    end
  end
  return r.poll or nil
end

-- A message from the same sender as the one before it has no name of its own.
local function sender_of(r, depth)
  depth = depth or 3
  local named = text_in(r, 'name_in_group_tv')
  if named ~= '' then
    return named
  end
  local known = (voice_of(r) or poll_of(r) or {}).sender
  if present(known) then
    return known
  end
  if is_outgoing(r) then
    return tr('You')
  end
  if depth > 0 and r.list then
    local rows = r.rows or r.list:children()
    for i, sibling in ipairs(rows) do
      if sibling == r.node then
        local previous = i > 1 and rows[i - 1] or nil
        if previous then
          local p = read_row(previous, r.list)
          p.rows = rows
          if not is_outgoing(p) then
            local name = present(sender_of(p, depth - 1))
            if name then
              return name
            end
          end
        end
        break
      end
    end
  end
  return contact_name(r.list)
end

-- "Voice message, 2 minutes, 33 seconds elapsed"; "0 seconds elapsed" before it has played.
local function elapsed_of(r)
  local seek_bar = first(r, 'audio_seekbar')
  local elapsed
  if seek_bar then
    for _, pattern in ipairs(WA.elapsed) do
      elapsed = (seek_bar.contentDescription or ''):match(pattern)
      if elapsed then
        break
      end
    end
  end
  if elapsed and not WA.zero_elapsed[lower(elapsed)] then
    return elapsed .. ' ' .. tr('elapsed')
  end
  return ''
end

local function label_of(item, depth)
  depth = depth or LABEL_DEPTH
  local own = clean(present(item.contentDescription) or item.text)
  if own ~= '' or depth == 0 then
    return own
  end
  for _, child in ipairs(item:children()) do
    local label = label_of(child, depth - 1)
    if label ~= '' then
      return label
    end
  end
  return ''
end

local function document_of(r)
  if short_id(r.node) ~= 'conversation_row_document' then
    return ''
  end
  local content = first(r, 'content')
  local label = content and label_of(content) or ''
  return label ~= '' and (tr('document') .. ': ' .. label) or tr('document')
end

-- "Enlarge photo", or "Photo 331 kB" before it is downloaded.
local function photo_of(r)
  if short_id(r.node) ~= 'conversation_row_image' then
    return ''
  end
  local image = first(r, 'image')
  local label = clean(image and image.contentDescription)
  if label == '' or is_one_of(label, WA.enlarge) then
    return tr('photo')
  end
  for _, word in ipairs(WA.photo_words) do
    if label:sub(1, #word):lower() == word then
      return tr('photo') .. label:sub(#word + 1)
    end
  end
  return label
end

-- The quote's frame and holder have no text of their own, so Android leaves them out of what a
-- screen reader sees; only the quote's title and text are there.
local function reply_of(r)
  local author = text_in(r, 'quoted_title')
  local quoted = text_in(r, 'quoted_text')
  if author == '' and quoted == '' then
    return ''
  end
  return join({ (tr('in reply to') .. ' ' .. author):match('^%s*(.-)%s*$'), quoted }, ': ')
end

-- A link's preview repeats the link; only a title that isn't the address is worth saying, unless
-- the message is only the link, which WhatsApp then shows as the preview alone.
local function preview_of(r, alone)
  local title = text_in(r, 'title')
  local is_address = title:find('^https?://') or title:find('^www%.')
  local named
  if title ~= '' and not is_address then
    named = title
  elseif alone then
    named = present(text_in(r, 'url')) or title
  end
  if not present(named) then
    return ''
  end
  return tr(first(r, 'play_button') and 'video link' or 'link') .. ': ' .. named
end

-- The time and status are said on their own, so a message of a kind not handled above is read
-- from the rest of the text in its bubble.
local SKIP_IDS = {
  date = true, status = true, name_in_group_tv = true, secondary_name_in_group_tv = true,
  conversation_row_date_divider = true, group_profile_initials = true,
}
local function bubble_text_of(r)
  -- A text message's bubble has nothing to say of its own, so screen readers don't see it.
  local main = main_of(r) or r.node
  local texts, seen = {}, {}
  for _, item in ipairs(main:findAll({}, MAX_BUBBLE_ITEMS)) do
    if #texts >= MAX_BUBBLE_TEXTS then
      break
    end
    if not SKIP_IDS[short_id(item)] then
      local own = clean(present(item.contentDescription) or item.text)
      if own ~= '' and not seen[own] then
        seen[own] = true
        texts[#texts + 1] = own
      end
    end
  end
  return table.concat(texts, ', ')
end

local function reactions_of(r)
  local reactions = {}
  for _, reaction in ipairs(all_of(r, 'reaction_bubble_emoji_text', MAX_REACTIONS)) do
    reactions[#reactions + 1] = clean(reaction.text)
  end
  if #reactions == 0 then
    return ''
  end
  return tr('reactions') .. ' ' .. table.concat(reactions, ' ')
end

-- A video: "Video, 53 MB, not downloaded" before it is downloaded (the picture says Download and the size is the text of
-- the button), and what its picture says, such as "Video, High definition, duration 29 seconds", after.
local function is_video_row(r)
  if short_id(r.node) == 'conversation_row_video' then
    return true
  end
  -- a row with no id: a picture with the button of its size, or the one that plays it, or the details of the media
  if first(r, 'thumb') == nil or first(r, 'media_grid') ~= nil then
    return false
  end
  for _, id in ipairs({ 'control_btn', 'play_button', 'cancel_download', 'video_info_view' }) do
    if first(r, id) ~= nil then
      return true
    end
  end
  return false
end

local function video_of(r)
  if not is_video_row(r) then
    return ''
  end
  local thumb = first(r, 'thumb')
  local label = clean(thumb and thumb.contentDescription)
  if label == '' or is_one_of(label, WA.download) then
    return join({ tr('video'), text_in(r, 'control_btn'), tr('not downloaded') }, ', ')
  end
  return label
end

local function describe(r)
  local voice = voice_of(r)
  local poll = not voice and poll_of(r) or nil
  local body
  if voice then
    body = voice.body
  elseif poll then
    body = poll.body
  else
    local text = present(text_in(r, 'message_text')) or text_in(r, 'caption')
    body = join({ present(document_of(r)) or present(video_of(r)) or photo_of(r), text }, ', ')
  end
  local notices = {}
  for _, info in ipairs(all_of(r, 'info', MAX_NOTICES)) do
    notices[#notices + 1] = clean(info.text)
  end
  local preview = preview_of(r, body == '')
  local other = (body == '' and preview == '') and bubble_text_of(r) or ''
  if body == '' and preview == '' and other == '' then
    return #notices > 0 and table.concat(notices, ', ') or nil
  end
  local status = first(r, 'status')
  local time = voice and voice.time or text_in(r, 'date')
  local state = voice and present(voice.state) or (status and status.contentDescription)
  local parts = table.pack(
    sender_of(r),
    present(body) or present(preview) or other,
    voice and elapsed_of(r),
    first(r, 'edit_label') and tr('edited'),
    body ~= '' and preview,
    reply_of(r),
    reactions_of(r),
    join({ time, state, text_in(r, 'conversation_row_date_divider') }, ', ')
  )
  for _, notice in ipairs(notices) do
    parts.n = parts.n + 1
    parts[parts.n] = notice
  end
  return join(parts, ', ')
end

-- Whether [item] is WhatsApp's "Read more". It may be in the description or in the text, and with an
-- ellipsis or a period at the end, so those are left out of the comparison.
local function plain(text)
  local t = lower(text):gsub('\u{2026}', '')
  t = t:gsub('^[%s%.]+', ''):gsub('[%s%.]+$', '')
  return t
end

local function is_read_more(item)
  return is_one_of(plain(item.contentDescription), WA.read_more) or is_one_of(plain(item.text), WA.read_more)
end

local function read_more_in(r)
  for _, item in ipairs(r.items) do
    if is_read_more(item) then
      return item
    end
  end
end

-- Whether something in [row] still says "Read more" (in any of the languages).
local MAX_ROW_ITEMS = 120
local function has_read_more(row)
  for _, item in ipairs(row:findAll({}, MAX_ROW_ITEMS)) do
    if is_read_more(item) then
      return true
    end
  end
  return false
end

local EXPAND_ATTEMPTS = 4
local EXPAND_DELAY = 250

-- Each focus is counted, so that a row read after focus moved on isn't said.
local focus_count = 0

-- The last row read, kept for the Actions menu. SandFly waits only 50 milliseconds for the actions
-- of a script, and every call to WhatsApp takes time, so the menu uses what the focus already read.
local cached_row = nil

-- WhatsApp cuts a long message off in the screen's text, so open it and say the whole message.
local function expand(row, list, read_more, count)
  read_more:click()
  local current = row
  for _ = 1, EXPAND_ATTEMPTS do
    sf.sleep(EXPAND_DELAY)
    current = current:refresh() or current
    if not has_read_more(current) then
      break
    end
  end
  local text = describe(read_row(current, list))
  if text and count == focus_count then
    sf.speak(text, { interrupt = true })
  end
end

local expand_long = sf.settings.get('expandLong') ~= false
local send_after_recording = sf.settings.get('sendAfterRecording') ~= false
sf.onSettingChange(function(key, value)
  if key == 'expandLong' then
    expand_long = value ~= false
  elseif key == 'sendAfterRecording' then
    send_after_recording = value ~= false
  end
end)

sf.onWindowChange(function()
  chats = {}
end)

-- Reads the focused row and says it, or what SandFly would have said, [fallback], if it isn't a
-- message.
local function say_row(item, fallback, count)
  local list = list_of(item)
  local r = list and read_row(item, list)
  if r then
    cached_row = { node = item, r = r }
  end
  local read_more = r and expand_long and read_more_in(r)
  if read_more then
    expand(item, list, read_more, count)
    return
  end
  local text = r and describe(r) or fallback
  if count == focus_count and present(text) then
    sf.speak(text, { interrupt = true })
  end
end

-- The script runs in every app, to follow the calls even with the screen off. What reads and changes the
-- messages looks at the app of the item first, and leaves every other app alone, with no call to it.
local WHATSAPP_PACKAGES = { ['com.whatsapp'] = true, ['com.whatsapp.w4b'] = true }
local function in_whatsapp(item)
  return item ~= nil and WHATSAPP_PACKAGES[item.packageName] == true
end

-- Starting to record a voice message by tapping the microphone, not holding it, puts SandFly focus
-- on the Pause button of the recording. Focus goes to Send instead.
--
-- It is told by where focus comes from, not by the tap: the click event of the tap is queued behind
-- the speech hook, so the hook can't count on having seen it. Focus that lands on Pause from
-- anywhere but Send or Pause itself is the recording starting. When you swipe back from Send to Pause
-- yourself, focus comes from Send, and Pause keeps it.
local REDIRECT_GAP = 3 -- seconds in which focus that lands on Pause again is left alone
local SEND_TRIES = 4
local SEND_RETRY_MS = 200
local KEEP_CHECKS = 2
local KEEP_CHECK_MS = 350
local last_redirect = -1000
local previous_kind = '' -- what focus was on before: 'pause', 'send' or '' for anything else
local quiet_send = false -- true while the script puts focus on Send: Send isn't said then

-- 'pause' for the Pause button of a recording, 'send' for the Send button, '' for anything else.
-- The Pause of a voice message in the chat, control_btn, is not the recording's.
local function kind_of(item, text)
  if short_id(item) == 'control_btn' then
    return ''
  end
  local id = lower(short_id(item))
  local name = lower(present(item.contentDescription) or present(item.text) or text)
  if id == 'send' then
    return 'send'
  end
  for _, send in ipairs(WA.send) do
    if name == lower(send) then
      return 'send'
    end
  end
  if item.clickable or item.role == 'button' then
    if id:find('pause', 1, true) then
      return 'pause'
    end
    for _, prefix in ipairs(WA.pause) do
      if name:sub(1, #prefix) == prefix then
        return 'pause'
      end
    end
  end
  return ''
end

local function find_send()
  local send = sf.screen.find({ id = 'send' })
  for _, name in ipairs(WA.send) do
    send = send or sf.screen.find({ contentDescription = name })
  end
  return send
end

-- Moves focus to Send, looking for it a few times, since the recording's screen may not be ready.
-- When it can't, says what SandFly would have said for the Pause button. Afterwards checks that
-- focus stayed on Send, and puts it back if WhatsApp moved it to Pause again.
local function do_go_to_send(item, text, count)
  local moved = false
  for attempt = 1, SEND_TRIES do
    if count ~= focus_count then
      return
    end
    local ok, send = pcall(find_send)
    if ok and send then
      last_redirect = os.time()
      quiet_send = true -- focus lands on Send without Send being said
      moved = send:focus() and true or false
      break
    end
    if attempt < SEND_TRIES then
      sf.sleep(SEND_RETRY_MS)
    end
  end
  if not moved then
    print('Send button not found or not focusable; staying on Pause')
    if count == focus_count and present(text) then
      sf.speak(text, { interrupt = true })
    end
    return
  end
  for _ = 1, KEEP_CHECKS do
    sf.sleep(KEEP_CHECK_MS)
    local focused = sf.screen.focused()
    if not focused or kind_of(focused, '') ~= 'pause' then
      return
    end
    local ok, send = pcall(find_send)
    if ok and send then
      send:focus()
    end
  end
end

local function go_to_send(item, text, count)
  local ok, err = pcall(do_go_to_send, item, text, count)
  quiet_send = false
  if not ok then
    print('Moving focus to Send failed: ' .. tostring(err))
  end
end

sf.onFocus(function(item, text)
  if not in_whatsapp(item) then
    return
  end
  focus_count = focus_count + 1
  -- Only the id is looked at here, which needs no call to WhatsApp.
  if short_id(item):sub(1, 17) ~= 'conversation_row_' and not looks_like_row(item) then
    local kind = kind_of(item, text)
    local before = previous_kind
    previous_kind = kind
    if kind == 'send' and quiet_send then
      return false
    end
    if kind == 'pause' and send_after_recording and before == '' and os.time() - last_redirect > REDIRECT_GAP then
      -- Pause isn't said now; go_to_send says it if focus can't go to Send.
      sf.setTimeout(go_to_send, 0, item, text, focus_count)
      return false
    end
    return
  end
  previous_kind = ''
  -- sf.run would start reading at once, inside onFocus's time, and SandFly turns the script off
  -- when it runs out of time again and again. A timer reads the row once onFocus has returned.
  sf.setTimeout(say_row, 0, item, text, focus_count)
  return false
end)

-- Moves a voice message back or forward with a gesture. WhatsApp's seek bar only moves a message that
-- is paused, by its own step, so a message that is playing is paused, moved and played again; whether
-- it is playing is told by the bar moving on its own a moment apart.
local PLAY_PROBE_DELAY = 80
local TOGGLE_DELAY = 200

local function seek(node, list, forward, count)
  local r = read_row(node, list)
  local seek_bar = first(r, 'audio_seekbar')
  if not seek_bar then
    sf.playSound('beep')
    return
  end
  local control = first(r, 'control_btn')
  local playing = false
  local before = seek_bar.range and seek_bar.range.current
  if control and before then
    sf.sleep(PLAY_PROBE_DELAY)
    seek_bar = seek_bar:refresh() or seek_bar
    local after = seek_bar.range and seek_bar.range.current
    playing = after ~= nil and after > before
  end
  if playing then
    control:click()
    sf.sleep(TOGGLE_DELAY)
  end
  if forward then
    seek_bar:scrollForward()
  else
    seek_bar:scrollBackward()
  end
  sf.sleep(TOGGLE_DELAY)
  if playing then
    control:click()
  end
  seek_bar = seek_bar:refresh() or seek_bar
  local range = seek_bar.range
  if range and count == focus_count then
    sf.speak(string.format('%d s', math.floor(range.current / 1000)), { interrupt = true })
  end
end

-- Returns false when the focus isn't on a voice message, so that the gesture does what it always
-- does (SandFly's own, or the app's).
local function on_seek_gesture(event, forward)
  local node = event and event.node or sf.screen.focused()
  if not in_whatsapp(node) then
    return false
  end
  local r = cached_row and cached_row.node == node and cached_row.r
  if not r then
    local list = list_of(node)
    if not list then
      return false
    end
    r = read_row(node, list)
    cached_row = { node = node, r = r }
  end
  if not first(r, 'audio_seekbar') then
    return false
  end
  sf.setTimeout(seek, 0, node, r.list, forward, focus_count)
end

sf.onCommand('audioForward', function(event) return on_seek_gesture(event, true) end)
sf.onCommand('audioBackward', function(event) return on_seek_gesture(event, false) end)

-- A double tap on a document message opens the document. SandFly presses the first thing in the row
-- that can be pressed, and that is the Forward button beside the document. The document is the
-- biggest thing in the row that can be pressed; the buttons around it are small.
local DOCUMENT_MIN_SHARE = 0.2 -- of the row's area

local function area_of(item)
  local b = item.bounds
  if not b then
    return 0
  end
  return math.max(0, b.right - b.left) * math.max(0, b.bottom - b.top)
end

local function document_target(r)
  local best, best_area
  for _, item in ipairs(r.items) do
    if item.clickable and item ~= r.node then
      local area = area_of(item)
      if area > 0 and (not best_area or area > best_area) then
        best, best_area = item, area
      end
    end
  end
  if best and best_area >= DOCUMENT_MIN_SHARE * area_of(r.node) then
    return best
  end
end

local function open_document(target)
  if not target:click() then
    target:tap()
  end
end

-- A double tap on a voice message presses the first thing in the row that can be pressed, and that is
-- not always the play button: the quoted message of a reply is above it, and the Forward button of a
-- message that you sent is on its left. The play button (or the download one, before the message is
-- downloaded) is what the double tap should press.
local function voice_target(r)
  if not (first(r, 'audio_seekbar') or voice_of(r)) then
    return nil
  end
  local control = first(r, 'control_btn')
  return control and control.clickable and control or nil
end

-- With the reading control on Actions, swiping up or down says the name of an action, and a double tap does that action.
-- The double tap is a command of this script (it plays a voice message and opens a document), so it would play or pause
-- the message instead of doing the action that was chosen. SandFly does not say which reading control is on, so it is told
-- by what SandFly says: the name of one of the actions of the message, after focus last moved, means one was chosen, and
-- the double tap is left to SandFly until focus moves again.
local action_titles = {}
local action_said_at = nil

sf.onSpeech(function(text)
  if type(text) ~= 'string' or text == '' then
    return
  end
  for title in pairs(action_titles) do
    if text:sub(1, #title) == title then
      action_said_at = focus_count
      return
    end
  end
end)

-- A double tap on a video presses what plays it: the play button, or, before the video is downloaded, the button that
-- downloads it. Without either, the biggest thing in the row that can be pressed, which is the picture of the video.
-- The row itself cannot be pressed, and the first thing in it that can is the "Forwarded" label, so by default the double
-- tap did nothing.
local function video_target(r)
  local thumb = first(r, 'thumb')
  local order = { 'play_button', 'control_btn' }
  if thumb and is_one_of(clean(thumb.contentDescription), WA.download) then
    -- not downloaded: the button of the size downloads it, and so does the picture, which says Download
    order = { 'control_btn', 'thumb' }
  end
  -- a downloaded video: the button that says it plays, by its id or, when the id is another, by what it says
  if order[1] == 'play_button' then
    for _, item in ipairs(r.items) do
      local words = lower(clean(item.contentDescription))
      if item.clickable and words ~= '' then
        for _, word in ipairs(WA.play_video) do
          if words:sub(1, #word) == word then
            return item
          end
        end
      end
    end
  end
  for _, id in ipairs(order) do
    local button = first(r, id)
    if button and button.clickable then
      return button
    end
  end
  return document_target(r)
end

-- Returns false for anything that isn't a document, a video or a voice message, so every other
-- double tap does what it always does. A row that focus already read costs no call to WhatsApp.
sf.onCommand('openDocument', function(event)
  if action_said_at == focus_count then
    return false
  end
  local node = event and event.node
  if not in_whatsapp(node) then
    return false
  end
  local id = short_id(node)
  if id:sub(1, 17) ~= 'conversation_row_' and not looks_like_row(node) then
    return false
  end
  local r = cached_row and cached_row.node == node and cached_row.r
  if not r then
    local list = list_of(node)
    if not list then
      return false
    end
    r = read_row(node, list)
    cached_row = { node = node, r = r }
  end
  local target
  if id == 'conversation_row_document' then
    target = document_target(r)
  elseif is_video_row(r) then
    target = video_target(r)
  else
    target = voice_target(r)
  end
  if not target then
    return false
  end
  sf.setTimeout(open_document, 0, target)
end)

-- A three-finger tap presses "Read more" of the focused message, and says the whole message. Without
-- a "Read more" in the message it returns false, so the gesture does what it always does.
sf.onCommand('readMore', function(event)
  local node = event and event.node
  if not in_whatsapp(node) or short_id(node):sub(1, 17) ~= 'conversation_row_' then
    return false
  end
  local r = cached_row and cached_row.node == node and cached_row.r
  local list = r and r.list or list_of(node)
  if not list then
    return false
  end
  if not r then
    r = read_row(node, list)
    cached_row = { node = node, r = r }
  end
  local read_more = read_more_in(r)
  if not read_more then
    return false
  end
  sf.setTimeout(expand, 0, node, list, read_more, focus_count)
end)

-- ======== Chats with many unread messages: the last message and the line of the unread ones ========
-- WhatsApp opens a chat with many unread messages days before them, and its button for the last message
-- moves the list but SandFly focus goes back to where it was. These two commands scroll the list and put the
-- focus where it should be themselves. They have no gesture: they are assigned in Settings > Commands > Scripts.
local UNREAD_WORDS = { 'mensagens não lidas', 'mensagem não lida', 'unread messages', 'unread message' }
local UNREAD_MAX_LENGTH = 100 -- characters: the line says "Mensagens não lidas: 16 toque duas vezes para resumir com IA"; a longer text is a message that says so
local FAST_STEPS = 400 -- scrolls of the fast run to the newest message
local FAST_PAUSE = 40 -- ms between one scroll and the next look
local BRING_WAIT = 250 -- ms for the list to stop after the run, before the line is looked for
local SCAN_STEPS_BACK = 250 -- pages looked at from the newest message toward the oldest
local SCAN_WAIT = 450 -- ms for the list to settle after the jump to the end
local SCAN_POLL = 50 -- ms between looks while a page scrolls
local SCAN_MAX_WAIT = 700 -- the most ms to wait for one page
local LAST_TRIES = 4
local FOCUS_WAIT = 600

local function say_now(text)
  sf.speak(text, { interrupt = true })
end

-- The list of messages of the chat that is open, or nil in any other screen.
local function chat_list()
  local ok, list = pcall(sf.screen.find, { id = 'list' })
  if not ok or not list then
    return nil
  end
  local ok_kids, kids = pcall(list.children, list)
  for _, kid in ipairs(ok_kids and kids or {}) do
    if short_id(kid):sub(1, 17) == 'conversation_row_' then
      return list
    end
  end
  local ok_entry, entry = pcall(sf.screen.find, { id = 'entry' })
  if ok_entry and entry then
    return list
  end
  return nil
end

-- What gets the focus for an item of the list: the item itself or the nearest item around it that can take the focus
-- (the line of the unread messages is a text inside a button); without one, the row of the list it is in.
local function focus_target(item)
  local node = item
  local row
  for _ = 1, 6 do
    if node.focusable == true then
      return node
    end
    local ok, parent = pcall(node.parent, node)
    if not ok or not parent then
      return row or item
    end
    if (parent.id or ''):sub(-5) == '/list' then
      row = node
      break
    end
    node = parent
  end
  return row or item
end

local function text_length(item)
  local text = item.text
  if text == nil or text == '' then
    text = item.contentDescription
  end
  text = text or ''
  return utf8.len(text) or #text
end

-- Lower case for the letters A to Z only: string.lower can damage the bytes of accented letters.
local function ascii_lower(text)
  return (text:gsub('[A-Z]', function(letter) return string.char(letter:byte() + 32) end))
end

-- Does this item look like the line of the unread messages? Its id has "unread" in it ("unread_divider_tv"), or it is a
-- short text that says so.
local function is_unread_line(item, by_id_only)
  local text = item.text
  if text == nil or text == '' then
    text = item.contentDescription
  end
  if text == nil or text == '' or text_length(item) > UNREAD_MAX_LENGTH then
    return false
  end
  if ascii_lower(item.id or ''):find('unread', 1, true) then
    return true
  end
  if by_id_only then
    return false
  end
  local lowered = ascii_lower(text)
  for _, word in ipairs(UNREAD_WORDS) do
    if lowered:find(word, 1, true) then
      return true
    end
  end
  return false
end

-- Looks through the items of the list one by one, without asking SandFly to search.
local function walk_for_unread(node, depth, budget, by_id_only)
  if node.visible ~= false and is_unread_line(node, by_id_only) then
    return node
  end
  if depth == 0 or budget.left <= 0 then
    return nil
  end
  local ok, kids = pcall(node.children, node)
  for _, kid in ipairs(ok and kids or {}) do
    budget.left = budget.left - 1
    if kid.visible ~= false then
      local found = walk_for_unread(kid, depth - 1, budget, by_id_only)
      if found then
        return found
      end
    end
  end
  return nil
end

-- The line "N unread messages" if it is on the screen.
local function find_unread_line(list, quick)
  -- WhatsApp gives the line an id with "unread" in it ("unread_divider_tv"): that is the surest way
  local ok_id, by_id = pcall(list.findAll, list, { matches = 'unread', field = 'id', visible = true }, 5)
  for _, item in ipairs(ok_id and by_id or {}) do
    if is_unread_line(item, true) then
      return focus_target(item)
    end
  end
  for _, word in ipairs(UNREAD_WORDS) do
    local ok, found = pcall(list.findAll, list, { contains = word, visible = true }, 10)
    for _, item in ipairs(ok and found or {}) do
      if is_unread_line(item) then
        return focus_target(item)
      end
    end
  end
  if quick then
    return nil
  end
  -- if the search of SandFly finds nothing, the items are looked at one by one
  for _, by_id_only in ipairs({ true, false }) do
    local found = walk_for_unread(list, 4, { left = 600 }, by_id_only)
    if found then
      sf.log('unread line found by walking the items: ' .. tostring(found.id))
      return focus_target(found)
    end
  end
  sf.log('unread line not on the screen; ok_id=' .. tostring(ok_id) .. ' by_id=' .. tostring(ok_id and #by_id or 'error'))
  return nil
end

-- What the list shows now, to tell when a scroll has stopped.
local function page_signature(list)
  local ok, kids = pcall(list.children, list)
  if not ok or not kids or #kids == 0 then
    return nil
  end
  local first, last = kids[1].bounds, kids[#kids].bounds
  return table.concat({ #kids, first and first.top or 0, first and first.bottom or 0, last and last.top or 0, last and last.bottom or 0 }, ':')
end

-- After a scroll: looks for the line again and again, as soon as the list moves, and stops waiting when the list has
-- stopped. This is much faster than waiting a fixed time after every page.
local function look_while_it_settles(list)
  local previous
  local waited = 0
  while waited < SCAN_MAX_WAIT do
    sf.sleep(SCAN_POLL)
    waited = waited + SCAN_POLL
    local fresh = chat_list() or list
    local line = find_unread_line(fresh, true)
    if line then
      return line
    end
    local signature = page_signature(fresh)
    if signature and signature == previous then
      -- stopped: now the careful search too
      return find_unread_line(fresh)
    end
    previous = signature
  end
  return find_unread_line(chat_list() or list)
end

local function scan_for_unread_line(list, steps, scroll)
  for step = 1, steps do
    if not scroll() then
      return nil
    end
    local line = look_while_it_settles(list)
    if line then
      return line
    end
    if step % 25 == 0 then
      say_now(tr('Still looking'))
    end
  end
  return nil
end

-- The last row on the screen: the lowest one that is visible.
local function last_visible_row(list)
  local ok, kids = pcall(list.children, list)
  local best
  for _, kid in ipairs(ok and kids or {}) do
    local b = kid.bounds
    if kid.visible ~= false and b and (not best or b.top > best.bounds.top) then
      best = kid
    end
  end
  return best
end

-- Goes to the newest message: straight to the last row when the list says how many it has, or page by page.
local function scroll_to_end(list)
  local collection = list.collection
  local rows = collection and collection.rows
  if rows and rows > 0 then
    local ok, done = pcall(list.perform, list, 'scrollToPosition', { row = rows, column = 1 })
    if ok and done then
      return
    end
  end
  for _ = 1, SCAN_STEPS_BACK do
    if not list:scrollForward() then
      return
    end
    sf.sleep(120)
  end
end

local function focus_and_keep(find_target)
  local target
  for _ = 1, LAST_TRIES do
    target = find_target()
    if not target then
      return false
    end
    target:focus()
    sf.sleep(FOCUS_WAIT)
    local ok, focused = pcall(sf.screen.focused)
    local fb = ok and focused and focused.bounds
    local tb = target.bounds
    if fb and tb and fb.top == tb.top then
      return true
    end
  end
  return false
end

sf.onCommand('lastMessage', function()
  local list = chat_list()
  if not list then
    say_now(tr('Open a chat first'))
    return
  end
  scroll_to_end(list)
  sf.sleep(SCAN_WAIT)
  if not focus_and_keep(function() return last_visible_row(chat_list() or list) end) then
    say_now(tr('Could not find the last message'))
  end
end)

-- The line seen by its id while the list is still moving.
local function quick_unread_line()
  -- one search of the screen for the words of the line, in Portuguese and in English: each search goes through the
  -- whole list, so a second one would slow the run down
  local ok, found = pcall(sf.screen.findAll, { matches = 'unread|n[ãa]o lida', visible = true }, 5)
  for _, item in ipairs(ok and found or {}) do
    if is_unread_line(item) then
      return item
    end
  end
  return nil
end

local function mute_scan()
  pcall(sf.feedback.mute, { speech = true, sounds = true, vibration = true }, 10000)
end

-- Scrolls toward the newest message one page after another with no waiting for each to stop, and looks for the line
-- all the time. Each scroll starts from where the list is, so it runs on without stopping and no page is skipped.
-- Speech, sounds and vibration of SandFly are off meanwhile, so that they do not slow it down.
local function fast_scan_forward(list)
  mute_scan()
  local muted_at = os.time()
  -- the focus waits on something that stays on the screen, so that nothing pulls the list back to where the focus was
  local ok_head, head = pcall(sf.screen.find, { id = 'conversation_contact' })
  if ok_head and head then
    pcall(head.focus, head)
  end
  local line
  for _ = 1, FAST_STEPS do
    if not list:scrollForward() then
      list = chat_list() or list
      if not list:scrollForward() then
        break
      end
    end
    sf.sleep(FAST_PAUSE)
    line = quick_unread_line()
    if line then
      break
    end
    if os.time() - muted_at >= 8 then
      mute_scan()
      muted_at = os.time()
    end
  end
  pcall(sf.feedback.unmute)
  return line
end

-- The list went on a little after the line was seen: it is brought back until the line is on the screen.
local function bring_line_into_view(list)
  for _ = 1, 4 do
    sf.sleep(BRING_WAIT)
    local line = find_unread_line(chat_list() or list)
    if line then
      return line
    end
    ;(chat_list() or list):scrollBackward()
  end
  return nil
end

sf.onCommand('unreadLine', function()
  local list = chat_list()
  if not list then
    say_now(tr('Open a chat first'))
    return
  end
  local line = find_unread_line(list)
  if not line then
    say_now(tr('Looking for the unread messages'))
    -- WhatsApp opens before the line, so it is ahead: a fast run to the newest message. If it did not see the line, it
    -- is looked for carefully from the newest message back.
    local seen = fast_scan_forward(list)
    if seen then
      line = bring_line_into_view(list)
    end
    if not line then
      line = find_unread_line(chat_list() or list)
        or scan_for_unread_line(list, SCAN_STEPS_BACK, function() return (chat_list() or list):scrollBackward() end)
    end
  end
  if not line then
    say_now(tr('There is no line of unread messages in this chat'))
    return
  end
  if not focus_and_keep(function() return find_unread_line(chat_list() or list) end) then
    line:focus()
  end
end)

-- ======== A voice message that is playing: the focus follows it and the screen stays on ===============
-- While a voice message plays, SandFly focus goes to its row (once for each message, so that moving the focus
-- yourself is left alone), and the screen timeout is raised to the longest SandFly can set, because WhatsApp
-- stops playing when the screen turns off. The timeout you had comes back when the playback ends, when you leave
-- WhatsApp and the next time the script loads, if something stopped it before. Each part has a switch in the settings.
local PLAY_POLL_MS = 1500
local PLAY_MISSES_TO_END = 2 -- polls without a message playing before it counts as ended
local FOLLOW_MUTE_MS = 1200 -- the message is playing: what SandFly would say about it on focus is not said

local play = { misses = 0, followed = nil, holding = false, failed = false }

-- What is playing: the play button of a message that says "Pause" instead of "Play".
local function playing_control()
  local ok, buttons = pcall(sf.screen.findAll, { id = 'control_btn' }, 30)
  local hidden
  for _, button in ipairs(ok and buttons or {}) do
    local description = ascii_lower(button.contentDescription or '')
    for _, word in ipairs(WA.pause) do
      if description:sub(1, #word) == word then
        if button.visible ~= false then
          return button
        end
        hidden = hidden or button
      end
    end
  end
  return hidden
end

-- The row of the list that an item is in.
local function row_in_list(item)
  local node = item
  for _ = 1, 8 do
    local ok, parent = pcall(node.parent, node)
    if not ok or not parent then
      return item
    end
    if (parent.id or ''):sub(-5) == '/list' then
      return node
    end
    node = parent
  end
  return item
end

-- Something that tells one message from another: its description as the row has it.
local function message_key(row)
  local ok, found = pcall(row.find, row, { id = 'main_layout' })
  local description = ok and found and found.contentDescription
  local bounds = row.bounds
  return description or tostring(bounds and bounds.top)
end

local function release_screen()
  local saved = sf.storage.get('screenTimeoutBefore')
  if saved == nil then
    play.holding = false
    return
  end
  local ok = pcall(sf.device.set, 'screenTimeout', saved)
  if ok then
    sf.storage.set('screenTimeoutBefore', nil)
    play.holding = false
  end
end

local function hold_screen()
  if play.holding or play.failed then
    return
  end
  local ok, state = pcall(sf.device.get, 'screenTimeout')
  if not ok or type(state) ~= 'table' or state.value == nil then
    sf.log('screen timeout: cannot be read')
    play.failed = true
    return
  end
  local longest = nil
  for _, option in ipairs(state.options or {}) do
    local value = type(option) == 'table' and option.value or option
    if type(value) == 'number' and (not longest or value > longest) then
      longest = value
    end
  end
  longest = longest or state.max
  if longest == nil or state.value == longest then
    play.holding = true -- already the longest: nothing to change and nothing to give back
    return
  end
  sf.storage.set('screenTimeoutBefore', state.value)
  local done, why = pcall(sf.device.set, 'screenTimeout', longest)
  if not done then
    sf.storage.set('screenTimeoutBefore', nil)
    play.failed = true
    sf.log('screen timeout: ' .. tostring(why))
    say_now(tr('SandFly cannot change the screen timeout. Allow it to modify system settings to keep the screen on'))
    return
  end
  play.holding = true
end

local function follow_message(control)
  local row = row_in_list(control)
  local key = message_key(row)
  if key == play.followed then
    return
  end
  play.followed = key
  if row.visible == false then
    return
  end
  pcall(sf.feedback.mute, { speech = true }, FOLLOW_MUTE_MS)
  row:focus()
  -- the row is read again now that it plays: the speed button is there only while it does, and the Actions menu uses
  -- the row that was read last
  pcall(function()
    local list = list_of(row)
    if list then
      cached_row = { node = row, r = read_row(row, list) }
    end
  end)
end

local function playback_ended()
  play.misses = 0
  play.followed = nil
  play.control = nil
  play.seen = false
  release_screen()
end

-- Looking at the screen asks WhatsApp for every item, and WhatsApp answers on the thread that draws and scrolls it. So
-- nothing looks at the screen all the time: the script starts looking only when a voice message is started, and stops
-- when the message is over. Until then it does no work at all. While one plays, the Pause button that was found is only
-- refreshed (one call), and the whole screen is searched again only when that one stops saying Pause.
local PLAY_START_TRIES = 4 -- looks, after a message is started, to see it playing before giving up
local poll_timer = nil

local function stop_polling()
  if poll_timer then
    pcall(sf.clearTimer, poll_timer)
    poll_timer = nil
  end
end

-- Does this item still say Pause? One call to WhatsApp.
local function still_playing(control)
  local ok, fresh = pcall(control.refresh, control)
  if not ok or not fresh then
    return nil
  end
  local description = ascii_lower(fresh.contentDescription or '')
  for _, word in ipairs(WA.pause) do
    if description:sub(1, #word) == word then
      return fresh
    end
  end
  return nil
end

local poll_playback

local function start_polling()
  if poll_timer then
    return
  end
  play.misses = 0
  play.seen = false
  play.tries = 0
  poll_playback()
  poll_timer = sf.setInterval(poll_playback, PLAY_POLL_MS)
end

function poll_playback()
  local follow = sf.settings.get('followPlayingMessage') ~= false
  local keep = sf.settings.get('keepScreenOnWhilePlaying') ~= false
  if not follow and not keep then
    if play.holding then
      release_screen()
    end
    stop_polling()
    return
  end
  if not keep and play.holding then
    release_screen()
  end
  -- the same message is still playing: one call to WhatsApp and nothing else
  if play.control and still_playing(play.control) then
    play.misses = 0
    return
  end
  if not chat_list() then
    if play.holding or play.followed then
      playback_ended()
    end
    stop_polling()
    return
  end
  local control = playing_control()
  play.control = control
  if not control then
    if not play.seen then
      -- the button may take a moment to say Pause after it was pressed
      play.tries = play.tries + 1
      if play.tries >= PLAY_START_TRIES then
        stop_polling()
      end
      return
    end
    play.misses = play.misses + 1
    if play.misses >= PLAY_MISSES_TO_END then
      playback_ended()
      stop_polling()
    end
    return
  end
  play.seen = true
  play.misses = 0
  if keep then
    hold_screen()
  elseif play.holding then
    release_screen()
  end
  if follow then
    follow_message(control)
  end
end

-- If a screen timeout was raised and never given back, such as after the phone restarted, it is given back now.
if sf.storage.get('screenTimeoutBefore') ~= nil then
  sf.run(release_screen)
end

-- A voice message is started by pressing its play button, by anyone: by you, or by an action of the script.
sf.onClick(function(event)
  local node = event and event.node
  if node and node.packageName and WHATSAPP_PACKAGES[node.packageName] and short_id(node) == 'control_btn' then
    sf.setTimeout(start_polling, 300)
  end
end)

sf.onAppLeave(function()
  stop_polling()
  release_screen()
end)

local SKIPPED_BUTTONS = {
  name_in_group = true, contact_photo_view = true, url_layout = true, poll_option_vote_checkbox = true,
  info = true, play_frame_view = true, video_control_frame_view = true,
}

-- downloading is true while the row has a Download button, so its photo isn't there yet.
-- The text of a button. With the row already read, it comes from the items that were read: the button's
-- own text, or that of the first item inside it that has one. Without it, WhatsApp is asked.
local function name_of(button, r)
  if not r then
    return label_of(button)
  end
  local own = clean(present(button.contentDescription) or button.text)
  if own ~= '' then
    return own
  end
  local a = button.bounds
  for _, candidate in ipairs(r.items) do
    local b = candidate.bounds
    if candidate ~= button and a and b and b.left >= a.left and b.right <= a.right
        and b.top >= a.top and b.bottom <= a.bottom then
      local label = clean(present(candidate.contentDescription) or candidate.text)
      if label ~= '' then
        return label
      end
    end
  end
  return ''
end

local function title_of(button, downloading, r)
  local id = short_id(button)
  if id == 'bubble_quoted_message_frame' then
    return tr('Go to replied message')
  elseif id == 'reactions_bubble_layout' then
    return tr('View reactions')
  elseif id == 'link_preview_frame' then
    return tr('Open link')
  elseif id == 'poll_option_main_layout' then
    return tr('Vote') .. ': ' .. name_of(button, r)
  elseif id == 'image' then
    return downloading and '' or tr('Open photo')
  elseif id == 'polls_main_layout' then
    local label = name_of(button, r)
    return is_one_of(label, WA.enlarge) and label or ''
  elseif id == 'control_btn' then
    if (button.className or ''):sub(-11) == 'ImageButton' then
      return name_of(button, r)
    end
    -- the Download button of a video says its size
    local size = clean(button.text)
    return size ~= '' and (tr('Download') .. ' (' .. size .. ')') or tr('Download')
  elseif id == 'thumb' or id == 'play_button' then
    -- the picture of a video that is not downloaded is the Download button, and the video cannot be played yet
    local thumb = r and first(r, 'thumb')
    if thumb and is_one_of(clean(thumb.contentDescription), WA.download) then
      return ''
    end
    return name_of(button, r)
  elseif SKIPPED_BUTTONS[id] then
    return ''
  end
  local label = name_of(button, r)
  return label:find('^https?://') and tr('Open link') or label
end

-- The label of an item's click action, where the app gave it one, such as "view profile".
local ACTION_CLICK = 16
local function click_label(item)
  for _, action in ipairs(item.actions or {}) do
    if action.id == ACTION_CLICK and action.label ~= 'click' then
      return (clean(action.label):gsub('^%l', string.upper))
    end
  end
  return ''
end

local MAX_CHAT_ITEMS = 20

-- A chat in the chats list, whose photo, hidden by the rules, opens the contact's or group's
-- profile. The action has the name WhatsApp gives the photo, in WhatsApp's language. A community's
-- photo can't be clicked itself; the frame around it can.
local function chat_actions(row)
  local photo, frame
  for _, item in ipairs(row:findAll({}, MAX_CHAT_ITEMS)) do
    local id = short_id(item)
    if id == 'contact_photo' or id == 'parent_stack_photo' then
      photo = photo or item
    elseif id == 'contact_selector' then
      frame = frame or item
    end
  end
  local target = photo and photo.clickable and photo or frame
  if not target then
    return
  end
  local title = present(click_label(target))
    or (photo and (present(click_label(photo)) or present(clean(photo.contentDescription))))
    or tr('View profile')
  return {
    {
      title = title,
      run = function()
        if not target:click() then
          target:tap()
        end
      end,
    },
  }
end

-- Names of the standard Android actions, which SandFly lists on their own, without spaces and in
-- lower case. A custom action named like one of them isn't listed twice.
local STANDARD_ACTIONS = {}
for name in ([[click longclick scrollforward scrollbackward expand collapse dismiss copy cut paste select
  clearselection focusinput clearfocus showonscreen scrollup scrolldown scrollleft scrollright pageup
  pagedown pageleft pageright contextclick imeenter pressandhold showtooltip hidetooltip
  showtextsuggestions setselection settext setprogress scrolltoposition]]):gmatch('%S+') do
  STANDARD_ACTIONS[name] = true
end
local ACTION_LONG_CLICK = 32

-- ======== Go to the message a reply answers ===============================================================
-- Pressing the quote of a reply makes WhatsApp scroll the chat to the message it answers, but the focus of the screen
-- reader stays where it was. After the press, the message is found by the beginning of the quoted text (the quote shows
-- the start of a long message, sometimes cut with "..."), and the focus goes to it, so it is read. When the quote has
-- text of a message to look for, such as the one of a photo or a voice message ("Mensagem de voz (0:03)"), the message is
-- the nearest one above the reply from the same author, and from nothing better, the one in the middle of the screen.
local REPLIED_WAIT_MS = 250 -- before the first look: WhatsApp is scrolling; the setting repliedWaitMs changes it
local REPLIED_STEP_MS = 350 -- between looks: a message far up has to be loaded first
local REPLIED_LOOKS = 8
local REPLIED_PREFIX = 40 -- characters of the quote that are looked for

-- What of the quote is looked for: its first line, without the cut mark, in lower case, up to REPLIED_PREFIX characters.
local function replied_needle(quoted)
  local text = quoted:match('^[^\n]+') or quoted
  text = text:gsub('%s*\xE2\x80\xA6%s*$', ''):gsub('%s*%.%.%.%s*$', '')
  local ok, cut = pcall(function()
    local at = utf8.offset(text, REPLIED_PREFIX + 1)
    return at and text:sub(1, at - 1) or text
  end)
  return ascii_lower((ok and cut or text):match('^%s*(.-)%s*$'))
end

local function middle_of(list)
  local b = list.bounds
  return b and (b.top + b.bottom) / 2 or 0
end

local function distance_to(row, middle)
  local b = row.bounds
  return b and math.abs((b.top + b.bottom) / 2 - middle) or math.huge
end

-- The row of the message that has the quoted text, other than the reply itself; the one nearest the middle of the
-- screen when several have it.
local function find_replied(list, reply, needle)
  if needle == '' then
    return nil
  end
  local ok, found = pcall(sf.screen.findAll, { id = 'message_text' }, 60)
  local middle, best, best_distance = middle_of(list), nil, math.huge
  for _, item in ipairs(ok and found or {}) do
    if item.visible ~= false and ascii_lower(clean(item.text)):find(needle, 1, true) == 1 then
      local row = row_in_list(item)
      local d = distance_to(row, middle)
      if row ~= reply and d < best_distance then
        best, best_distance = row, d
      end
    end
  end
  return best
end

-- The row nearest the middle of the screen that is not the reply: where WhatsApp leaves the message it went to.
local function middle_row(list, reply)
  local ok, kids = pcall(list.children, list)
  local middle, best, best_distance = middle_of(list), nil, math.huge
  for _, kid in ipairs(ok and kids or {}) do
    local d = distance_to(kid, middle)
    if kid.visible ~= false and kid ~= reply and d < best_distance then
      best, best_distance = kid, d
    end
  end
  return best
end

-- Whether the quote is of a voice or sound message: it reads "Mensagem de voz (0:03)" or "Voice message (0:03)".
local function is_voice_quote(quoted)
  local lowered = quoted:lower()
  return quoted:find('%d+:%d+') ~= nil and (lowered:find('voz', 1, true) ~= nil or lowered:find('voice', 1, true) ~= nil
    or lowered:find('udio', 1, true) ~= nil or lowered:find('audio', 1, true) ~= nil)
end

-- Whether the name over the quote is mine: a quote of my own message says "Você" or "You".
local function is_my_name(title)
  return title == tr('You') or title == 'You' or title == '\x56\x6F\x63\xC3\xAA' or title == 'Voce'
end

-- The message the quote is of, found by its author when the quote has no text of a message to look for: going up from the
-- reply, the first message that I sent (the quote says "Você") or that someone else sent (their name, in a group), and,
-- for the quote of a voice message, that is a voice message. WhatsApp often has it on screen already, right above.
local function replied_above(list, reply, title, quoted)
  local fresh = reply:refresh()
  local b = fresh and fresh.visible ~= false and fresh.bounds
  -- The reply scrolled off the screen, below: every row on the screen is above it.
  b = b or { top = math.huge }
  local ok, kids = pcall(list.children, list)
  local above = {}
  for _, kid in ipairs(ok and kids or {}) do
    local kb = kid.bounds
    if kid.visible ~= false and kb and kb.top < b.top then
      above[#above + 1] = kid
    end
  end
  table.sort(above, function(x, y) return x.bounds.top > y.bounds.top end)
  local mine, voice = is_my_name(title), is_voice_quote(quoted)
  for i = 1, math.min(#above, 12) do
    local r = read_row(above[i], list)
    if main_of(r) then
      local named = text_in(r, 'name_in_group_tv')
      local author_ok
      if mine then
        author_ok = is_outgoing(r)
      else
        author_ok = not is_outgoing(r)
          and (named == '' or title == '' or ascii_lower(named):find(ascii_lower(title), 1, true) ~= nil)
      end
      if author_ok and (not voice or voice_of(r)) then
        return above[i]
      end
    end
  end
  return nil
end

-- The words WhatsApp puts in a quote of something that is not text: there is no message text to look for.
local MEDIA_QUOTES = {
  foto = true, photo = true, video = true, gif = true, documento = true, document = true, figurinha = true,
  sticker = true, audio = true, localizacao = true, location = true, contato = true, contact = true,
}

-- Whether the quote is of a voice message or of something that is not text, so the original is looked for by its
-- author and not by the beginning of its text.
local function is_media_quote(quoted)
  return is_voice_quote(quoted) or MEDIA_QUOTES[ascii_lower(quoted):match('^%s*(.-)%s*$')] == true
end

local REPLIED_AUTHOR_LOOKS = 6
local REPLIED_AUTHOR_STEP_MS = 200

-- The original of a quote that has no text to look for, by its author. WhatsApp is still scrolling when it is first
-- looked for, so the answer is taken once the reply has left the screen, or when two looks in a row give the same one.
local function find_by_author(list, reply, title, quoted)
  local previous
  for look = 1, REPLIED_AUTHOR_LOOKS do
    list = chat_list() or list
    local fresh = reply:refresh()
    local gone = not (fresh and fresh.visible ~= false and fresh.bounds)
    local found = replied_above(list, reply, title, quoted)
    if found and (gone or (previous and previous.bounds and found.bounds and previous.bounds.top == found.bounds.top)) then
      return found
    end
    previous = found
    sf.sleep(REPLIED_AUTHOR_STEP_MS)
  end
  return previous
end

-- How long to wait, after pressing the quote, for WhatsApp to scroll to the original: the setting, from 0 to 1.5 seconds.
local function replied_wait_ms()
  local value = tonumber(sf.settings.get('repliedWaitMs'))
  if not value then
    return REPLIED_WAIT_MS
  end
  return math.max(0, math.min(1500, value))
end

local function go_to_replied(r, button)
  local reply, title, quoted = r.node, text_in(r, 'quoted_title'), text_in(r, 'quoted_text')
  local media = is_media_quote(quoted)
  local needle = media and '' or replied_needle(quoted)
  if not button:click() then
    button:tap()
  end
  sf.sleep(replied_wait_ms())
  local list = chat_list()
  if not list then
    return
  end
  local target
  if media then
    target = find_by_author(list, reply, title, quoted)
  else
    for look = 1, REPLIED_LOOKS do
      target = find_replied(list, reply, needle)
      if target or needle == '' then
        break
      end
      sf.sleep(REPLIED_STEP_MS)
    end
  end
  target = target or replied_above(chat_list() or list, reply, title, quoted)
  target = target or middle_row(chat_list() or list, reply)
  if not target then
    say_now(tr('Could not find the replied message'))
    return
  end
  if not focus_and_keep(function() return target:refresh() or target end) then
    say_now(tr('Could not find the replied message'))
  end
end

local function upper_first(text)
  return (text:gsub('^%l', string.upper))
end

-- The actions WhatsApp gives the message, such as Reply, Forward and Share, wherever in the row they
-- are: this script hides the buttons of a row, and with them the place they may be on, so the row is
-- searched for them. Each has the number of the action and the item that has it.
local function native_actions_of(r)
  local found, seen = {}, {}
  for _, node in ipairs(r.items) do
    for _, action in ipairs(node.actions or {}) do
      local label = clean(action.label or '')
      local key = label:lower():gsub('[%s_%-]', '')
      if label ~= '' and action.id ~= ACTION_CLICK and action.id ~= ACTION_LONG_CLICK
          and not STANDARD_ACTIONS[key] and not seen[key] then
        seen[key] = true
        found[#found + 1] = { title = upper_first(label), node = node, id = action.id, label = label }
      end
    end
  end
  return found
end

local function inside(inner, outer)
  local a, b = inner.bounds, outer.bounds
  return a and b and a.left >= b.left and a.right <= b.right and a.top >= b.top and a.bottom <= b.bottom
end

-- Whether the button holds the picture or the initials of a contact in a group chat.
local function is_profile_button(r, button)
  for _, id in ipairs({ 'group_profile_initials', 'group_profile_pic' }) do
    for _, found in ipairs(r.by_id[id] or {}) do
      if inside(found, button) then
        return true
      end
    end
  end
  return false
end

-- ======== Copy what a message holds: links, e-mail addresses and phone numbers ======================
-- The Actions menu of a message gets "Copy link: ...", "Copy e-mail: ..." and "Copy number: ..." for each one
-- found in the text, after the options that open them. Only the texts read with the row are used, so the
-- menu still answers without asking WhatsApp for anything.
local COPY_TLDS = {}
for tld in ([[com net org edu gov mil int info biz io co me app dev tv ly gl be br pt us uk ar cl mx de fr es
  it nl ru cn jp in au ca xyz online site store shop link page cloud tech ai wiki blog news]]):gmatch('%S+') do
  COPY_TLDS[tld] = true
end

local MAX_COPY = 8 -- the most Copy actions on one message
local MAX_COPY_TITLE = 60 -- longer addresses are cut in the title, not in what is copied

-- The address without what WhatsApp or the sentence puts around it: quotes, brackets, punctuation and the
-- * _ ~ marks of bold, italic and strikethrough.
local function trim_edges(token)
  local text = token:gsub('^[%(%[{<"\'%*_~]+', '')
  text = text:gsub('[%.,;:!%?%)%]}>"\'%*_~]+$', '')
  return text
end

local function is_email(text)
  if not text:find('^[%w%.%_%%%+%-]+@[%w%-]+%.[%w%.%-]+$') then
    return false
  end
  return text:match('%.(%a+)$') ~= nil
end

local function is_link(text)
  local lowered = ascii_lower(text)
  if lowered:find('^https?://%S') or lowered:find('^www%.%S') then
    return true
  end
  if text:find('@', 1, true) then
    return false
  end
  local host = lowered:match('^([^/%?#]+)')
  if not host or not host:find('^[%w%-%.]+$') or not host:find('%a') then
    return false
  end
  local tld = host:match('%.(%a+)$')
  return tld ~= nil and COPY_TLDS[tld] == true and #host > #tld + 1
end

-- The phone numbers in the text: 8 to 15 digits, with spaces, dots, dashes and brackets between groups of at
-- least two, alone and not part of a word. Dates such as 12-05-2026 are not numbers.
local function find_phones(scan, add)
  local i = 1
  while i <= #scan do
    local s, e = scan:find('%+?[%(%d][%d%s%-%.%(%)]*', i)
    if not s then
      return
    end
    local raw = scan:sub(s, e)
    -- two separators in a row (". ", " ...") end the number: the sentence goes on with something else
    local cut = raw:find('[%s%.%-][%s%.%-]')
    if cut then
      raw = raw:sub(1, cut - 1)
      e = s + cut - 2
    end
    i = e + 1
    local run = raw:gsub('[%s%-%.%(%)]+$', '')
    local digits = run:gsub('%D', '')
    local before = s > 1 and scan:sub(s - 1, s - 1) or ''
    local after = scan:sub(s + #run, s + #run)
    local short_group = false
    for group in run:gmatch('%d+') do
      if #group < 2 then
        short_group = true
      end
    end
    local is_date = run:find('^%d%d?[%-%.]%d%d?[%-%.]%d%d%d?%d?$') ~= nil
    if #digits >= 8 and #digits <= 15 and not short_group and not is_date
        and not before:find('%w') and not after:find('%a') then
      add('phone', (run:sub(1, 1) == '+' and '+' or '') .. digits)
    end
  end
end

-- What can be copied from a text, in the order it appears: { { kind = 'link' | 'email' | 'phone', value } }.
local function copyables(text)
  local found, seen = {}, {}
  local function add(kind, value)
    local key = kind .. ':' .. value:lower()
    if not seen[key] and #found < MAX_COPY then
      seen[key] = true
      found[#found + 1] = { kind = kind, value = value }
    end
  end
  local pieces, position = {}, 1
  for start, token in text:gmatch('()(%S+)') do
    local address = trim_edges(token)
    local kind = address ~= '' and ((is_email(address) and 'email') or (is_link(address) and 'link')) or nil
    if kind then
      add(kind, address)
      -- the address is taken out of the text that is searched for phone numbers
      pieces[#pieces + 1] = text:sub(position, start - 1)
      pieces[#pieces + 1] = string.rep('x', #token)
      position = start + #token
    end
  end
  pieces[#pieces + 1] = text:sub(position)
  find_phones(table.concat(pieces), add)
  return found
end

local function copy_title(kind)
  if kind == 'link' then
    return tr('Copy link')
  elseif kind == 'email' then
    return tr('Copy e-mail')
  end
  return tr('Copy number')
end

local function copy_text(value)
  local ok = pcall(sf.clipboard.set, value)
  sf.speak(tr(ok and 'Copied' or 'Could not copy'), { interrupt = true })
end

-- The texts of the message that can hold something to copy: its text, its caption and the address of a link's
-- preview. Nothing that WhatsApp is asked for: the items were read with the row.
local function add_copy_actions(r, add)
  local texts = {}
  for _, id in ipairs({ 'message_text', 'caption', 'url' }) do
    for _, item in ipairs(r.by_id[id] or {}) do
      if item.text and item.text ~= '' then
        texts[#texts + 1] = item.text
      end
    end
  end
  if #texts == 0 then
    return
  end
  for _, found in ipairs(copyables(table.concat(texts, '\n'))) do
    local shown = found.value
    if #shown > MAX_COPY_TITLE then
      shown = shown:sub(1, MAX_COPY_TITLE) .. '…'
    end
    add(copy_title(found.kind) .. ': ' .. shown, function() copy_text(found.value) end)
  end
end

local function is_speed_label(label)
  local lowered = ascii_lower(label or '')
  for _, word in ipairs(WA.speed) do
    if lowered:find(word, 1, true) then
      return true
    end
  end
  return false
end

-- The playback speed button of a voice message: the item that has that name itself. The button that can be clicked
-- around it takes its name from it, and pressing that one plays or pauses the message, so the speed button itself is
-- touched, as a finger would.
local function speed_item_of(r)
  for _, candidate in ipairs(r.items) do
    if is_speed_label(clean(present(candidate.contentDescription) or candidate.text)) then
      return candidate
    end
  end
  return nil
end

-- What the speed button shows now ("1x", "1.5x"), or nil when it is no longer on the screen: the button is there only
-- while the message plays, so when it is gone the message stopped.
local function speed_now(node)
  local ok, fresh = pcall(node.refresh, node)
  if not ok or not fresh then
    return nil
  end
  local text = clean(fresh.text)
  if text == '' then
    text = clean(fresh.contentDescription)
  end
  return text
end

local SPEED_WAIT = 450

-- A moment after the button was pressed: its text says the new speed. If the text did not change, the press did nothing
-- (the button may only answer to a touch), and it is touched as a finger would.
local function finish_speed(node, before, touched)
  local now = speed_now(node)
  sf.log('speed button: before=' .. tostring(before) .. ' now=' .. tostring(now) .. ' touched=' .. tostring(touched))
  if now == nil then
    say_now(tr('The speed could not be changed'))
    return
  end
  if now == before and not touched then
    pcall(node.tap, node)
    sf.setTimeout(finish_speed, SPEED_WAIT, node, before, true)
    return
  end
  say_now(now)
end

-- Presses the speed button itself, never the item around it: the item around it plays or pauses the message.
local function press_speed(item)
  local node = item:refresh() or item
  local before = speed_now(node)
  local ok, done = pcall(node.click, node)
  sf.log('speed button: click ' .. tostring(ok) .. ' ' .. tostring(done))
  if not (ok and done) then
    pcall(node.tap, node)
  end
  sf.setTimeout(finish_speed, SPEED_WAIT, node, before, not (ok and done))
end

-- The speed button of the message that is playing, from anywhere in the chat.
sf.onCommand('voiceSpeed', function()
  local ok, found = pcall(sf.screen.find, { id = 'fast_playback_overlay', visible = true })
  if not ok or not found then
    say_now(tr('No voice message is playing'))
    return
  end
  press_speed(found)
end)

local function message_actions(item, r)
  local actions, titles = {}, {}
  local function add(title, run)
    local key = title:lower()
    if title ~= '' and not titles[key] then
      titles[key] = true
      actions[#actions + 1] = { title = title, run = run }
    end
  end

  -- What the app itself offers for the message comes first.
  for _, native in ipairs(native_actions_of(r)) do
    add(native.title, function()
      local node = native.node:refresh() or native.node
      -- By its number first; by its name if that fails. An item that is gone raises an error.
      local ok, done = pcall(function() return node:perform(native.id) end)
      if not (ok and done) then
        ok, done = pcall(function() return node:perform(native.label) end)
      end
      if not (ok and done) then
        sf.speak(tr('That action is not available'), { interrupt = true })
      end
    end)
  end

  local buttons = {}
  for _, candidate in ipairs(r.items) do
    if candidate.clickable and #buttons < MAX_BUTTONS then
      buttons[#buttons + 1] = candidate
    end
  end
  local downloading = false
  for _, button in ipairs(buttons) do
    if short_id(button) == 'control_btn' and (button.className or ''):sub(-11) ~= 'ImageButton' then
      downloading = true
    end
  end
  local speed = speed_item_of(r)
  for _, button in ipairs(buttons) do
    if button ~= item and not is_profile_button(r, button) then
      local title = title_of(button, downloading, r)
      if speed and is_speed_label(title) then
        -- the speed button: touched itself, never the item around it
        add(clean(present(speed.contentDescription) or speed.text), function() press_speed(speed) end)
      elseif short_id(button) == 'bubble_quoted_message_frame' then
        add(title, function() go_to_replied(r, button) end)
      else
        add(title, function()
          if not button:click() then
            button:tap()
          end
        end)
      end
    end
  end
  if speed then
    -- when no item that can be clicked had its name, the speed button is still in the menu
    add(clean(present(speed.contentDescription) or speed.text), function() press_speed(speed) end)
  end
  add_copy_actions(r, add)
  return actions
end

-- A voice message that was read at rest and plays now (or the other way round) has other buttons: the speed button is
-- there only while it plays. Its play button is asked again, which is one call to WhatsApp, and the row is read again
-- when the two do not agree: it plays and the row has no speed button, or it does not play and the row has one.
local function voice_row_changed(r)
  local control = first(r, 'control_btn')
  if not control then
    return false
  end
  local ok, fresh = pcall(control.refresh, control)
  if not ok or not fresh then
    return true
  end
  local description = ascii_lower(fresh.contentDescription or '')
  local playing = false
  for _, word in ipairs(WA.pause) do
    if description:sub(1, #word) == word then
      playing = true
    end
  end
  return playing ~= (first(r, 'fast_playback_overlay') ~= nil)
end

sf.onActions(function(item)
  if not in_whatsapp(item) then
    return
  end
  if short_id(item) == 'contact_row_container' then
    return chat_actions(item)
  end
  -- The row that focus read, if it is this one; otherwise one search reads it now.
  local r = cached_row and cached_row.node == item and cached_row.r
  if r and voice_row_changed(r) then
    r = nil
  end
  if not r then
    local list = list_of(item)
    if not list then
      return
    end
    r = read_row(item, list)
    cached_row = { node = item, r = r }
  end
  local list = message_actions(item, r)
  action_titles = {}
  for _, action in ipairs(list) do
    action_titles[action.title] = true
  end
  return list
end)
