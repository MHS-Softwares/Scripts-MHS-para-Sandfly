-- Google Messages conversation actions (Lua port of google-messages-actions.js v1.0.0), by Surendra, under the
-- Apache License 2.0. Adapted by Michel Henrique: Brazilian Portuguese, the menus of Google Messages in
-- Portuguese, and Select message in the Actions menu of a message in a chat.
-- Adds Pin, Mark as unread, Archive, Delete, Snooze, Block and Add contact to the Actions menu of
-- each conversation in the Google Messages list, and Select conversation and Select message to each one.

local manifest = {
  id = 'google-messages-actions-mhs',
  name = 'Google Messages conversation actions (MHS)',
  version = '1.3.0',
  author = 'Surendra, adapted by Michel Henrique',
  minApiVersion = 2,
  testedApiVersion = 6,
  description = 'Adds Pin, Mark as unread, Archive, Delete, Snooze, Block and Add contact to the Actions menu of each conversation in the Google Messages list, and Select message to the Actions menu of each message in a chat. Conversations and messages can be selected, to delete or archive several at once. Works with Google Messages in English and in Brazilian Portuguese.',
  apps = { 'com.google.android.apps.messaging' },
  permissions = { 'screen', 'actions', 'speech', 'input' },
  settings = {
    { key = 'keepFocus', type = 'switch', title = 'Keep the focus on what was selected', default = true },
  },
}

local tr = sf._

local ROW_ID = 'swipeableContainer'

-- What Google Messages writes in English and in Brazilian Portuguese. The ids of the buttons in the bar do not
-- change with the language; the texts of the menu entries do, so each query has both.
local MORE = { { contentDescription = 'More options' }, { contentDescription = 'Mais opções' } }
local DONE = { { id = 'action_mode_close_button' } }

-- "bar": a button in the toolbar that appears once the conversation is selected.
-- "menu": an entry in the More options popup, which is its own window.
local ACTIONS = {
  {
    title = 'Pin or unpin conversation',
    selected_title = 'Pin or unpin selected conversations',
    where = 'bar',
    queries = {
      { id = 'action_pin_to_top' },
      { contentDescription = 'Unpin' }, { text = 'Unpin' },
      { contentDescription = 'Desafixar' }, { text = 'Desafixar' },
    },
  },
  {
    title = 'Mark as unread or read',
    selected_title = 'Mark selected conversations as unread or read',
    where = 'menu',
    queries = {
      { text = 'Mark as unread' }, { text = 'Mark as read' },
      { text = 'Marcar como não lida' }, { text = 'Marcar como lida' },
    },
  },
  {
    title = 'Archive conversation',
    selected_title = 'Archive selected conversations',
    where = 'bar',
    queries = { { id = 'action_archive' }, { contentDescription = 'Unarchive' }, { contentDescription = 'Desarquivar' } },
  },
  { title = 'Delete conversation', selected_title = 'Delete selected conversations', where = 'bar', queries = { { id = 'action_delete' } } },
  { title = 'Snooze notifications', selected_title = 'Snooze notifications of selected conversations', where = 'bar', queries = { { id = 'action_snooze' } } },
  { title = 'Block', where = 'menu', queries = { { text = 'Block' }, { text = 'Bloquear' } } },
  { title = 'Add contact', where = 'menu', queries = { { text = 'Add contact' }, { text = 'Adicionar contato' } } },
}

local function shortId(item)
  return string.match(item.id or '', '[^/]*$')
end

-- A popup entry's text sits in a child; click the item that is clickable.
local function clickable(node)
  local current = node
  for _ = 1, 4 do
    if not current then break end
    if current.clickable then return current end
    current = current:parent()
  end
  return node
end

local function locate(queries)
  for _, query in ipairs(queries) do
    local found = sf.screen.find(query)
    if found then return clickable(found) end
  end
  return nil
end

local function waitFor(queries, tries)
  for _ = 1, tries or 8 do
    local found = locate(queries)
    if found then return found end
    sf.sleep(150)
  end
  return nil
end

-- Runs when an Actions menu entry is chosen. It can wait, so sf.sleep is allowed here.
-- `selecting` is true when conversations are already selected: the action is then for all of them, and the
-- conversation is not pressed again.
local function perform(row, action, selecting)
  sf.sleep(400)
  if not selecting and not row:longClick() then
    sf.speak(tr('Could not select the conversation'))
    return
  end
  local target = nil
  if action.where == 'bar' then
    target = waitFor(action.queries)
  else
    local more = waitFor(MORE)
    if more then
      more:click()
      target = waitFor(action.queries)
    end
  end
  if target then
    target:click()
    return
  end
  sf.speak(tr('{action} is not available', { action = tr(selecting and action.selected_title or action.title) }))
  -- Leave selection mode so the list works normally again.
  local done = locate(DONE)
  if done then done:click() end
end

-- ======== Keep the focus on what was selected ========================================================
-- Google Messages redraws the list when something is selected or taken off, and the focus of SandFly goes back to
-- the first item. The item is remembered before, and the focus is put back on it afterwards, so that the next swipe
-- goes to the item below it.
-- The text of an item, or of the first thing inside it that has one: a message's bubble may keep its text in a child.
local function text_of(item)
  local own = item.contentDescription
  if own == nil or own == '' then
    own = item.text
  end
  if own == nil or own == '' then
    local seen = 0
    local function look(node, depth)
      if depth > 3 or seen > 30 then return nil end
      for _, child in ipairs(node:children() or {}) do
        seen = seen + 1
        local found = child.contentDescription
        if found == nil or found == '' then found = child.text end
        if found and found ~= '' then return found end
        found = look(child, depth + 1)
        if found then return found end
      end
      return nil
    end
    own = look(item, 1)
  end
  return (tostring(own or ''):gsub('%s+', ' '))
end

local function remember(item, by_id)
  local text = text_of(item)
  return {
    first = text:sub(1, 30),
    last = #text > 30 and text:sub(-30) or '',
    top = item.bounds and item.bounds.top or 0,
    id = by_id and item.id or nil,
  }
end

-- The same item on the screen as it is now: the one with the text it had, nearest to where it was. The end of the
-- text is tried before the start, which Google Messages may change ("Selected, ...").
local function find_again(memo)
  for _, key in ipairs({ memo.last, memo.first }) do
    if key ~= '' then
      local query = { contains = key, visible = true }
      if memo.id then
        query.id = memo.id
      end
      local ok, found = pcall(sf.screen.findAll, query, 30)
      local best, best_gap = nil, nil
      for _, candidate in ipairs(ok and found or {}) do
        local gap = math.abs((candidate.bounds and candidate.bounds.top or 0) - memo.top)
        if not best or gap < best_gap then
          best, best_gap = candidate, gap
        end
      end
      if best then
        return best
      end
    end
  end
  return nil
end

-- Looks twice, a little after the action and a little later, for the focus having gone back to the top. A focus
-- that has moved down, as when the user swipes on, is left alone.
local function keep_focus_on(memo, climb)
  local ok, enabled = pcall(sf.settings.get, 'keepFocus')
  if ok and enabled == false then
    return
  end
  for _ = 1, 2 do
    sf.sleep(350)
    local found = find_again(memo)
    local target = found and (climb and climb(found) or found)
    if target then
      local focused = sf.screen.focused()
      local went_up = focused == nil or ((focused.bounds and focused.bounds.top or 0) < memo.top - 5)
      if focused ~= target and went_up then
        pcall(function() target:focus() end)
      end
    end
  end
end

-- ======== Select conversations ============================================================================
-- A long press on a conversation selects it. While conversations are selected, a tap on one adds it or takes it
-- off, and the Actions menu of a conversation acts on all the selected ones.
local function select_conversation(row)
  sf.sleep(300)
  local memo = remember(row, true)
  if locate(DONE) then
    if not (row:click() or row:tap()) then
      sf.speak(tr('Could not select the conversation'))
      return
    end
    keep_focus_on(memo)
    return
  end
  local ok = row:longClick()
  if not ok then
    local good, held = pcall(function() return row:longPress(1000) end)
    ok = good and held
  end
  if not ok then
    sf.speak(tr('Could not select the conversation'))
    return
  end
  keep_focus_on(memo)
end

local function cancel_selection()
  sf.sleep(300)
  local done = locate(DONE)
  if done then done:click() end
end

-- ======== Select message ===============================================================================
-- In a chat, a long press on a message selects it, and the bar of Google Messages then has what can be done with
-- it: copy, forward, star and delete. While messages are selected, a tap on one adds it or takes it off.
local NOT_A_MESSAGE = { 'Button', 'EditText', 'CheckBox', 'Switch', 'SeekBar', 'Spinner', 'Toolbar' }

-- The item of a message that takes a long press: the item itself, or the first one around it (up to 4 levels).
local function long_clickable(item)
  local current = item
  for _ = 1, 4 do
    if not current then return nil end
    if current.longClickable then return current end
    current = current:parent()
  end
  return nil
end

local function looks_like_message(item)
  local class = item.className or ''
  for _, kind in ipairs(NOT_A_MESSAGE) do
    if class:find(kind, 1, true) then return false end
  end
  if item.editable or item.checkable then return false end
  local id = shortId(item)
  if id == ROW_ID or id:find('^action_') or id:find('^compose') or id:find('^send') or id:find('toolbar') then
    return false
  end
  return long_clickable(item) ~= nil
end

local function message_item(found)
  return long_clickable(found)
end

local function select_message(item)
  sf.sleep(300)
  local target = long_clickable(item) or item
  local memo = remember(target)
  if locate(DONE) then
    -- messages are already selected: a tap adds this one or takes it off
    if not (item:click() or target:click()) then
      sf.speak(tr('Could not select the message'))
      return
    end
    keep_focus_on(memo, message_item)
    return
  end
  local ok = target:longClick()
  if not ok then
    local good, held = pcall(function() return item:longPress(1000) end)
    ok = good and held
  end
  if not ok then
    sf.speak(tr('Could not select the message'))
    return
  end
  keep_focus_on(memo, message_item)
end

sf.onActions(function(item)
  if shortId(item) == ROW_ID then
    local ok, selecting = pcall(sf.screen.find, DONE[1])
    selecting = ok and selecting ~= nil
    local list = {}
    if selecting then
      list[1] = { title = tr('Select or deselect conversation'), run = function() select_conversation(item) end }
      for _, action in ipairs(ACTIONS) do
        if action.selected_title then
          list[#list + 1] = { title = tr(action.selected_title), run = function() perform(item, action, true) end }
        end
      end
      list[#list + 1] = { title = tr('Cancel selection'), run = cancel_selection }
    else
      list[1] = { title = tr('Select conversation'), run = function() select_conversation(item) end }
      for _, action in ipairs(ACTIONS) do
        list[#list + 1] = { title = tr(action.title), run = function() perform(item, action) end }
      end
    end
    return list
  end
  if looks_like_message(item) then
    return { { title = tr('Select message'), run = function() select_message(item) end } }
  end
  return nil
end)
