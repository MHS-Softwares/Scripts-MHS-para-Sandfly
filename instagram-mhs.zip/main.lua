-- Instagram (MHS): a SandFly script for the Instagram app, by MHS Softwares.
-- In the Reels tab, commands go to the next and the previous reel (the script scrolls the pager of the reels itself, and
-- puts the focus on the new reel), and the Actions menu of a reel has Like, Comments, Share, Save, Follow and a summary.
-- In a story, commands go to the next and the previous story, pause it, like it, reply to it and say what it is.
-- In the home feed, the Actions menu of a post has Like, Comment, Repost, Share, Save and More options.
-- In the notifications, each one is read as one item with its buttons in the Actions menu, and the counts of the
-- profile are read with a space between the number and the word.

local manifest = {
  id = 'instagram-mhs',
  name = 'Instagram (MHS)',
  version = '1.8.0',
  author = 'MHS Softwares',
  minApiVersion = 6,
  testedApiVersion = 6,
  description = 'Makes the Reels tab of Instagram easier to use with a screen reader. The commands Next reel and Previous reel scroll to the next or the previous reel and put the focus on it, which you can assign to gestures in Settings > Commands > Scripts. In a reel, the Actions menu has Next reel, Previous reel, Like, Comments, Share, Save, Follow, More options and Say reel info, which says who made it, what it is about and how many likes and comments it has. In a story, the Actions menu and commands have Next story, Previous story, Story of the next person, Story of the previous person, Pause or play, Like, Reply, Comments, Share, More options and Say story info, which says who posted it, how long ago, what the picture is and who is mentioned. When a reel or a story opens, the reading control is set to Actions, so that a swipe up or down goes through them. In the notifications, each one is read as one item, with what it says and the state of its button, and its buttons, such as Follow and Go to the profile, are in its Actions menu. On a profile, the numbers of posts, followers and following are read with a space. In the home feed, the Actions menu of a post has Like, Comment, Repost, Share, Save and More options, for the post that has the focus, and those buttons are left out of the swipes (an option turns that off). The Actions menu of a post also has Show the whole caption, Go to the profile of who posted, Play or pause the video, Turn the sound on or off, Open the music of the post and, in an ad, Open the ad button. A suggestion of a person is read as one item too, with the name, how many friends you have in common and its button. In the Reels tab, a two-finger swipe up goes to the next reel and a two-finger swipe down to the previous one; in every other screen those gestures do what they always do.',
  apps = { 'com.instagram.android' },
  permissions = { 'screen', 'actions', 'speech', 'input' },
  rules = {
    -- A notification: the avatar, the text and a button such as Follow are separate items to swipe to. It is read as one
    -- item: what it says, and the state of its button ("Follow", "Message", "Requested"). Every button in it is an
    -- action of its Actions menu, such as "Go to the profile of ..." and "Follow".
    {
      id = 'activity_feed_newsfeed_story_row',
      group = true,
      read = { { from = { className = 'TextView' } }, { from = { id = 'ig_text' } } },
      buttonActions = true,
    },
    -- A suggestion of a person ("Follow"): the name, how many people you both know and the state of the button are one item,
    -- and its buttons, Follow and Dismiss, are in its Actions menu.
    {
      id = 'igds_people_cell',
      group = true,
      read = {
        { from = { id = 'ig_text' } },
        { from = { id = 'ig_text', textContains = 'em comum' } },
        { from = { id = 'ig_text', textContains = 'mutual' } },
        { from = { id = 'ig_text', inside = { id = 'igds_button' } } },
      },
      buttonActions = true,
    },
    -- The counts of a profile are written "34posts": the number and the word are read with a space.
    {
      id = 'profile_header_post_count_front_familiar',
      read = { { from = { id = 'profile_header_familiar_post_count_value' } }, { from = { id = 'profile_header_familiar_post_count_label' } } },
    },
    {
      id = 'profile_header_followers_stacked_familiar',
      read = { { from = { id = 'profile_header_familiar_followers_value' } }, { from = { id = 'profile_header_familiar_followers_label' } } },
    },
    {
      id = 'profile_header_following_stacked_familiar',
      read = { { from = { id = 'profile_header_familiar_following_value' } }, { from = { id = 'profile_header_familiar_following_label' } } },
    },
  },
  settings = {
    { key = 'hidePostButtons', type = 'switch', title = 'Leave the buttons of a post out of the swipes (they are in its Actions menu)', default = true },
    { key = 'selectActions', type = 'switch', title = 'Select the Actions reading control when a reel or a story opens', default = true },
    { key = 'focusNewReel', type = 'switch', title = 'Put the focus on the new reel after scrolling', default = true },
  },
  commands = {
    { id = 'nextReel', title = 'Next reel', gesture = 'twoFingerSwipeUp' },
    { id = 'previousReel', title = 'Previous reel', gesture = 'twoFingerSwipeDown' },
    { id = 'reelInfo', title = 'Say reel info' },
    { id = 'likeReel', title = 'Like the reel' },
    { id = 'commentsReel', title = 'Open the comments of the reel' },
    { id = 'shareReel', title = 'Share the reel' },
    { id = 'saveReel', title = 'Save the reel' },
    { id = 'followReel', title = 'Follow who made the reel' },
    { id = 'moreReel', title = 'More options of the reel' },
    { id = 'likePost', title = 'Like the post' },
    { id = 'commentPost', title = 'Comment on the post' },
    { id = 'repostPost', title = 'Repost the post' },
    { id = 'sharePost', title = 'Share the post' },
    { id = 'savePost', title = 'Save the post' },
    { id = 'morePost', title = 'More options of the post' },
    { id = 'captionPost', title = 'Show the whole caption' },
    { id = 'profilePost', title = 'Go to the profile of who posted' },
    { id = 'playPost', title = 'Play or pause the video' },
    { id = 'soundPost', title = 'Turn the sound on or off' },
    { id = 'musicPost', title = 'Open the music of the post' },
    { id = 'adButtonPost', title = 'Open the ad button' },
    { id = 'nextStory', title = 'Next story' },
    { id = 'previousStory', title = 'Previous story' },
    { id = 'nextPersonStory', title = 'Story of the next person' },
    { id = 'previousPersonStory', title = 'Story of the previous person' },
    { id = 'pauseStory', title = 'Pause or play the story' },
    { id = 'likeStory', title = 'Like the story' },
    { id = 'replyStory', title = 'Reply to the story' },
    { id = 'commentsStory', title = 'Open the comments of the story' },
    { id = 'shareStory', title = 'Share the story' },
    { id = 'moreStory', title = 'More options of the story' },
    { id = 'storyInfo', title = 'Say story info' },
  },
}

local tr = sf._

local POLL_MS = 100 -- how often the screen is looked at while the reels scroll
local POLL_TRIES = 20 -- so at most 2 s
local SETTLE_MS = 250 -- the page has to settle before the focus is put on it
local SWIPE_MS = 250

-- The buttons of a reel, by the id Instagram gives them. The ids do not change with the language.
local BUTTONS = {
  likeReel = { id = 'like_button', title = 'Like the reel' },
  commentsReel = { id = 'comment_button', title = 'Open the comments of the reel' },
  shareReel = { id = 'direct_share_button', title = 'Share the reel' },
  saveReel = { id = 'save_button', title = 'Save the reel' },
  followReel = { id = 'inline_follow_button', title = 'Follow who made the reel' },
  moreReel = { id = 'clips_ufi_more_button_component', title = 'More options of the reel' },
  -- Stories
  nextStory = { id = 'next_story_button', title = 'Next story' },
  previousStory = { id = 'previous_story_button', title = 'Previous story' },
  pauseStory = { id = 'reel_accessibility_controls', title = 'Pause or play the story' },
  likeStory = { id = 'toolbar_like_button', title = 'Like the story' },
  replyStory = { id = 'message_composer_container', title = 'Reply to the story' },
  commentsStory = { id = 'reel_viewer_comments_button', title = 'Open the comments of the story' },
  shareStory = { id = 'toolbar_reshare_button', title = 'Share the story' },
  moreStory = { id = 'mimicry_top_right_hamburger_container', title = 'More options of the story' },
}
-- The counts under the buttons, read out in this order by "Say reel info".
local COUNTS = { 'like_count', 'comment_count', 'repost_count', 'ufi_text_component', 'save_count' }
local TAB_IDS = { feed_tab = true, clips_tab = true, direct_tab = true, search_tab = true, profile_tab = true }

local function shortId(item)
  return string.match(item.id or '', '[^/]*$')
end

local function setting(key, fallback)
  local ok, value = pcall(sf.settings.get, key)
  if ok and value ~= nil then return value end
  return fallback
end

local function say(text)
  sf.speak(text, { interrupt = true })
end

-- The parts of a spoken summary are joined with ". ", so a part's own final period is left off.
local function join_sentences(parts)
  local cleaned = {}
  for _, part in ipairs(parts) do
    local text = tostring(part):gsub('%.+$', '')
    if text ~= '' then cleaned[#cleaned + 1] = text end
  end
  return table.concat(cleaned, '. ')
end

-- Only what is on the screen counts: the reels before and after the one shown are in the tree too, off the screen.
local function visible(id)
  return sf.screen.find({ id = id, visible = true })
end

local function clickable(node)
  local current = node
  for _ = 1, 4 do
    if not current then break end
    if current.clickable then return current end
    current = current:parent()
  end
  return node
end

-- ======== Where the user is ============================================================================
-- The Actions menu has 50 milliseconds to answer, too short for a search of the screen, so the screen is looked at
-- when it changes and the answer is kept.
local state = { in_reels = false, in_story = false, in_feed = false }

-- SandFly switches the reading control to Actions by itself when focus lands on an item that has actions. The focus
-- lands on the reel or the story at the same time as the screen is looked at here, so the answer of the Actions menu
-- is not yet there. So when a reel or a story opens, the script selects the reading control with the command that
-- SandFly has for it ("Set reading control to Actions").
local ACTIONS_CONTROL = 'SET_READING_CONTROL:pref_selector_actions_key'

local function select_actions_control()
  if setting('selectActions', true) == false then return end
  local listed, commands = pcall(function() return sf.commands.list() end)
  if not listed or type(commands) ~= 'table' then return end
  local found = nil
  for _, command in ipairs(commands) do
    if command.id == ACTIONS_CONTROL then
      found = command.id
      break
    end
  end
  if not found then
    for _, command in ipairs(commands) do
      local id = tostring(command.id)
      if id:find('^SET_READING_CONTROL:') and id:lower():find('actions', 1, true) then
        found = id
        break
      end
    end
  end
  if found then
    pcall(function() sf.commands.run(found) end)
  end
end

local refreshing = false

local function refresh_state()
  if refreshing then return end
  refreshing = true
  local was_open = state.in_reels or state.in_story
  local was_reels, was_story = state.in_reels, state.in_story
  local ok, found = pcall(sf.screen.find, { id = 'clips_viewer_view_pager', visible = true })
  state.in_reels = ok and found ~= nil
  local ok_story, story = pcall(sf.screen.find, { id = 'reel_viewer_root', visible = true })
  state.in_story = ok_story and story ~= nil
  -- The home feed: a post header or the logo bar is on the screen. The mark "selected" of the tab is not used: some
  -- screens of the feed do not have it.
  local in_feed = false
  for _, query in ipairs({
    { id = 'row_feed_profile_header', visible = true },
    { id = 'title_logo', visible = true },
    { id = 'feed_tab', selected = true },
  }) do
    local ok_feed, feed = pcall(sf.screen.find, query)
    if ok_feed and feed ~= nil then
      in_feed = true
      break
    end
  end
  state.in_feed = in_feed and not state.in_reels and not state.in_story
  if (state.in_reels and not was_reels) or (state.in_story and not was_story) then
    -- the focus lands on the reel or the story first; the reading control is changed after that
    sf.sleep(350)
    select_actions_control()
  end
  refreshing = false
end

sf.onContentChange(function() refresh_state() end)
sf.onWindowChange(function() refresh_state() end)
sf.onAppEnter(function() refresh_state() end)

-- ======== The reel on the screen =======================================================================
local function current_reel()
  return visible('clips_media_component')
end

local function reel_key()
  local reel = current_reel()
  return reel and (reel.contentDescription or '') or nil
end

-- "Reel de maria. Toque duas vezes para reproduzir ou pausar." without the part about the double tap.
local function reel_name(reel)
  local description = reel and reel.contentDescription or ''
  description = description:gsub('%. Toque duas vezes.*$', ''):gsub('%. Double.tap.*$', ''):gsub('%. Double tap.*$', '')
  return description
end

-- ======== Scrolling the reels ==========================================================================
local function swipe_pager(pager, forward)
  local bounds = pager.bounds
  if not bounds then return false end
  local x = math.floor((bounds.left + bounds.right) / 2)
  local height = bounds.bottom - bounds.top
  local from = math.floor(bounds.top + height * 0.75)
  local to = math.floor(bounds.top + height * 0.25)
  if not forward then from, to = to, from end
  local ok = pcall(sf.touch.swipe, x, from, x, to, SWIPE_MS)
  return ok
end

local function scroll_reels(forward)
  local pager = visible('clips_viewer_view_pager')
  if not pager then
    say(tr('Open the Reels tab first'))
    return
  end
  local before = reel_key()
  local moved = forward and pager:scrollForward() or pager:scrollBackward()
  if not moved then
    -- the pager did not take the action: a swipe does the same
    moved = swipe_pager(pager, forward)
  end
  if not moved then
    say(tr('Could not scroll the reels'))
    return
  end
  for _ = 1, POLL_TRIES do
    sf.sleep(POLL_MS)
    local key = reel_key()
    if key and key ~= before then break end
  end
  sf.sleep(SETTLE_MS)
  if setting('focusNewReel', true) then
    local reel = current_reel()
    if reel then
      pcall(function() reel:focus() end)
    end
  end
end

-- ======== What the reel is ==============================================================================
local function reel_info()
  local reel = current_reel()
  if not reel then
    say(tr('Open the Reels tab first'))
    return
  end
  local parts = { reel_name(reel) }
  local caption = visible('clips_caption_component')
  if caption then
    local text = caption:find({ clickable = true })
    local words = text and (text.contentDescription or text.text) or ''
    if words ~= '' then parts[#parts + 1] = words end
  end
  for _, id in ipairs(COUNTS) do
    local found = visible(id)
    -- "O número de curtidas é 3190. Ver curtidas": the first sentence is the count
    local count = found and (found.text or found.contentDescription or ''):match('^[^%.]+') or nil
    if count and count ~= '' then parts[#parts + 1] = count end
  end
  say(join_sentences(parts))
end

local function press(which)
  local spec = BUTTONS[which]
  local found = visible(spec.id)
  if not found then
    say(tr('{action} is not available', { action = tr(spec.title) }))
    return
  end
  local button = clickable(found)
  if not button:click() then
    pcall(function() button:tap() end)
  end
end

-- ======== Commands and the Actions menu ================================================================
-- ======== Stories ======================================================================================
-- A swipe across the story: to the left goes to the next person, to the right to the previous one. This is the only
-- way tried: the button action that the story offers answers "done" without doing anything, and trying one way after
-- another when the first seems not to have worked skipped two people.
local function swipe_story(forward)
  local root = visible('reel_viewer_root')
  local bounds = root and root.bounds
  if not bounds then return false end
  local y = math.floor((bounds.top + bounds.bottom) / 2)
  local width = bounds.right - bounds.left
  local from = math.floor(bounds.left + width * 0.85)
  local to = math.floor(bounds.left + width * 0.15)
  if not forward then from, to = to, from end
  return (pcall(sf.touch.swipe, from, y, to, y, SWIPE_MS))
end

local function go_to_person(forward)
  if not visible('reel_viewer_root') then
    local title = forward and tr('Story of the next person') or tr('Story of the previous person')
    say(tr('{action} is not available', { action = title }))
    return
  end
  if swipe_story(forward) then
    -- the new story has the focus put on it, so that what it is gets read
    sf.sleep(SETTLE_MS * 2)
    local controls = visible('reel_accessibility_controls')
    if controls then
      pcall(function() controls:focus() end)
    end
    return
  end
  -- the swipe could not be made: the button goes to the next story, which may be of the next person
  press(forward and 'nextStory' or 'previousStory')
end

local function story_info()
  local header = visible('reel_viewer_text_container')
  if not header then
    say(tr('Open a story first'))
    return
  end
  local parts = { header.contentDescription or header.text or '' }
  local controls = visible('reel_accessibility_controls')
  local what = controls and controls.contentDescription or ''
  if what ~= '' then parts[#parts + 1] = what end
  for _, id in ipairs({ 'reel_app_attribution_action_text', 'attribution_label' }) do
    local found = visible(id)
    local text = found and (found.text or found.contentDescription or '') or ''
    if text ~= '' then parts[#parts + 1] = text end
  end
  local ok, buttons = pcall(sf.screen.findAll, { clickable = true, visible = true }, 80)
  for _, button in ipairs(ok and buttons or {}) do
    local description = button.contentDescription or ''
    if description:find('^Men') then parts[#parts + 1] = description end
  end
  say(join_sentences(parts))
end

-- ======== Posts of the home feed =======================================================================
-- The buttons of a post have no id: each is found by its description, and the ones that belong to the post with the focus
-- are chosen by where they are on the screen. The buttons of a post are below its picture, and "More options" is above.
-- The buttons inside the text of a caption: the one with the name of who posted, the words of the caption (twice) and "more".
local function caption_buttons(wants_more)
  local ok, buttons = pcall(sf.screen.findAll, { role = 'button', clickable = true, visible = true }, 60)
  local found = {}
  for _, button in ipairs(ok and buttons or {}) do
    local parent = button:parent()
    if parent and (parent.className or ''):find('IgTextLayoutView', 1, true) then
      local description = button.contentDescription or ''
      local is_more = description == 'mais' or description == 'Mais' or description == 'more' or description == 'More'
      -- the name of who posted is one word with no spaces; the words of the caption have spaces
      if (wants_more and is_more) or (not wants_more and not is_more and description ~= '' and not description:find('%s')) then
        found[#found + 1] = button
      end
    end
  end
  return found
end

local POST_BUTTONS = {
  likePost = { title = 'Like the post', exact = { 'Curtir', 'Descurtir', 'Like', 'Unlike' } },
  commentPost = { title = 'Comment on the post', exact = { 'Comentar', 'Comment' } },
  repostPost = { title = 'Repost the post', exact = { 'Repost' } },
  sharePost = { title = 'Share the post', contains = { 'Enviar post', 'Send post' } },
  savePost = { title = 'Save the post', exact = { 'Adicionar aos Salvos', 'Remover dos Salvos', 'Save', 'Remove from Saved' } },
  morePost = { title = 'More options of the post', id = 'media_option_button', above = true },
  captionPost = { title = 'Show the whole caption', custom = function() return caption_buttons(true) end },
  profilePost = { title = 'Go to the profile of who posted', custom = function() return caption_buttons(false) end },
  adButtonPost = { title = 'Open the ad button', id = 'cta_container' },
  -- the controls of a video are inside its picture; the music is above it
  playPost = { title = 'Play or pause the video', exact = { 'Pausar', 'Reproduzir', 'Pause', 'Play' }, within = true },
  soundPost = { title = 'Turn the sound on or off', exact = { 'Ativar som', 'Desativar som', 'Mute', 'Unmute' }, within = true },
  musicPost = { title = 'Open the music of the post', id = 'secondary_label', above = true },
}
-- What gets the focus in a post: the picture (media_group), or, in a video, its play button and the sound button; in an
-- ad, the button that opens it ("Learn more").
local POST_MEDIA_IDS = {
  'carousel_video_media_group', 'media_group', 'row_feed_photo', 'zoomable_view', 'row_feed_video', 'video_container',
  'cta_container',
}
local VIDEO_CONTROLS = {
  ['Pausar'] = true, ['Reproduzir'] = true, ['Pause'] = true, ['Play'] = true,
  ['Ativar som'] = true, ['Desativar som'] = true, ['Mute'] = true, ['Unmute'] = true,
}

-- The buttons of a post, left out of the swipes: each is in the Actions menu of the post. Added from code so that an option
-- can turn them off. A button is found by the description of what is in it (a "Like" in a clickable item), the others by
-- their own description or text.
local HIDDEN_DESCRIPTIONS = {
  'Curtir', 'Descurtir', 'Comentar', 'Repost', 'Adicionar aos Salvos', 'Remover dos Salvos',
  'Like', 'Unlike', 'Comment', 'Save', 'Remove from Saved',
  -- the sound button of a video: a clickable group with the words inside
  'Ativar som', 'Desativar som', 'Mute', 'Unmute',
}

local function post_rules()
  local rules = {}
  for _, description in ipairs(HIDDEN_DESCRIPTIONS) do
    -- hasDepth = 1: only the item that has the description as a direct child (the button), never a container above it
    rules[#rules + 1] = { match = { clickable = true, has = { contentDescription = description }, hasDepth = 1 }, hide = 'all' }
  end
  -- "Enviar post. 3 compartilhamentos. Botão...": an image that is not clickable
  rules[#rules + 1] = { match = { className = 'ImageView', contains = 'Enviar post' }, hide = true }
  rules[#rules + 1] = { match = { className = 'ImageView', contains = 'Send post' }, hide = true }
  rules[#rules + 1] = { match = { id = 'media_option_button' }, hide = true }
  -- the buttons of the bar of a post that have an id of their own ("row_feed_button_save" and the like), and the repost icon
  rules[#rules + 1] = { match = { matches = '^row_feed_button_', field = 'id' }, hide = true }
  rules[#rules + 1] = { match = { id = 'reposts_ufi_icon' }, hide = true }
  -- the music of the post ("Acoustic Mode · ..."): it is in the Actions menu
  rules[#rules + 1] = { match = { id = 'secondary_label' }, hide = true }
  -- the counts next to the buttons ("2", "1", "1.257", "3 mil"): a clickable text with only a number; the description of the post already says them
  rules[#rules + 1] = { match = { className = 'TextView', clickable = true, matches = '^[0-9][0-9.,]*( mil| mi)?$', field = 'text' }, hide = true }
  -- the button of an ad ("Chat on WhatsApp"), and the avatars of who follows
  rules[#rules + 1] = { match = { id = 'cta_container' }, hide = 'all' }
  rules[#rules + 1] = { match = { contentDescription = 'Avatares do usuário' }, hide = true }
  -- the buttons inside the caption (who posted, the words, "more") and the name inside "Followed by ...": the text is read
  -- as it is, and what the buttons do is in the Actions menu
  rules[#rules + 1] = { match = { role = 'button', clickable = true, inside = { className = 'IgTextLayoutView' } }, hide = true }
  rules[#rules + 1] = { match = { role = 'button', clickable = true, inside = { textContains = 'Seguido por' } }, hide = true }
  rules[#rules + 1] = { match = { role = 'button', contains = 'Ações para o post' }, hide = true }
  return rules
end

local function apply_post_rules()
  pcall(function() sf.rules.clear() end)
  if setting('hidePostButtons', true) == false then return end
  for _, rule in ipairs(post_rules()) do
    pcall(function() sf.rules.add(rule) end)
  end
end

apply_post_rules()
sf.onSettingChange(function(key)
  if key == 'hidePostButtons' then apply_post_rules() end
end)

local function is_post_media(item)
  local id = shortId(item)
  for _, part in ipairs(POST_MEDIA_IDS) do
    if id:find(part, 1, true) then return true end
  end
  local description = item.contentDescription or ''
  if VIDEO_CONTROLS[description] then return true end
  return description:find('^Foto %d+ de') ~= nil or description:find('^Photo %d+ of') ~= nil
end

local function middle(bounds)
  return (bounds.top + bounds.bottom) / 2
end

-- Of the candidates, the one that belongs to the post with the focus: the nearest one below the focused item (or the one
-- the focus is in); for "More options", the nearest one above.
local function pick_for(focused, candidates, above, within)
  local fb = focused and focused.bounds
  local best, best_gap = nil, nil
  for _, candidate in ipairs(candidates) do
    local cb = candidate.bounds
    if cb then
      local gap
      if not fb then
        gap = middle(cb)
      elseif within then
        -- the controls of a video: the one that is on the picture with the focus
        local center = middle(cb)
        if center >= fb.top - 20 and center <= fb.bottom + 20 then gap = math.abs(center - middle(fb)) end
      elseif above then
        gap = fb.top - cb.bottom
        if gap < -20 then gap = nil end
      else
        gap = cb.top - (fb.bottom - 20)
        if gap < 0 then
          -- the focus is on the buttons themselves: the buttons it is in
          gap = (cb.top <= fb.top + 20 and cb.bottom >= fb.top - 20) and 0 or nil
        end
      end
      if gap and (not best_gap or gap < best_gap) then best, best_gap = candidate, gap end
    end
  end
  return best
end

local function post_candidates(spec)
  local found = {}
  local function add_all(query)
    local ok, list = pcall(sf.screen.findAll, query, 30)
    for _, item in ipairs(ok and list or {}) do found[#found + 1] = item end
  end
  if spec.id then
    add_all({ id = spec.id, visible = true })
  end
  for _, item in ipairs(spec.custom and spec.custom() or {}) do found[#found + 1] = item end
  for _, description in ipairs(spec.exact or {}) do
    add_all({ contentDescription = description, visible = true })
  end
  for _, part in ipairs(spec.contains or {}) do
    add_all({ contains = part, visible = true })
  end
  return found
end

local function press_post(which)
  local spec = POST_BUTTONS[which]
  local focused = sf.screen.focused()
  local target = pick_for(focused, post_candidates(spec), spec.above, spec.within)
  if not target then
    say(tr('{action} is not available', { action = tr(spec.title) }))
    return
  end
  local button = clickable(target)
  if not button:click() then
    pcall(function() button:tap() end)
  end
end

for which in pairs(POST_BUTTONS) do
  sf.onCommand(which, function() press_post(which) end)
end

sf.onCommand('nextStory', function() press('nextStory') end)
sf.onCommand('previousStory', function() press('previousStory') end)
sf.onCommand('nextPersonStory', function() go_to_person(true) end)
sf.onCommand('previousPersonStory', function() go_to_person(false) end)
sf.onCommand('storyInfo', story_info)

-- The two-finger swipes up and down are the gestures of these two commands. Outside the Reels tab, `false` gives them back
-- to SandFly, which scrolls the screen as it always does. This has to be answered before waiting for anything.
local function reel_command(forward)
  return function(event)
    if event and event.via == 'gesture' and not state.in_reels then
      return false
    end
    scroll_reels(forward)
  end
end

sf.onCommand('nextReel', reel_command(true))
sf.onCommand('previousReel', reel_command(false))
sf.onCommand('reelInfo', reel_info)
for which in pairs(BUTTONS) do
  sf.onCommand(which, function() press(which) end)
end

sf.onActions(function(item)
  if TAB_IDS[shortId(item)] then return nil end
  if state.in_feed and not state.in_reels and not state.in_story then
    if not is_post_media(item) then return nil end
    local posts = {}
    for _, which in ipairs({ 'likePost', 'commentPost', 'repostPost', 'sharePost', 'savePost', 'morePost', 'captionPost', 'profilePost', 'playPost', 'soundPost', 'musicPost', 'adButtonPost' }) do
      posts[#posts + 1] = {
        title = tr(POST_BUTTONS[which].title),
        run = function() press_post(which) end,
      }
    end
    return posts
  end
  if not (state.in_reels or state.in_story) then return nil end
  local list = {}
  local function add(title, run)
    list[#list + 1] = { title = tr(title), run = run }
  end
  if state.in_story then
    add('Next story', function() press('nextStory') end)
    add('Previous story', function() press('previousStory') end)
    add('Story of the next person', function() sf.sleep(300) go_to_person(true) end)
    add('Story of the previous person', function() sf.sleep(300) go_to_person(false) end)
    add('Pause or play the story', function() press('pauseStory') end)
    add('Like the story', function() press('likeStory') end)
    add('Reply to the story', function() press('replyStory') end)
    add('Open the comments of the story', function() press('commentsStory') end)
    add('Share the story', function() press('shareStory') end)
    add('More options of the story', function() press('moreStory') end)
    add('Say story info', story_info)
    return list
  end
  add('Next reel', function() sf.sleep(300) scroll_reels(true) end)
  add('Previous reel', function() sf.sleep(300) scroll_reels(false) end)
  add('Like the reel', function() press('likeReel') end)
  add('Open the comments of the reel', function() press('commentsReel') end)
  add('Share the reel', function() press('shareReel') end)
  add('Save the reel', function() press('saveReel') end)
  add('Follow who made the reel', function() press('followReel') end)
  add('More options of the reel', function() press('moreReel') end)
  add('Say reel info', reel_info)
  return list
end)
