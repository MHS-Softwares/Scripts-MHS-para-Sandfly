-- AquaMail (MHS): a SandFly script for the AquaMail e-mail app, by MHS Softwares.
-- In the list of messages, each message is read in a short way (sender, subject, time, attachments), and its Actions
-- menu has Select, Delete, Mark as read, Star and Move to folder. Several messages can be selected, and the focus
-- stays on the message that was selected. In an open message, commands reply, forward and read the header.

local manifest = {
  id = 'aquamail-mhs',
  name = 'AquaMail (MHS)',
  version = '1.2.0',
  author = 'MHS Softwares',
  minApiVersion = 6,
  testedApiVersion = 6,
  description = 'In the list of messages of AquaMail, each message is read in a short way: its state, sender, subject, time and the number of attachments, without the start of the text unless you ask for it. The Actions menu of a message has Select, Delete, Mark as read or unread, Star and Move to folder, and with messages selected it acts on all of them. After a message is selected, the focus stays on it. In an open message, the Actions menu has Reply, Reply to all, Forward, Reply as new, Move to Deleted, Star, Show attachments and Say who sent it, and the same are commands to assign in Settings > Commands > Scripts. When a message opens, the reading control is set to Actions, so that a swipe up or down goes through them. The box that selects a message is not a separate item.',
  apps = { 'org.kman.AquaMail' },
  permissions = { 'screen', 'actions', 'speech', 'input' },
  -- The box on the left of each message of the list is hidden: the message and its box are one item to swipe to.
  rules = {
    { match = { contains = 'Seletor', clickable = true, inside = { id = 'message_item_root' } }, hide = true },
    { match = { contains = 'Selector', clickable = true, inside = { id = 'message_item_root' } }, hide = true },
  },
  settings = {
    { key = 'selectActions', type = 'switch', title = 'Select the Actions reading control when a message opens', default = true },
    { key = 'readPreview', type = 'switch', title = 'Say the start of the text in the list of messages', default = false },
    { key = 'keepFocus', type = 'switch', title = 'Keep the focus on the message that was selected', default = true },
  },
  commands = {
    { id = 'sayInfo', title = 'Say the sender, subject and time of the open message' },
    { id = 'readRow', title = 'Say the whole line of the focused message' },
    { id = 'reply', title = 'Reply to the open message' },
    { id = 'replyAll', title = 'Reply to all in the open message' },
    { id = 'forward', title = 'Forward the open message' },
    { id = 'replyNew', title = 'Reply to the open message as a new one' },
    { id = 'trash', title = 'Move the open message to Deleted' },
  },
}

local tr = sf._

local ROW_ID = 'message_item_root'

-- What AquaMail writes, in Brazilian Portuguese (the texts seen on a real screen) and, as a guess, in English.
local FLAG_PATTERNS = {
  '^[Cc]onversa$', '^[Cc]onversation$',
  '^%d+ mensagens?$', '^%d+ messages?$',
  '^[Ss]elecionadas?$', '^[Ss]elected$',
  '^[Nn]ão lidas?$', '^[Nn]ao lidas?$', '^[Uu]nread$',
}
local SELECTED_PATTERNS = { '^[Ss]elecionadas?$', '^[Ss]elected$' }
local WEEKDAYS = {
  dom = true, seg = true, ter = true, qua = true, qui = true, sex = true, ['sáb'] = true, sab = true,
  mon = true, tue = true, wed = true, thu = true, fri = true, sat = true, sun = true,
}
local ATTACHMENT_PATTERNS = { '^Com anexos?:', '^With attachments?:' }

-- The buttons of the bar that appears when messages are selected, by the description AquaMail gives each one.
local BAR = {
  delete = { 'Mover para Excluídas', 'Mover para a lixeira', 'Move to Deleted', 'Delete' },
  read = { 'Marcar como lida', 'Marcar como não lida', 'Mark as read', 'Mark as unread' },
  star = { 'Marcar com estrelas', 'Remover estrelas', 'Desmarcar estrelas', 'Star', 'Unstar' },
  move = { 'Mover para pasta…', 'Mover para pasta...', 'Move to folder…', 'Move to folder...' },
  all = { 'Selecionar tudo', 'Select all' },
}

-- The buttons in the bar of an open message, by their text.
local OPEN = {
  reply = { 'Responder', 'Reply' },
  replyAll = { 'Responder a todos', 'Reply all', 'Reply to all' },
  forward = { 'Encaminhar', 'Forward' },
  replyNew = { 'Responder (como nova)', 'Reply (as new)', 'Reply as new' },
  trash = { 'Mover para Excluídas', 'Move to Deleted' },
}

local function shortId(item)
  return string.match(item.id or '', '[^/]*$')
end

local function matches_any(text, patterns)
  for _, pattern in ipairs(patterns) do
    if text:find(pattern) then return true end
  end
  return false
end

local function setting(key, fallback)
  local ok, value = pcall(sf.settings.get, key)
  if ok and value ~= nil then return value end
  return fallback
end

-- ======== Reading a message of the list ================================================================
-- The row is one text: "[Conversation, 2 messages,] [Selected,] [Unread,] subject, sender, time, start of the text
-- [, With attachments: names]". The time is the part that tells where the subject and the sender end.

local function tokens_of(text)
  local list = {}
  for part in (text .. ', '):gmatch('(.-), ') do
    list[#list + 1] = part
  end
  return list
end

local function is_time(token)
  if token:find('^%d%d?:%d%d$') or token:find('^%d%d?:%d%d [AaPp][Mm]$') then return true end
  if token:find('^%d%d?/%d%d?/%d%d%d?%d?$') then return true end
  if #token <= 14 and token:find('^%d%d? de [^,]+$') then return true end
  local low = (token:lower():gsub('%.$', ''))
  return low == 'ontem' or low == 'hoje' or low == 'yesterday' or low == 'today' or WEEKDAYS[low] == true
end

-- A short reading of a row, or nil when it isn't in the form that is known (then SandFly says what it always does).
local function condense(text, with_preview)
  local tokens = tokens_of(text)
  local flags, first = {}, 1
  while first <= #tokens and matches_any(tokens[first], FLAG_PATTERNS) do
    flags[#flags + 1] = tokens[first]
    first = first + 1
  end
  local when
  for index = first + 2, #tokens do
    if is_time(tokens[index]) then
      when = index
      break
    end
  end
  if not when then return nil end
  local parts = {}
  for _, flag in ipairs(flags) do parts[#parts + 1] = flag end
  parts[#parts + 1] = tokens[when - 1]
  parts[#parts + 1] = table.concat(tokens, ', ', first, when - 2)
  parts[#parts + 1] = tokens[when]
  local preview, attachments = {}, nil
  for index = when + 1, #tokens do
    if matches_any(tokens[index], ATTACHMENT_PATTERNS) then
      attachments = #tokens - index + 1
      break
    end
    preview[#preview + 1] = tokens[index]
  end
  if attachments then
    parts[#parts + 1] = sf.ngettext('{count} attachment', '{count} attachments', attachments)
  end
  if with_preview and #preview > 0 then
    local start = table.concat(preview, ', ')
    if #start > 160 then start = start:sub(1, 160) .. '…' end
    parts[#parts + 1] = start
  end
  return table.concat(parts, ', ')
end

sf.onFocus(function(item, text)
  if shortId(item) ~= ROW_ID or not item.text or item.text == '' then return nil end
  return condense(item.text, setting('readPreview', false))
end)

local function row_is_selected(row)
  for _, token in ipairs(tokens_of(row.text or '')) do
    if matches_any(token, SELECTED_PATTERNS) then return true end
  end
  return false
end

-- ======== Finding buttons ==============================================================================
local function clickable(node)
  local current = node
  for _ = 1, 4 do
    if not current then break end
    if current.clickable then return current end
    current = current:parent()
  end
  return node
end

-- A button of the bar of the list: the description is what AquaMail says for it, and only the ones on the screen
-- count (the same buttons are off the screen while nothing is selected).
local function bar_button(descriptions)
  for _, description in ipairs(descriptions) do
    local found = sf.screen.find({ id = 'bb_item_image', contentDescription = description, visible = true })
    if found then return found end
  end
  return nil
end

local function wait_for(find, tries)
  for _ = 1, tries or 10 do
    local found = find()
    if found then return found end
    sf.sleep(150)
  end
  return nil
end

local function selection_active()
  local ok, found = pcall(sf.screen.find, { id = 'message_list_side_action_text', visible = true })
  return ok and found ~= nil
end

-- What is on the screen, looked at when the screen changes and kept: the Actions menu has 50 milliseconds to answer,
-- too short for a search of the screen, so it only reads this.
local state = { selecting = false, in_message = false }

-- Text on a web page, such as the body of a message, keeps the reading control it had: SandFly only switches to Actions
-- by itself for other items. So when a message opens, the script selects the Actions reading control, with the command
-- that SandFly has for it ("Set reading control to Actions").
local ACTIONS_CONTROL = 'SET_READING_CONTROL:pref_selector_actions_key'

local function select_actions_control()
  if setting('selectActions', true) == false then return end
  local listed, commands = pcall(function() return sf.commands.list() end)
  if not listed or type(commands) ~= 'table' then return end
  local found = nil
  for _, command in ipairs(commands) do
    if command.id == ACTIONS_CONTROL then
      found = command.id
      break
    end
  end
  if not found then
    -- the key may be written another way: any command that selects a control with "actions" in its key
    for _, command in ipairs(commands) do
      local id = tostring(command.id)
      if id:find('^SET_READING_CONTROL:') and id:lower():find('actions', 1, true) then
        found = id
        break
      end
    end
  end
  if found then
    pcall(function() sf.commands.run(found) end)
  end
end

local refreshing = false

local function refresh_state()
  if refreshing then return end
  refreshing = true
  local was_in_message = state.in_message
  state.selecting = selection_active()
  local ok, found = pcall(sf.screen.find, { id = 'message_position_info', visible = true })
  state.in_message = ok and found ~= nil
  if state.in_message and not was_in_message then
    -- the focus lands on the message first; the reading control is changed after that
    sf.sleep(350)
    select_actions_control()
  end
  refreshing = false
end

sf.onContentChange(function() refresh_state() end)
sf.onWindowChange(function() refresh_state() end)
sf.onAppEnter(function() refresh_state() end)

-- ======== Keep the focus on the message that was selected ============================================
-- AquaMail redraws the list when a message is selected, and the focus of SandFly goes back to the first one. The message
-- is remembered before, and the focus is put back on it afterwards, so that the next swipe goes to the one below it.
local function text_of(item)
  local own = item.contentDescription
  if own == nil or own == '' then own = item.text end
  return (tostring(own or ''):gsub('%s+', ' '))
end

local function remember(item)
  local text = text_of(item)
  return {
    first = text:sub(1, 30),
    last = #text > 30 and text:sub(-30) or '',
    top = item.bounds and item.bounds.top or 0,
    id = item.id,
  }
end

-- The same message as it is now: the one with the text it had, nearest to where it was. The end of the text comes
-- before the start, which changes when "Selected" is put in front.
local function find_again(memo)
  for _, key in ipairs({ memo.last, memo.first }) do
    if key ~= '' then
      local query = { contains = key, visible = true }
      if memo.id then query.id = memo.id end
      local ok, found = pcall(sf.screen.findAll, query, 30)
      local best, best_gap = nil, nil
      for _, candidate in ipairs(ok and found or {}) do
        local gap = math.abs((candidate.bounds and candidate.bounds.top or 0) - memo.top)
        if not best or gap < best_gap then best, best_gap = candidate, gap end
      end
      if best then return best end
    end
  end
  return nil
end

-- Looks twice, a little after the action and a little later, for the focus having gone back up. A focus that has moved
-- down, as when the user swipes on, is left alone.
local function keep_focus_on(memo)
  if setting('keepFocus', true) == false then return end
  for _ = 1, 2 do
    sf.sleep(350)
    local target = find_again(memo)
    if target then
      local focused = sf.screen.focused()
      local went_up = focused == nil or ((focused.bounds and focused.bounds.top or 0) < memo.top - 5)
      if focused ~= target and went_up then
        pcall(function() target:focus() end)
      end
    end
  end
end

-- ======== Actions of a message in the list ============================================================
-- Selects the message, or takes it off, with the box on its left, or with a long press if that fails.
local function toggle_row(row)
  local memo = remember(row)
  local box = row:find({ contains = 'Seletor' }) or row:find({ contains = 'Selector' })
  local ok = box and box:click()
  if not ok then
    ok = row:longClick()
  end
  if not ok then
    local good, held = pcall(function() return row:longPress(1000) end)
    ok = good and held
  end
  if not ok then
    sf.speak(tr('Could not select the message'))
    return false
  end
  keep_focus_on(memo)
  return true
end

local function bar_action(row, which, title, selecting)
  sf.sleep(300)
  if not selecting and not row_is_selected(row) then
    -- nothing is selected yet: the message is selected first, and the button of the bar then acts on it
    local box = row:find({ contains = 'Seletor' }) or row:find({ contains = 'Selector' })
    if not ((box and box:click()) or row:longClick()) then
      sf.speak(tr('Could not select the message'))
      return
    end
  end
  local button = wait_for(function() return bar_button(BAR[which]) end)
  if not button then
    sf.speak(tr('{action} is not available', { action = title }))
    return
  end
  button:click()
end

-- A button of the bar of an open message: found by its text and pressed.
local function press_open(which, title)
  for _, text in ipairs(OPEN[which]) do
    local found = sf.screen.find({ id = 'bottomSheetItemText', text = text, visible = true })
    if found then
      local button = clickable(found)
      if not button:click() then pcall(function() button:tap() end) end
      return
    end
  end
  sf.speak(tr('{action} is not available', { action = title }), { interrupt = true })
end

local function press_visible(id, title)
  local found = sf.screen.find({ id = id, visible = true })
  if not found then
    sf.speak(tr('{action} is not available', { action = title }), { interrupt = true })
    return
  end
  local button = clickable(found)
  if not button:click() then pcall(function() button:tap() end) end
end

local function say_info()
  local parts = {}
  for _, id in ipairs({ 'message_from_short', 'message_subject_short', 'message_when_short', 'message_position_info' }) do
    local found = sf.screen.find({ id = id, visible = true })
    local text = found and (found.text or found.contentDescription) or ''
    if text ~= '' then parts[#parts + 1] = text end
  end
  if #parts == 0 then
    sf.speak(tr('Open a message first'), { interrupt = true })
    return
  end
  sf.speak(table.concat(parts, ', '), { interrupt = true })
end

sf.onActions(function(item)
  local list = {}
  local function add(title, run)
    list[#list + 1] = { title = tr(title), run = run }
  end
  if shortId(item) == ROW_ID then
    -- This row may be the only one selected even if the screen was not looked at yet.
    local selecting = state.selecting or row_is_selected(item)
    if selecting then
      add('Select or deselect message', function() sf.sleep(300) toggle_row(item) end)
      add('Delete selected messages', function() bar_action(item, 'delete', tr('Delete selected messages'), true) end)
      add('Mark selected messages as read or unread', function() bar_action(item, 'read', tr('Mark selected messages as read or unread'), true) end)
      add('Star selected messages', function() bar_action(item, 'star', tr('Star selected messages'), true) end)
      add('Move selected messages to a folder', function() bar_action(item, 'move', tr('Move selected messages to a folder'), true) end)
      add('Select all messages', function() bar_action(item, 'all', tr('Select all messages'), true) end)
    else
      add('Select message', function() sf.sleep(300) toggle_row(item) end)
      add('Delete message', function() bar_action(item, 'delete', tr('Delete message'), false) end)
      add('Mark as read or unread', function() bar_action(item, 'read', tr('Mark as read or unread'), false) end)
      add('Star message', function() bar_action(item, 'star', tr('Star message'), false) end)
      add('Move message to a folder', function() bar_action(item, 'move', tr('Move message to a folder'), false) end)
    end
    return list
  end
  if state.in_message then
    add('Reply', function() press_open('reply', tr('Reply')) end)
    add('Reply to all', function() press_open('replyAll', tr('Reply to all')) end)
    add('Forward', function() press_open('forward', tr('Forward')) end)
    add('Reply as new', function() press_open('replyNew', tr('Reply as new')) end)
    add('Move to Deleted', function() press_open('trash', tr('Move to Deleted')) end)
    add('Star or unstar message', function() press_visible('message_star', tr('Star or unstar message')) end)
    add('Show attachments', function() press_visible('message_show_attachments', tr('Show attachments')) end)
    add('Say sender, subject and time', say_info)
    return list
  end
  return nil
end)

-- ======== Commands ====================================================================================
sf.onCommand('readRow', function(event)
  local item = event and event.node or sf.screen.focused()
  if not item or shortId(item) ~= ROW_ID or not item.text then
    sf.speak(tr('Focus a message in the list first'), { interrupt = true })
    return
  end
  sf.speak(item.text, { interrupt = true })
end)

sf.onCommand('sayInfo', say_info)

sf.onCommand('reply', function() press_open('reply', tr('Reply to the open message')) end)
sf.onCommand('replyAll', function() press_open('replyAll', tr('Reply to all in the open message')) end)
sf.onCommand('forward', function() press_open('forward', tr('Forward the open message')) end)
sf.onCommand('replyNew', function() press_open('replyNew', tr('Reply to the open message as a new one')) end)
sf.onCommand('trash', function() press_open('trash', tr('Move the open message to Deleted')) end)
