local manifest = {
  id = 'auto-clicks-mhs',
  name = 'Automatic clicks (MHS)',
  version = '1.5',
  author = 'MHS Softwares',
  minApiVersion = 6,
  testedApiVersion = 6,
  description = 'Builds a list of buttons that are pressed one after the other in an app. On each screen, add the focused item, or a name you copied, as a step. When you run the sequence, the script waits for each button to show up and presses it. A `*` in the name of a step stands for any text, and the command that ignores numbers makes one for you, for buttons such as "Clear chat (723.2 MB)". A step can be a long press. A sequence belongs to the app where you made it, and can be given a slot, which is a command of its own that you assign to a gesture. Assign the commands in Settings > Commands > Scripts to gestures.',
  permissions = { 'screen', 'actions', 'speech', 'clipboard', 'dialogs' },
  onDemand = true,
  settings = {
    { key = 'waitLimit', type = 'number', title = 'Seconds to wait for each button (0 = no limit)', default = 0 },
    { key = 'pressPause', type = 'number', title = 'Pause after each press, in milliseconds', default = 50 },
    { key = 'quiet', type = 'switch', title = 'Silence the screen reader while pressing', default = true },
  },
  commands = {
    { id = 'addFocused', title = 'Add the focused item to the sequence' },
    { id = 'addFocusedAnyNumber', title = 'Add the focused item to the sequence, ignoring numbers' },
    { id = 'addFocusedLong', title = 'Add the focused item to the sequence as a long press' },
    { id = 'addCopied', title = 'Add the copied text to the sequence' },
    { id = 'run', title = 'Run the sequence (again to stop)' },
    { id = 'removeLast', title = 'Remove the last step of the sequence' },
    { id = 'newSequence', title = 'New sequence' },
    { id = 'chooseSequence', title = 'Choose the sequence' },
    { id = 'manage', title = 'Manage sequences' },
    { id = 'runSlot1', title = 'Run the sequence of slot 1' },
    { id = 'runSlot2', title = 'Run the sequence of slot 2' },
    { id = 'runSlot3', title = 'Run the sequence of slot 3' },
    { id = 'runSlot4', title = 'Run the sequence of slot 4' },
    { id = 'runSlot5', title = 'Run the sequence of slot 5' },
    { id = 'runSlot6', title = 'Run the sequence of slot 6' },
    { id = 'runSlot7', title = 'Run the sequence of slot 7' },
    { id = 'runSlot8', title = 'Run the sequence of slot 8' },
    { id = 'runSlot9', title = 'Run the sequence of slot 9' },
    { id = 'runSlot10', title = 'Run the sequence of slot 10' },
  },
}

local tr = sf._

local POLL_FAST_MS = 50 -- how often the screen is looked at while a button is awaited, at first
local POLL_SLOW_MS = 150 -- and once it has taken a while, to go easy on a busy app
local FAST_MS = 3000 -- how long the quick looks last
local GRACE_MS = 1500 -- how long only the whole name is accepted
local RENEW_MS = 8000 -- how often the silence of the screen reader is renewed (SandFly allows 10 s at a time)
local SAME_NAME_PAUSE_MS = 500 -- least pause before a step with the same name as the one before
local MAX_UP = 7 -- how many levels above a text the button that holds it is looked for

local function say(text)
  sf.speak(text, { interrupt = true })
end

-- A step as it is read out: "Long press: Reply" for a long press, otherwise just the name.
local function step_label(step)
  if step.long then
    return tr('Long press') .. ': ' .. step.text
  end
  return step.text
end

-- What is kept: { seqs = { { name, pkg, steps = { { text } } } }, current = { [package] = sequence name } }.
local function load_data()
  local data = sf.storage.get('data', nil)
  if type(data) ~= 'table' then
    data = {}
  end
  data.seqs = data.seqs or {}
  data.current = data.current or {}
  return data
end

local function save_data(data)
  sf.storage.set('data', data)
end

local function app_package()
  local ok, app = pcall(sf.app)
  if ok and app and app.package and app.package ~= '' then
    return app.package
  end
  return nil
end

local function trim(text)
  if text == nil then
    return nil
  end
  local clean = tostring(text):gsub('^%s+', ''):gsub('%s+$', '')
  if clean == '' then
    return nil
  end
  return clean
end

local function seqs_of(data, pkg)
  local list = {}
  for _, seq in ipairs(data.seqs) do
    if seq.pkg == pkg then
      list[#list + 1] = seq
    end
  end
  return list
end

local function find_seq(data, pkg, name)
  for _, seq in ipairs(data.seqs) do
    if seq.pkg == pkg and seq.name == name then
      return seq
    end
  end
  return nil
end

local function make_seq(data, pkg, name)
  local seq = { name = name, pkg = pkg, steps = {} }
  data.seqs[#data.seqs + 1] = seq
  data.current[pkg] = name
  return seq
end

-- The sequence of this app that is in use. With several and none chosen, asks which. With none, makes one if `create`.
local function pick_sequence(data, pkg, create)
  local seq = data.current[pkg] and find_seq(data, pkg, data.current[pkg])
  if seq then
    return seq
  end
  local list = seqs_of(data, pkg)
  if #list == 1 then
    data.current[pkg] = list[1].name
    return list[1]
  end
  if #list == 0 then
    if create then
      return make_seq(data, pkg, tr('Sequence') .. ' 1')
    end
    return nil
  end
  local choices = {}
  for i, item in ipairs(list) do
    choices[i] = { value = item.name, label = item.name }
  end
  local name = sf.ui.choose(tr('Which sequence?'), choices)
  if not name then
    return nil
  end
  data.current[pkg] = name
  return find_seq(data, pkg, name)
end

-- The name a button goes by: its text or description, or the first one found inside it.
local function name_of(item)
  local name = trim(item.text) or trim(item.contentDescription)
  if name then
    return name
  end
  local seen = 0
  local function look(node, depth)
    if depth > 4 or seen > 40 then
      return nil
    end
    for _, child in ipairs(node:children() or {}) do
      seen = seen + 1
      local found = trim(child.text) or trim(child.contentDescription) or look(child, depth + 1)
      if found then
        return found
      end
    end
    return nil
  end
  return look(item, 1)
end

local function regex_escape(text)
  return (text:gsub('[%^%$%(%)%.%[%]%*%+%-%?%{%}%|\\]', '\\%0'))
end

-- The button with this name on the screen: the name as a whole first, then any button that has it in its name.
-- A `*` in the name stands for anything ("Clear chat (*)" is "Clear chat (723.2 MB)" and any other size).
local function whole_name_pattern(text)
  return '^' .. regex_escape(text):gsub('\\%*', '.*') .. '$'
end

local function find_button(text, partial, long)
  local kind = long and 'longClickable' or 'clickable'
  local queries = {
    { matches = whole_name_pattern(text), kind = kind, visible = true },
  }
  if partial and not text:find('*', 1, true) then
    queries[2] = { contains = text, kind = kind, visible = true }
  end
  for _, query in ipairs(queries) do
    local ok, item = pcall(sf.screen.find, query)
    if ok and item then
      return item
    end
  end
  return nil
end

local running = false
local stop_requested = false

-- Waits for the button, with no limit unless `limit_s` is more than 0. The name as a whole is looked for first. A button
-- that only has the name in its own name is accepted after a short while, so that "More" doesn't press "More options",
-- still on the screen, before the new screen has shown. `renew` is called now and then, while the wait goes on.
local function wait_for_button(text, limit_s, renew, long)
  local limit_ms = limit_s > 0 and limit_s * 1000 or nil
  local elapsed, next_renew = 0, RENEW_MS
  while true do
    if stop_requested then
      return nil
    end
    local item = find_button(text, elapsed >= GRACE_MS, long)
    if item then
      return item
    end
    if limit_ms and elapsed >= limit_ms then
      return find_button(text, true, long)
    end
    local step = elapsed < FAST_MS and POLL_FAST_MS or POLL_SLOW_MS
    sf.sleep(step)
    elapsed = elapsed + step
    if renew and elapsed >= next_renew then
      renew()
      next_renew = next_renew + RENEW_MS
    end
  end
end

-- The item that holds the one found and can be pressed (or long pressed): the item itself, or the first one around it.
local function pressable(item, field)
  local target = item
  for _ = 1, MAX_UP do
    if target[field] then
      return target
    end
    local parent = target:parent()
    if not parent then
      break
    end
    target = parent
  end
  return target[field] and target or item
end

-- Presses the button that holds the item, or long presses it.
local function press(item, long)
  if long then
    local ok = pressable(item, 'longClickable'):longClick()
    if ok == false then
      local good, held = pcall(function() return item:longPress(1000) end)
      ok = good and held
    end
    return ok ~= false
  end
  local ok = pressable(item, 'clickable'):click()
  if ok == false then
    local good, tapped = pcall(function() return item:tap() end)
    ok = good and tapped
  end
  return ok ~= false
end

local function number_setting(key, low, high, fallback)
  local ok, value = pcall(sf.settings.get, key)
  value = ok and tonumber(value) or fallback
  return math.min(high, math.max(low, value))
end

local function quiet_setting()
  local ok, value = pcall(sf.settings.get, 'quiet')
  return not ok or value ~= false
end

local function run_sequence(seq)
  local limit = number_setting('waitLimit', 0, 3600, 0)
  local pause = number_setting('pressPause', 0, 5000, 50)
  local quiet = quiet_setting()
  local mute = nil
  local function mute_now()
    if quiet then
      local ok, handle = pcall(sf.feedback.mute, { speech = true }, 10000)
      mute = ok and handle or mute
    end
  end
  local function unmute()
    if mute then
      pcall(mute.release)
      mute = nil
    end
  end
  local outcome = 'done'
  local missing = nil
  for index, step in ipairs(seq.steps) do
    if stop_requested then
      outcome = 'stopped'
      break
    end
    mute_now()
    local item = wait_for_button(step.text, limit, mute_now, step.long)
    if not item then
      outcome = stop_requested and 'stopped' or 'missing'
      missing = step.text
      break
    end
    press(item, step.long)
    local following = seq.steps[index + 1]
    if following then
      -- two steps with the same name: the button just pressed may still be on the screen for a moment
      local gap = pause
      if following.text == step.text and following.long == step.long then
        gap = math.max(pause, SAME_NAME_PAUSE_MS)
      end
      sf.sleep(gap)
    end
  end
  unmute()
  if outcome == 'missing' then
    say(string.format(tr('Could not find "%s"'), missing))
  elseif outcome == 'stopped' then
    say(tr('Stopped'))
  else
    say(tr('Done'))
  end
end

local function start_run(seq)
  if #seq.steps == 0 then
    say(tr('The sequence has no steps'))
    return
  end
  running = true
  stop_requested = false
  local ok, err = pcall(run_sequence, seq)
  running = false
  stop_requested = false
  if not ok then
    error(err, 0)
  end
end

sf.onCommand('run', function()
  if running then
    stop_requested = true
    return
  end
  local pkg = app_package()
  if not pkg then
    say(tr('No app in front'))
    return
  end
  local data = load_data()
  local seq = pick_sequence(data, pkg, false)
  save_data(data)
  if not seq then
    say(tr('No sequence for this app. Add steps first'))
    return
  end
  start_run(seq)
end)

-- Slots: commands of their own, one gesture each. A slot holds the name of a sequence of the app in front.
local SLOTS = 10

local function slot_name(data, pkg, n)
  local slots = data.slots and data.slots[pkg]
  return slots and slots[tostring(n)]
end

for n = 1, SLOTS do
  sf.onCommand('runSlot' .. n, function()
    if running then
      stop_requested = true
      return
    end
    local pkg = app_package()
    if not pkg then
      say(tr('No app in front'))
      return
    end
    local data = load_data()
    local name = slot_name(data, pkg, n)
    local seq = name and find_seq(data, pkg, name)
    if not seq then
      say(string.format(tr('Slot %d has no sequence in this app'), n))
      return
    end
    start_run(seq)
  end)
end

local function add_step(text, long)
  local pkg = app_package()
  if not pkg then
    say(tr('No app in front'))
    return
  end
  local data = load_data()
  local seq = pick_sequence(data, pkg, true)
  if not seq then
    return
  end
  local step = { text = text }
  if long then
    step.long = true
  end
  seq.steps[#seq.steps + 1] = step
  save_data(data)
  say(string.format(tr('Step %d: %s'), #seq.steps, step_label(step)))
end

sf.onCommand('addFocused', function(event)
  local item = event and event.node or sf.screen.focused()
  if not item then
    say(tr('Nothing is focused'))
    return
  end
  local text = name_of(item)
  if not text then
    say(tr('This item has no name'))
    return
  end
  add_step(text)
end)

-- "Clear chat (723.2 MB)" becomes "Clear chat (*)": numbers, with the unit after them, vary from one time to the next.
local function without_numbers(text)
  text = text:gsub('%d[%d.,]*%s*[KkMmGgTt]?[Bb]%f[%A]', '*')
  return (text:gsub('%d[%d.,]*', '*'))
end

sf.onCommand('addFocusedAnyNumber', function(event)
  local item = event and event.node or sf.screen.focused()
  if not item then
    say(tr('Nothing is focused'))
    return
  end
  local text = name_of(item)
  if not text then
    say(tr('This item has no name'))
    return
  end
  add_step(without_numbers(text))
end)

sf.onCommand('addFocusedLong', function(event)
  local item = event and event.node or sf.screen.focused()
  if not item then
    say(tr('Nothing is focused'))
    return
  end
  local text = name_of(item)
  if not text then
    say(tr('This item has no name'))
    return
  end
  add_step(text, true)
end)

sf.onCommand('addCopied', function()
  local copied = sf.clipboard.get()
  local first = nil
  for line in tostring(copied or ''):gmatch('[^\r\n]+') do
    first = trim(line)
    if first then
      break
    end
  end
  if not first then
    say(tr('Nothing copied'))
    return
  end
  add_step(first)
end)

sf.onCommand('removeLast', function()
  local pkg = app_package()
  if not pkg then
    say(tr('No app in front'))
    return
  end
  local data = load_data()
  local seq = pick_sequence(data, pkg, false)
  if not seq or #seq.steps == 0 then
    say(tr('The sequence has no steps'))
    return
  end
  local removed = table.remove(seq.steps)
  save_data(data)
  say(string.format(tr('Removed step %d: %s'), #seq.steps + 1, step_label(removed)))
end)

local function new_sequence(data, pkg)
  local suggestion = tr('Sequence') .. ' ' .. (#seqs_of(data, pkg) + 1)
  local name = trim(sf.ui.prompt(tr('Name of the new sequence'), { text = suggestion }))
  if not name then
    return nil
  end
  if find_seq(data, pkg, name) then
    say(tr('There is already a sequence with that name'))
    return nil
  end
  return make_seq(data, pkg, name)
end

sf.onCommand('newSequence', function()
  local pkg = app_package()
  if not pkg then
    say(tr('No app in front'))
    return
  end
  local data = load_data()
  local seq = new_sequence(data, pkg)
  if seq then
    save_data(data)
    say(string.format(tr('Sequence %s created. Add its steps'), seq.name))
  end
end)

local function choose_sequence(data, pkg)
  local list = seqs_of(data, pkg)
  if #list == 0 then
    say(tr('No sequence for this app. Add steps first'))
    return nil
  end
  local choices = {}
  for i, item in ipairs(list) do
    choices[i] = { value = item.name, label = item.name .. ' (' .. #item.steps .. ')' }
  end
  local name = sf.ui.choose(tr('Which sequence?'), choices, { selected = data.current[pkg] })
  if not name then
    return nil
  end
  data.current[pkg] = name
  return find_seq(data, pkg, name)
end

sf.onCommand('chooseSequence', function()
  local pkg = app_package()
  if not pkg then
    say(tr('No app in front'))
    return
  end
  local data = load_data()
  local seq = choose_sequence(data, pkg)
  if seq then
    save_data(data)
    say(string.format(tr('Sequence %s'), seq.name))
  end
end)

-- The steps as a list to choose from: "1. Send".
local function step_choices(seq)
  local choices = {}
  for i, step in ipairs(seq.steps) do
    choices[i] = { value = i, label = i .. '. ' .. step_label(step) }
  end
  return choices
end

local function manage_once(data, pkg)
  local seq = pick_sequence(data, pkg, false)
  local title = seq and (tr('Sequence') .. ': ' .. seq.name) or tr('Sequences')
  local actions = {
    { value = 'view', label = tr('Say the steps') },
    { value = 'edit', label = tr('Edit a step') },
    { value = 'move', label = tr('Move a step') },
    { value = 'delete', label = tr('Delete a step') },
    { value = 'new', label = tr('New sequence') },
    { value = 'choose', label = tr('Choose the sequence') },
    { value = 'longpress', label = tr('Switch a step between press and long press') },
    { value = 'slot', label = tr('Give the sequence a slot') },
    { value = 'slots', label = tr('Say the slots') },
    { value = 'rename', label = tr('Rename the sequence') },
    { value = 'remove', label = tr('Delete the sequence') },
  }
  local action = sf.ui.choose(title, actions)
  if not action then
    return false
  end
  if action == 'new' then
    new_sequence(data, pkg)
    return true
  elseif action == 'choose' then
    choose_sequence(data, pkg)
    return true
  elseif action == 'slots' then
    local lines = {}
    for n = 1, SLOTS do
      lines[n] = n .. '. ' .. (slot_name(data, pkg, n) or tr('(free)'))
    end
    sf.ui.text(tr('Slots'), table.concat(lines, '\n'))
    return true
  end
  if not seq then
    say(tr('No sequence for this app. Add steps first'))
    return false
  end
  if action == 'rename' then
    local name = trim(sf.ui.prompt(tr('New name of the sequence'), { text = seq.name }))
    if name and name ~= seq.name then
      if find_seq(data, pkg, name) then
        say(tr('There is already a sequence with that name'))
      else
        if data.current[pkg] == seq.name then
          data.current[pkg] = name
        end
        for key, held in pairs((data.slots or {})[pkg] or {}) do
          if held == seq.name then
            data.slots[pkg][key] = name
          end
        end
        seq.name = name
      end
    end
    return true
  elseif action == 'remove' then
    if sf.ui.confirm(string.format(tr('Delete the sequence %s and its steps?'), seq.name)) then
      for i, item in ipairs(data.seqs) do
        if item == seq then
          table.remove(data.seqs, i)
          break
        end
      end
      data.current[pkg] = nil
      for key, held in pairs((data.slots or {})[pkg] or {}) do
        if held == seq.name then
          data.slots[pkg][key] = nil
        end
      end
    end
    return true
  elseif action == 'slot' then
    local choices = {}
    for n = 1, SLOTS do
      choices[n] = { value = n, label = n .. '. ' .. (slot_name(data, pkg, n) or tr('(free)')) }
    end
    local n = tonumber(sf.ui.choose(string.format(tr('Slot for %s'), seq.name), choices))
    if n and n >= 1 and n <= SLOTS then
      data.slots = data.slots or {}
      data.slots[pkg] = data.slots[pkg] or {}
      data.slots[pkg][tostring(n)] = seq.name
      say(string.format(tr('Slot %d: %s'), n, seq.name))
    end
    return true
  end
  if #seq.steps == 0 then
    say(tr('The sequence has no steps'))
    return true
  end
  if action == 'view' then
    local lines = {}
    for i, step in ipairs(seq.steps) do
      lines[i] = i .. '. ' .. step_label(step)
    end
    sf.ui.text(seq.name, table.concat(lines, '\n'))
    return true
  end
  -- sf.ui.choose gives the chosen value as text, so "4", not 4
  local index = tonumber(sf.ui.choose(tr('Which step?'), step_choices(seq)))
  local step = index and seq.steps[index]
  if not step then
    return true
  end
  if action == 'edit' then
    local text = trim(sf.ui.prompt(tr('Name of the button'), { text = step.text }))
    if text then
      step.text = text
    end
  elseif action == 'longpress' then
    step.long = (not step.long) or nil
    say(string.format(tr('Step %d: %s'), index, step_label(step)))
  elseif action == 'delete' then
    if sf.ui.confirm(string.format(tr('Delete step %d: %s?'), index, step_label(step))) then
      table.remove(seq.steps, index)
    end
  elseif action == 'move' then
    local choices = {}
    if index > 1 then
      choices[#choices + 1] = { value = -1, label = tr('Move up') }
    end
    if index < #seq.steps then
      choices[#choices + 1] = { value = 1, label = tr('Move down') }
    end
    if #choices == 0 then
      return true
    end
    local delta = tonumber(sf.ui.choose(tr('Move the step'), choices))
    if delta then
      seq.steps[index], seq.steps[index + delta] = seq.steps[index + delta], seq.steps[index]
    end
  end
  return true
end

sf.onCommand('manage', function()
  local pkg = app_package()
  if not pkg then
    say(tr('No app in front'))
    return
  end
  while true do
    local data = load_data()
    local again = manage_once(data, pkg)
    save_data(data)
    if not again then
      return
    end
  end
end)
