local manifest = {
  id = 'record-and-share-mhs',
  name = 'Record and share (MHS)',
  version = '1.3',
  author = 'MHS Softwares',
  minApiVersion = 6,
  testedApiVersion = 6,
  description = 'Records audio in stereo (AAC, 192 kbps) and, when you stop, opens the share sheet with the recording. Assign the command Record audio, then share, in Settings > Commands > Scripts, to a gesture: the first time starts recording, the next stops it and shares the file. The files are in the Music folder, in MHS_Recordings. SandFly needs the microphone permission in Android settings.',
  permissions = { 'speech', 'java' },
  settings = {
    { key = 'speakStart', type = 'switch', title = 'Say Recording in stereo when recording starts', default = false },
  },
  commands = {
    { id = 'toggleRecording', title = 'Record audio, then share' },
  },
}

local tr = sf._

-- The step the script is in, so that a failure can say where it happened.
local step = ''
local function mark(name)
  step = name
end

-- The recording is kept in Java, in the properties of the process, and not in a variable of the
-- script: SandFly unloads a script when the screen turns off or when it is reloaded, and a recording
-- that only the script knew of could never be stopped.
local KEY = 'mhs.recording.'
local FIELDS = { 'recorder', 'pfd', 'uri', 'file' }

local function properties()
  return java.import('java.lang.System'):getProperties()
end

local function get_recording()
  local props = properties()
  local recorder = props:get(KEY .. 'recorder')
  if not recorder then
    return nil
  end
  return {
    recorder = recorder,
    pfd = props:get(KEY .. 'pfd'),
    uri = props:get(KEY .. 'uri'),
    file = props:get(KEY .. 'file'),
  }
end

local function set_recording(r)
  local props = properties()
  for _, field in ipairs(FIELDS) do
    local value = r and r[field]
    if value then
      props:put(KEY .. field, value)
    else
      props:remove(KEY .. field)
    end
  end
end

local function app_context()
  local context = java.import('android.app.ActivityThread'):currentApplication()
  if not context then
    error('SandFly has no context')
  end
  return context
end

-- Vibrates through Android itself, as the Jieshuo plugin did, and not through SandFly, whose own
-- vibration settings can turn it off. SandFly's is the fallback.
local function buzz(ms)
  local ok = pcall(function()
    local vibrator = app_context():getSystemService('vibrator')
    vibrator:vibrate(java.import('android.os.VibrationEffect'):createOneShot(ms, -1))
  end)
  if not ok then
    sf.vibrate(ms)
  end
end

-- Where the file goes. From Android 10 on, in the Music folder through MediaStore, which needs no
-- permission; if that fails, in the files folder of SandFly.
local function open_output(context, name)
  local Version = java.import('android.os.Build$VERSION')
  if Version.SDK_INT >= 29 then
    local ok, out = pcall(function()
      local values = java.new(java.import('android.content.ContentValues'))
      values:put('_display_name', name .. '.m4a')
      values:put('mime_type', 'audio/mp4')
      values:put('relative_path', 'Music/MHS_Recordings')
      values:put('is_pending', java.import('java.lang.Integer'):valueOf(1))
      local resolver = context:getContentResolver()
      local uri = resolver:insert(java.import('android.provider.MediaStore$Audio$Media').EXTERNAL_CONTENT_URI, values)
      local pfd = resolver:openFileDescriptor(uri, 'w')
      return { uri = uri, pfd = pfd, fd = pfd:getFileDescriptor() }
    end)
    if ok and out then
      return out
    end
    print('MediaStore failed: ' .. tostring(out))
  end
  local File = java.import('java.io.File')
  local dir = java.new(File, context:getExternalFilesDir(nil), 'MHS_Recordings')
  dir:mkdirs()
  local file = java.new(File, dir, name .. '.m4a')
  return { file = file, path = file:getAbsolutePath() }
end

local function discard(context, out)
  pcall(function()
    if out.pfd then
      out.pfd:close()
    end
  end)
  pcall(function()
    if out.uri then
      context:getContentResolver():delete(out.uri, nil, nil)
    elseif out.file then
      out.file:delete()
    end
  end)
end

local function start_recording()
  mark('context')
  local context = app_context()
  mark('permission')
  if context:checkSelfPermission('android.permission.RECORD_AUDIO') ~= 0 then
    error('no microphone permission')
  end
  mark('output')
  local out = open_output(context, 'MHS_' .. os.date('%Y%m%d_%H%M%S'))
  mark('recorder')
  local Recorder = java.import('android.media.MediaRecorder')
  local ok_new, recorder = pcall(java.new, Recorder, context)
  if not ok_new then
    print('MediaRecorder(context) failed: ' .. tostring(recorder))
    recorder = java.new(Recorder)
  end
  local ok, err = pcall(function()
    mark('source')
    recorder:setAudioSource(java.import('android.media.MediaRecorder$AudioSource').MIC)
    mark('format')
    recorder:setOutputFormat(java.import('android.media.MediaRecorder$OutputFormat').MPEG_4)
    mark('encoder')
    recorder:setAudioEncoder(java.import('android.media.MediaRecorder$AudioEncoder').AAC)
    mark('settings')
    recorder:setAudioChannels(2)
    recorder:setAudioEncodingBitRate(192000)
    recorder:setAudioSamplingRate(44100)
    mark('file')
    if out.fd then
      recorder:setOutputFile(out.fd)
    else
      recorder:setOutputFile(out.path)
    end
    mark('prepare')
    recorder:prepare()
    mark('start')
    recorder:start()
  end)
  if not ok then
    pcall(function() recorder:release() end)
    discard(context, out)
    error(err, 0)
  end
  set_recording({ recorder = recorder, pfd = out.pfd, uri = out.uri, file = out.file })
  buzz(100)
  if sf.settings.get('speakStart') then
    sf.speak(tr('Recording in stereo'))
  end
end

-- What the share sheet gets: the address of the file in the Music folder, or one of SandFly's file
-- provider for a file in its own folder.
local function uri_of(context, r)
  if r.uri then
    local values = java.new(java.import('android.content.ContentValues'))
    values:put('is_pending', java.import('java.lang.Integer'):valueOf(0))
    context:getContentResolver():update(r.uri, values, nil, nil)
    return r.uri
  end
  return java.import('androidx.core.content.FileProvider'):getUriForFile(
    context, context:getPackageName() .. '.providers.FileProvider', r.file)
end

local function share(context, uri)
  local Intent = java.import('android.content.Intent')
  local send = java.new(Intent, Intent.ACTION_SEND)
  send:setType('audio/mp4')
  send:putExtra(Intent.EXTRA_STREAM, uri)
  send:addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
  send:setClipData(java.import('android.content.ClipData'):newRawUri('', uri))
  local chooser = Intent:createChooser(send, tr('Share recording'))
  chooser:addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
  chooser:addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
  context:startActivity(chooser)
end

local function stop_recording(r)
  set_recording(nil)
  local context = app_context()
  local stopped, stop_err = pcall(function() r.recorder:stop() end)
  pcall(function() r.recorder:release() end)
  pcall(function()
    if r.pfd then
      r.pfd:close()
    end
  end)
  if not stopped then
    -- stopped before any sound was recorded: there is no file to keep
    print('stop failed: ' .. tostring(stop_err))
    discard(context, r)
    sf.speak(tr('Recording too short, discarded'))
    return
  end
  buzz(200)
  sf.speak(tr('Recording ended'))
  local ok, err = pcall(function()
    share(context, uri_of(context, r))
  end)
  if not ok then
    print('share failed: ' .. tostring(err))
    sf.speak(tr('The recording is saved, but it could not be shared'))
  end
end

sf.onCommand('toggleRecording', function()
  local ok, err = pcall(function()
    local r = get_recording()
    if r then
      stop_recording(r)
    else
      start_recording()
    end
  end)
  if not ok then
    print('Recording failed in step ' .. step .. ': ' .. tostring(err))
    local text = tr('Could not record')
    local lowered = tostring(err):lower()
    if lowered:find('permission', 1, true) or lowered:find('setaudiosource failed', 1, true) then
      text = text .. '. ' .. tr('Allow the microphone for SandFly in Android settings')
    else
      -- the step and the start of the error, for whoever is looking for the cause
      text = text .. '. ' .. step .. ': ' .. tostring(err):sub(1, 160)
    end
    sf.speak(text)
  end
end)
