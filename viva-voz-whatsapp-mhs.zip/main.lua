-- WhatsApp calls (MHS): in a WhatsApp call, the speaker follows the phone. Moving the phone away from the ear puts
-- the call on the speaker, and holding it up again puts it back on the earpiece. It was part of the WhatsApp
-- messages script (3.9) and is a script of its own so that script runs only in WhatsApp and needs no Java.

local manifest = {
  id = 'whatsapp-calls-mhs',
  name = 'WhatsApp calls (MHS)',
  version = '2.0.0',
  author = 'MHS Softwares',
  minApiVersion = 6,
  testedApiVersion = 6,
  description = 'In a WhatsApp call, takes the call to the speaker when you move the phone away from your ear, and back to the earpiece when you hold it up again. It presses the speaker button of the call screen, but only when the speaker is not already in the state it should be in, which it asks Android. A headset, wired or Bluetooth, is left alone. What SandFly would say about the button changing is silenced for a moment, so the only feedback is a short vibration. It uses the proximity sensor, so turn on Keep running with the screen off on the page of the script: the screen turns off at your ear. The command Say call audio status says what the script sees.',
  permissions = { 'screen', 'actions', 'speech', 'java' },
  keepLoaded = true,
  settings = {
    { key = 'speakerWhenAway', type = 'switch', title = 'Speaker when away from your ear', default = true },
  },
  commands = {
    { id = 'callInfo', title = 'Say call audio status' },
  },
}

local tr = sf._

local function lower(text)
  return (tostring(text or ''):lower())
end

local function short_id(item)
  return (item.id or ''):match('[^/]*$') or ''
end


-- ======== Calls: the speaker follows the phone ======================================================
-- In a WhatsApp call, moving the phone away from the ear puts the call on the speaker, and holding it up
-- again puts it back on the earpiece. Everything is inside this block, so that its names can't meet the
-- ones of the messages above.
do
local WHATSAPP = { ['com.whatsapp'] = true, ['com.whatsapp.w4b'] = true }
local SPEAKER_WORDS = { 'alto-falante', 'alto falante', 'altofalante', 'viva-voz', 'viva voz', 'speaker' }
local SPEAKER_IDS = { 'speaker', 'audio_route' }
local TYPE_EARPIECE = 1
local TYPE_SPEAKER = 2
local MODE_IN_CALL = 2
local MODE_IN_COMMUNICATION = 3
local SENSOR_TYPE_PROXIMITY = 8
local SENSOR_DELAY_NORMAL = 3
local FAR_LIMIT = 5 -- centimeters: the sensors that report only near or far use their maximum
local SETTLE_MS = 500 -- a reading has to hold this long, so that a hand passing over doesn't switch
local VERIFY_MS = 900
local MUTE_MS = 1500 -- speech that follows the press of the button, such as the new state of the button

-- What is kept across loads of the script is kept in Java, in the properties of the process: SandFly
-- unloads a script when it is reloaded, and a listener that only the old load knew of could never be
-- removed.
local KEY = 'mhs.calls.'

local function properties()
  return java.import('java.lang.System'):getProperties()
end

local function app_context()
  local context = java.import('android.app.ActivityThread'):currentApplication()
  if not context then
    error('SandFly has no context')
  end
  return context
end

local enabled = sf.settings.get('speakerWhenAway') ~= false

-- ---- what Android says about the call audio -------------------------------------------------------

local function in_call(audio)
  local mode = audio:getMode()
  return mode == MODE_IN_CALL or mode == MODE_IN_COMMUNICATION
end

-- 'speaker' or 'earpiece'; nil when another device is in use, such as a headset, or it can't be told.
local function route(audio)
  local ok, device = pcall(function() return audio:getCommunicationDevice() end)
  if ok and device then
    local kind = device:getType()
    if kind == TYPE_SPEAKER then
      return 'speaker'
    elseif kind == TYPE_EARPIECE then
      return 'earpiece'
    end
    return nil
  end
  local asked, on = pcall(function() return audio:isSpeakerphoneOn() end)
  if asked then
    return on and 'speaker' or 'earpiece'
  end
  return nil
end

-- ---- the speaker button of the call screen ---------------------------------------------------------

local function is_speaker_button(item)
  local id = lower(short_id(item))
  for _, part in ipairs(SPEAKER_IDS) do
    if id:find(part, 1, true) then
      return true
    end
  end
  local name = lower(item.contentDescription or item.text)
  for _, word in ipairs(SPEAKER_WORDS) do
    if name:find(word, 1, true) then
      return true
    end
  end
  return false
end

local MAX_ITEMS = 120

local function find_speaker_button()
  for _, item in ipairs(sf.screen.findAll({ clickable = true }, MAX_ITEMS)) do
    if is_speaker_button(item) then
      return item
    end
  end
end

local function press(item)
  -- SandFly would read the new state of the button; the call changes quietly. Speech under way stops, and
  -- what SandFly would say in the next moment is dropped.
  pcall(function()
    sf.feedback.mute({ speech = true }, MUTE_MS)
  end)
  if not item:click() then
    item:tap()
  end
end

local function buzz(ms)
  local ok = pcall(function()
    local vibrator = app_context():getSystemService('vibrator')
    vibrator:vibrate(java.import('android.os.VibrationEffect'):createOneShot(ms, -1))
  end)
  if not ok then
    sf.vibrate(ms)
  end
end

-- ---- moving the call -------------------------------------------------------------------------------

local release -- defined below

-- Puts the call on the speaker, or on the earpiece, unless it already is there.
local function apply(want_speaker, retry)
  local audio = app_context():getSystemService('audio')
  if not in_call(audio) then
    release()
    return
  end
  local current = route(audio)
  if current == nil or (current == 'speaker') == want_speaker then
    return
  end
  local button = find_speaker_button()
  if not button then
    print('Speaker button not found on the call screen')
    return
  end
  press(button)
  buzz(60)
  if not retry then
    -- WhatsApp may not have moved the call: look once more, and press once more if it hasn't.
    sf.setTimeout(function()
      local again = app_context():getSystemService('audio')
      if in_call(again) and route(again) == current then
        apply(want_speaker, true)
      end
    end, VERIFY_MS)
  end
end

-- ---- the proximity sensor --------------------------------------------------------------------------

local reading = 0 -- counts the readings, so that a timer of an older one does nothing

local function on_reading(value)
  if not enabled then
    return
  end
  reading = reading + 1
  local want_speaker = value >= FAR_LIMIT
  local mine = reading
  sf.setTimeout(function()
    if mine == reading then
      local ok, err = pcall(apply, want_speaker, false)
      if not ok then
        print('Moving the call failed: ' .. tostring(err))
      end
    end
  end, SETTLE_MS)
end

function release()
  pcall(function()
    local props = properties()
    local listener = props:get(KEY .. 'listener')
    if listener then
      pcall(function()
        app_context():getSystemService('sensor'):unregisterListener(listener)
      end)
      props:remove(KEY .. 'listener')
    end
  end)
end

local function acquire()
  local props = properties()
  if props:get(KEY .. 'listener') then
    return
  end
  local manager = app_context():getSystemService('sensor')
  local sensor = manager:getDefaultSensor(SENSOR_TYPE_PROXIMITY)
  if not sensor then
    print('No proximity sensor')
    return
  end
  local maximum = sensor:getMaximumRange()
  local far_limit = math.min(maximum, FAR_LIMIT)
  local Array = java.import('java.lang.reflect.Array')
  -- LuaJava gives the function of a proxy the proxy itself first, and the arguments after it.
  local listener = java.proxy('android.hardware.SensorEventListener', {
    onSensorChanged = function(...)
      local args = table.pack(...)
      local event = args[args.n]
      local value = Array:getFloat(event.values, 0)
      on_reading(value >= far_limit and FAR_LIMIT or 0)
    end,
    onAccuracyChanged = function() end,
  })
  manager:registerListener(listener, sensor, SENSOR_DELAY_NORMAL)
  props:put(KEY .. 'listener', listener)
end

-- ---- when to listen --------------------------------------------------------------------------------

-- Listening starts when a WhatsApp window opens during a call, and stops with the call.
local function check(app)
  if not java then
    return -- the Java permission is turned off: nothing here can work
  end
  if not enabled then
    release()
    return
  end
  if not (app and WHATSAPP[app.package]) then
    return
  end
  local ok, err = pcall(function()
    if in_call(app_context():getSystemService('audio')) then
      acquire()
    else
      release()
    end
  end)
  if not ok then
    print('Checking the call failed: ' .. tostring(err))
  end
end

sf.onAppEnter(check)
sf.onWindowChange(check)

sf.onSettingChange(function(key, value)
  if key == 'speakerWhenAway' then
    enabled = value ~= false
    if not enabled then
      release()
    else
      check(sf.app())
    end
  end
end)

-- A listener left by an earlier load of the script is removed, and listening starts again if needed. With
-- the Java permission turned off none of this works, and the rest of the script goes on.
pcall(release)
pcall(function()
  check(sf.app())
end)

-- ---- the status command ----------------------------------------------------------------------------

sf.onCommand('callInfo', function()
  local ok, err = pcall(function()
    local audio = app_context():getSystemService('audio')
    local parts = {}
    if not in_call(audio) then
      parts[#parts + 1] = tr('Not in a call')
    else
      local where = route(audio)
      parts[#parts + 1] = where == 'speaker' and tr('Speaker on')
        or where == 'earpiece' and tr('Speaker off')
        or tr('Other audio device')
      parts[#parts + 1] = find_speaker_button() and tr('Speaker button found') or tr('Speaker button not found')
    end
    sf.speak(table.concat(parts, '. '))
  end)
  if not ok then
    print('Call status failed: ' .. tostring(err))
    sf.speak(tr('Could not read the call audio') .. '. ' .. tostring(err):sub(1, 160))
  end
end)
end
