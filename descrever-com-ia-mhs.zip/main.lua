local manifest = {
  id = 'describe-with-ai-mhs',
  name = 'Describe with AI (MHS)',
  version = '1.1',
  author = 'MHS Softwares',
  minApiVersion = 6,
  testedApiVersion = 6,
  description = 'Sends a picture of the focused item, or of the whole screen, to Be My Eyes or to Seeing AI, which describe it. Assign the commands in Settings > Commands > Scripts to gestures. The image goes straight to the app you choose; if it is not installed, its page in the store opens. In Be My Eyes, the command for the whole screen goes back instead. Secure screens, such as some banking apps, come out black.',
  permissions = { 'speech', 'java', 'screen' },
  commands = {
    { id = 'beMyEyesItem', title = 'Describe the focused item with Be My Eyes' },
    { id = 'beMyEyesScreen', title = 'Describe the whole screen with Be My Eyes' },
    { id = 'seeingAiItem', title = 'Describe the focused item with Seeing AI' },
    { id = 'seeingAiScreen', title = 'Describe the whole screen with Seeing AI' },
  },
}

local tr = sf._

local BE_MY_EYES = 'com.bemyeyes.bemyeyes'
local SEEING_AI = 'com.microsoft.seeingai'
local REDRAW_MS = 150 -- how long the app gets to redraw without the focus indicator
local ITEM_INSET = 8 -- pixels cut from the item's edge when the focus indicator can't be hidden
local GLOBAL_ACTION_BACK = 1

-- The step the script is in, so that a failure can say where it happened.
local step = ''
local function mark(name)
  step = name
end

local function service_instance()
  local service = java.import('com.google.android.accessibility.talkback.TalkBackService'):getInstance()
  if not service then
    error('SandFly is not running')
  end
  return service
end

-- Vibrates through Android itself, SandFly's own vibration being the fallback.
local function buzz(service, ms)
  local ok = pcall(function()
    local vibrator = service:getSystemService('vibrator')
    vibrator:vibrate(java.import('android.os.VibrationEffect'):createOneShot(ms, -1))
  end)
  if not ok then
    sf.vibrate(ms)
  end
end

local function foreground_package(service)
  local ok, name = pcall(function()
    local root = service:getRootInActiveWindow()
    return root and tostring(root:getPackageName()) or ''
  end)
  return ok and name or ''
end

-- The app isn't installed: its page in the store opens instead.
local function open_store(service, package)
  local Intent = java.import('android.content.Intent')
  local intent = java.new(Intent, Intent.ACTION_VIEW)
  intent:setData(java.import('android.net.Uri'):parse('market://details?id=' .. package))
  intent:addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
  service:startActivity(intent)
end

-- The picture goes to the app alone, with no share sheet in between.
local function send_image(service, package, file)
  mark('share')
  local uri = java.import('androidx.core.content.FileProvider'):getUriForFile(
    service, service:getPackageName() .. '.providers.FileProvider', file)
  local Intent = java.import('android.content.Intent')
  local intent = java.new(Intent, Intent.ACTION_SEND)
  intent:setType('image/*')
  intent:setPackage(package)
  intent:putExtra(Intent.EXTRA_STREAM, uri)
  intent:addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
  intent:addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
  intent:setClipData(java.import('android.content.ClipData'):newRawUri('', uri))
  pcall(function() service:grantUriPermission(package, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) end)
  service:startActivity(intent)
end

local function save_image(service, shot, bounds, name)
  mark('crop')
  local Bitmap = java.import('android.graphics.Bitmap')
  local image = shot
  if bounds then
    local left = math.max(0, bounds.left)
    local top = math.max(0, bounds.top)
    local right = math.min(shot:getWidth(), bounds.right)
    local bottom = math.min(shot:getHeight(), bounds.bottom)
    if right - left < 2 or bottom - top < 2 then
      error('the item is outside the screen')
    end
    image = Bitmap:createBitmap(shot, left, top, right - left, bottom - top)
  end
  mark('save')
  local File = java.import('java.io.File')
  local dir = java.new(File, service:getCacheDir(), 'shared_images')
  dir:mkdirs()
  local file = java.new(File, dir, name)
  local out = java.new(java.import('java.io.FileOutputStream'), file)
  local ok = image:compress(java.import('android.graphics.Bitmap$CompressFormat').JPEG, 95, out)
  out:close()
  if not ok then
    error('the image could not be saved')
  end
  return file
end

local function fail(err)
  print('Describe failed in step ' .. step .. ': ' .. tostring(err))
  sf.speak(tr('Could not describe the image') .. '. ' .. step .. ': ' .. tostring(err):sub(1, 160))
end

-- Takes the screenshot, with the focus indicator hidden for the focused item, and sends it.
local function describe(package, bounds, name)
  local service
  local hidden = false
  local function finish()
    if hidden then
      pcall(function()
        java.import('com.google.android.accessibility.talkback.utils.FocusIndicatorUtils'):restoreAfterScreenshot(service)
      end)
      hidden = false
    end
  end
  local ok, err = pcall(function()
    mark('service')
    service = service_instance()
    mark('app')
    if not service:getPackageManager():getLaunchIntentForPackage(package) then
      open_store(service, package)
      return
    end
    buzz(service, 60)
    if bounds then
      mark('focus')
      hidden = java.import('com.google.android.accessibility.talkback.utils.FocusIndicatorUtils'):hideForScreenshot(service)
      if hidden then
        sf.sleep(REDRAW_MS)
      else
        bounds = { left = bounds.left + ITEM_INSET, top = bounds.top + ITEM_INSET,
                   right = bounds.right - ITEM_INSET, bottom = bounds.bottom - ITEM_INSET }
      end
    end
    mark('screenshot')
    local listener = java.proxy(
      'com.google.android.libraries.accessibility.utils.screencapture.ScreenCaptureController$CaptureListener', {
        -- LuaJava gives a proxy's function the proxy itself first, then the arguments of the call.
        onScreenCaptureFinished = function(...)
          local first, second = ...
          local shot = first
          if select('#', ...) >= 3 then
            shot = second -- may be nil when the capture failed
          end
          finish()
          local done, why = pcall(function()
            if not shot then
              error('no screenshot')
            end
            send_image(service, package, save_image(service, shot, bounds, name))
          end)
          if not done then
            fail(why)
          end
        end,
      })
    java.import('com.google.android.accessibility.utils.screencapture.ScreenshotCapture'):takeScreenshot(service, listener)
  end)
  if not ok then
    finish()
    fail(err)
  end
end

local function item_bounds(event)
  local node = event and event.node
  local bounds = node and node.bounds
  if not bounds then
    sf.speak(tr('Nothing is focused'))
    return nil
  end
  return bounds
end

local function on_item(package, name)
  return function(event)
    local bounds = item_bounds(event)
    if bounds then
      sf.setTimeout(describe, 0, package, bounds, name)
    end
  end
end

local function on_screen(package, name, back_inside)
  return function()
    sf.setTimeout(function()
      if back_inside then
        -- Inside the app that describes, the same gesture closes the description.
        local ok, service = pcall(service_instance)
        if ok and foreground_package(service) == package then
          service:performGlobalAction(GLOBAL_ACTION_BACK)
          return
        end
      end
      describe(package, nil, name)
    end, 0)
  end
end

sf.onCommand('beMyEyesItem', on_item(BE_MY_EYES, 'MHS-describe-item.jpg'))
sf.onCommand('beMyEyesScreen', on_screen(BE_MY_EYES, 'MHS-describe-screen.jpg', true))
sf.onCommand('seeingAiItem', on_item(SEEING_AI, 'MHS-describe-item.jpg'))
sf.onCommand('seeingAiScreen', on_screen(SEEING_AI, 'MHS-describe-screen.jpg', false))
