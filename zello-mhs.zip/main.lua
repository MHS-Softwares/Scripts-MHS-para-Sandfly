local manifest = {
  id = 'zello-mhs',
  name = 'Zello (MHS)',
  version = '1.3.1',
  author = 'MHS Softwares',
  minApiVersion = 6,
  testedApiVersion = 6,
  description = 'In Zello, a double tap on the talk button presses it with a touch on the screen, as a finger does. The button ignores the double tap of a screen reader, which presses it without touching the screen, and only answers to a touch on the screen. With the button set to toggle, the double tap starts and stops talking. On any other item the double tap works as always. SandFly waits a little before it touches the screen, so the button answers about a third of a second after the double tap.',
  apps = { 'com.loudtalks' },
  permissions = { 'screen', 'actions', 'input' },
  settings = {
    { key = 'touchMs', type = 'number', title = 'How long the touch stays on the button, in milliseconds', default = 1 },
    { key = 'waitMs', type = 'number', title = 'How long SandFly waits before the touch, in milliseconds (only a SandFly with the wait option; 350 is what SandFly always waited)', default = 290 },
  },
  commands = {
    { id = 'pressToTalk', title = 'Press the talk button', gesture = 'doubleTap' },
  },
}

local tr = sf._

-- The id of the talk button of Zello, which a screen reader reads as "Falar" or "Talk".
local TALK_BUTTON = 'round_button'
local DEFAULT_TOUCH_MS = 1
local MAX_TOUCH_MS = 2000
local DEFAULT_WAIT_MS = 290
local MAX_WAIT_MS = 1000

local function short_id(item)
  return (item.id or ''):match('[^/]*$')
end

-- A setting that is a number, kept between a minimum and a maximum; the default if it isn't one.
local function number_setting(key, default, minimum, maximum)
  local value = tonumber(sf.settings.get(key))
  if value == nil then
    return default
  end
  return math.floor(math.min(maximum, math.max(minimum, value)))
end

-- Touches the middle of the button: a touch of touchMs milliseconds that SandFly starts waitMs after the call. A SandFly
-- without the wait option ignores it and waits its 350. An item that has no place on screen can't be touched.
local function touch(node)
  local b = node.bounds
  if type(b) ~= 'table' then
    error('no place on screen')
  end
  local x, y = (b.left + b.right) // 2, (b.top + b.bottom) // 2
  local duration = number_setting('touchMs', DEFAULT_TOUCH_MS, 1, MAX_TOUCH_MS)
  local wait = number_setting('waitMs', DEFAULT_WAIT_MS, 0, MAX_WAIT_MS)
  sf.touch.gesture({ { points = { { x = x, y = y } }, duration = duration } }, { wait = wait })
end

local function press(node)
  if not pcall(touch, node) then
    sf.speak(tr('Could not press the talk button'))
  end
end

-- A double tap on the talk button touches it. On another item it returns false, so that the double
-- tap does what it always does.
sf.onCommand('pressToTalk', function(event)
  local node = event and event.node
  if not node or short_id(node) ~= TALK_BUTTON then
    return false
  end
  sf.setTimeout(press, 0, node)
end)
